from enum import StrEnum


class UserRole(StrEnum):
    PARTICIPANT = "participant"
    ORGANIZER = "organizer"
    JUDGE = "judge"
    ADMIN = "admin"


class UserStatus(StrEnum):
    ACTIVE = "active"
    BLOCKED = "blocked"


class ContestStatus(StrEnum):
    DRAFT = "draft"
    PUBLISHED = "published"
    ACCEPTING_LOGS = "accepting_logs"
    LOG_SUBMISSION_CLOSED = "log_submission_closed"
    CHECKING = "checking"
    JUDGE_REVIEW = "judge_review"
    FINALIZED = "finalized"
    RESULTS_PUBLISHED = "results_published"
    ARCHIVED = "archived"


class ParticipantStatus(StrEnum):
    REGISTERED = "registered"
    SUBMITTED = "submitted"
    ACCEPTED = "accepted"
    CHECKED = "checked"
    WITHDRAWN = "withdrawn"


class SubmissionStatus(StrEnum):
    UPLOADED = "uploaded"
    PARSING_QUEUED = "parsing_queued"
    PARSING = "parsing"
    VALIDATION_FAILED = "validation_failed"
    ACCEPTED = "accepted"
    CHECKING = "checking"
    CHECKED = "checked"
    SUPERSEDED = "superseded"


class QsoCheckStatus(StrEnum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    REJECTED = "rejected"
    DUPLICATE = "duplicate"
    CONFLICT = "conflict"
    AMBIGUOUS = "ambiguous"
    NO_MATCH = "no_match"


class IssueSeverity(StrEnum):
    BLOCKING = "blocking"
    WARNING = "warning"


class ValidationIssueType(StrEnum):
    FILE_EMPTY = "file_empty"
    FILE_NOT_TEXT = "file_not_text"
    MISSING_REQUIRED_HEADER = "missing_required_header"
    MISSING_QSO_LINES = "missing_qso_lines"
    INVALID_QSO_FORMAT = "invalid_qso_format"
    QSO_OUT_OF_CONTEST_TIME = "qso_out_of_contest_time"
    UNSUPPORTED_BAND = "unsupported_band"
    UNSUPPORTED_MODE = "unsupported_mode"
    MISSING_EXCHANGE = "missing_exchange"
    CATEGORY_MISMATCH = "category_mismatch"
    DUPLICATE_QSO_IN_FILE = "duplicate_qso_in_file"


class ConflictType(StrEnum):
    NIL = "nil"
    AMBIGUOUS = "ambiguous"
    BUSTED_CALL = "busted_call"
    TIME_MISMATCH = "time_mismatch"
    BAND_MISMATCH = "band_mismatch"
    MODE_MISMATCH = "mode_mismatch"
    EXCHANGE_MISMATCH = "exchange_mismatch"
    DUPLICATE_QSO = "duplicate_qso"
    MISSING_COUNTERPARTY_LOG = "missing_counterparty_log"


class ConflictStatus(StrEnum):
    OPEN = "open"
    AUTO_RESOLVED = "auto_resolved"
    JUDGE_RESOLVED = "judge_resolved"


class JudgeDecisionType(StrEnum):
    ACCEPT_MATCH = "accept_match"
    OVERRIDE_MATCH = "override_match"
    MARK_NIL = "mark_nil"
    MARK_BUSTED_CALL = "mark_busted_call"
    IGNORE_CONFLICT = "ignore_conflict"
    RECALCULATE = "recalculate"


class ProcessingJobType(StrEnum):
    VALIDATION = "validation"
    PARSING = "parsing"
    SCORING = "scoring"
    CROSS_CHECK = "cross_check"
    PUBLICATION_PREPARATION = "publication_preparation"


class ProcessingJobStatus(StrEnum):
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"


class EventOutboxStatus(StrEnum):
    PENDING = "pending"
    PUBLISHED = "published"
    FAILED = "failed"


class MatchingDecisionStatus(StrEnum):
    CONFIRMED = "confirmed"
    CONFLICT = "conflict"
    DUPLICATE = "duplicate"
    NO_MATCH = "no_match"
    """Multiple viable candidates within tie gap — requires judge."""
    AMBIGUOUS = "ambiguous"
