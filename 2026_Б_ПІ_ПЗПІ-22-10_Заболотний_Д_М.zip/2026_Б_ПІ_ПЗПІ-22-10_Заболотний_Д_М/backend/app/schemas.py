from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, EmailStr, Field, model_validator

from app.domain import (
    ConflictStatus,
    ConflictType,
    ContestStatus,
    IssueSeverity,
    JudgeDecisionType,
    MatchingDecisionStatus,
    ParticipantStatus,
    ProcessingJobStatus,
    ProcessingJobType,
    QsoCheckStatus,
    SubmissionStatus,
    UserRole,
    UserStatus,
    ValidationIssueType,
)


class OrmModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    display_name: str | None = None
    callsign: str | None = None


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class ProfileUpdate(BaseModel):
    display_name: str | None = None
    callsign: str | None = None


class UserRead(OrmModel):
    id: int
    email: EmailStr
    display_name: str | None
    callsign: str | None
    global_roles: list[UserRole]
    status: UserStatus


class ScoringRuleIn(BaseModel):
    qso_points: int = 1
    required_exchange_fields: list[str] = Field(default_factory=list)
    time_tolerance_minutes: int = 5
    duplicate_policy: str = "same_band_mode"
    multiplier_policy: dict[str, Any] = Field(default_factory=dict)
    penalty_policy: dict[str, Any] = Field(default_factory=dict)


class ContestCreate(BaseModel):
    title: str
    description: str
    rules_text: str
    start_at_utc: datetime
    end_at_utc: datetime
    log_submission_open_at_utc: datetime
    log_submission_deadline_at_utc: datetime
    allowed_bands: list[str] = Field(default_factory=list)
    allowed_modes: list[str] = Field(default_factory=list)
    categories: list[str]
    scoring_rule: ScoringRuleIn = Field(default_factory=ScoringRuleIn)


class ContestUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    rules_text: str | None = None
    start_at_utc: datetime | None = None
    end_at_utc: datetime | None = None
    log_submission_open_at_utc: datetime | None = None
    log_submission_deadline_at_utc: datetime | None = None
    allowed_bands: list[str] | None = None
    allowed_modes: list[str] | None = None
    categories: list[str] | None = None
    scoring_rule: ScoringRuleIn | None = None


class ScoringRuleRead(OrmModel):
    qso_points: int
    required_exchange_fields: list[str]
    time_tolerance_minutes: int
    duplicate_policy: str
    multiplier_policy: dict[str, Any]
    penalty_policy: dict[str, Any]


class ContestRead(OrmModel):
    id: int
    title: str
    description: str
    rules_text: str
    start_at_utc: datetime
    end_at_utc: datetime
    log_submission_open_at_utc: datetime
    log_submission_deadline_at_utc: datetime
    status: ContestStatus
    allowed_bands: list[str]
    allowed_modes: list[str]
    categories: list[str]
    created_by_id: int
    scoring_rule: ScoringRuleRead | None


class JudgeContestRead(BaseModel):
    id: int
    title: str
    status: ContestStatus
    start_at_utc: datetime
    end_at_utc: datetime


class ContestJudgeAdd(BaseModel):
    user_id: int | None = None
    email: EmailStr | None = None

    @model_validator(mode="after")
    def exactly_one_identifier(self) -> "ContestJudgeAdd":
        has_uid = self.user_id is not None
        has_email = self.email is not None
        if has_uid == has_email:
            raise ValueError("Exactly one of user_id or email must be provided")
        return self


class ContestJudgeRead(BaseModel):
    user_id: int
    email: EmailStr
    display_name: str | None
    callsign: str | None
    assigned_at_utc: datetime


class ParticipationCreate(BaseModel):
    callsign: str = Field(min_length=2, max_length=32)
    category: str
    power: str | None = None
    country_or_region: str | None = None


class ParticipantRead(OrmModel):
    id: int
    user_id: int
    contest_id: int
    callsign: str
    category: str
    power: str | None
    country_or_region: str | None
    status: ParticipantStatus
    current_submission_id: int | None


class ValidationIssueRead(OrmModel):
    id: int
    submission_id: int
    qso_id: int | None
    type: ValidationIssueType
    severity: IssueSeverity
    message: str
    line_number: int | None


class QsoRead(OrmModel):
    id: int
    participant_callsign: str
    counterparty_callsign: str
    qso_at_utc: datetime
    band: str
    frequency: str | None
    mode: str
    sent_exchange: str | None
    received_exchange: str | None
    raw_line: str
    line_number: int
    check_status: QsoCheckStatus
    matched_qso_id: int | None


class SubmissionRead(OrmModel):
    id: int
    participant_id: int
    contest_id: int
    original_file_path: str
    original_file_hash: str
    uploaded_at_utc: datetime
    version: int
    status: SubmissionStatus
    parsed_metadata: dict[str, Any]


class SubmissionDetail(SubmissionRead):
    issues: list[ValidationIssueRead] = Field(default_factory=list)
    qso_records: list[QsoRead] = Field(default_factory=list)


class ConflictRead(OrmModel):
    id: int
    contest_id: int
    qso_id: int
    candidate_qso_id: int | None
    type: ConflictType
    severity: IssueSeverity
    status: ConflictStatus
    detected_at_utc: datetime
    details: dict[str, Any]


class JudgeDashboardRead(BaseModel):
    total_qso: int
    auto_resolved_ratio: float
    pending_conflicts: int
    high_priority_conflicts: int
    avg_confidence: float


class ConflictQueueItem(BaseModel):
    id: int
    contest_id: int
    qso_id: int
    candidate_qso_id: int | None
    type: ConflictType
    severity: IssueSeverity
    status: ConflictStatus
    detected_at_utc: datetime
    participant_callsign: str
    counterparty_callsign: str
    band: str
    mode: str
    qso_at_utc: datetime
    confidence: float
    impact: int
    category: str | None = None
    region: str | None = None
    details: dict[str, Any]


class ConflictQueueRead(BaseModel):
    items: list[ConflictQueueItem]
    total: int
    limit: int
    offset: int


class ConflictNeighborRead(BaseModel):
    contest_id: int
    conflict_id: int
    index: int | None
    prev_conflict_id: int | None
    next_conflict_id: int | None
    total_matching_filters: int


class ParticipantStationSearchHit(BaseModel):
    callsign: str
    category: str | None = None
    region: str | None = None


class ConflictDetail(ConflictRead):
    qso: QsoRead
    candidate_qso: QsoRead | None = None


class MatchingDecisionRead(OrmModel):
    id: int
    contest_id: int
    qso_id: int
    candidate_qso_id: int | None
    conflict_id: int | None
    status: MatchingDecisionStatus
    confidence: int
    stage: str
    decided_at_utc: datetime
    details: dict[str, Any]


class ConflictWorkbenchDetail(ConflictDetail):
    """Judge review payload with deterministic pipeline artifacts."""

    explainability: dict[str, Any] | None = None
    matching_candidates: list[dict[str, Any]] = Field(default_factory=list)
    timeline: dict[str, Any] | None = None
    prior_matching_decisions: list[MatchingDecisionRead] = Field(default_factory=list)


class JudgeDecisionCreate(BaseModel):
    decision: JudgeDecisionType
    comment: str = Field(min_length=1)
    score_impact: int = 0
    """Use for OVERRIDE_MATCH to select a specific candidate."""
    selected_candidate_qso_id: int | None = None


class JudgeDecisionRead(OrmModel):
    id: int
    conflict_id: int
    judge_id: int
    decision: JudgeDecisionType
    comment: str
    score_impact: int
    metadata_json: dict[str, Any]
    created_at_utc: datetime


class ScoringResultRead(OrmModel):
    id: int
    participant_id: int
    contest_id: int
    claimed_score_from_file: int | None
    system_claimed_score: int
    final_score: int | None
    confirmed_qso_count: int
    rejected_qso_count: int
    duplicate_qso_count: int
    multiplier_count: int
    penalty_points: int
    calculated_at_utc: datetime


class PublicResultRead(OrmModel):
    id: int
    contest_id: int
    participant_id: int
    rank_overall: int | None
    rank_in_category: int
    callsign: str
    category: str
    claimed_score: int
    final_score: int
    confirmed_qso_count: int
    removed_qso_count: int
    published_at_utc: datetime


class PersonalReport(BaseModel):
    participant: ParticipantRead
    scoring: ScoringResultRead | None
    removed_or_changed_qso: list[dict[str, Any]]


class ProcessingJobRead(OrmModel):
    id: int
    contest_id: int | None
    submission_id: int | None
    type: ProcessingJobType
    status: ProcessingJobStatus
    started_by_id: int | None
    started_at_utc: datetime | None
    finished_at_utc: datetime | None
    summary: dict[str, Any]
    error_message: str | None


class SubmissionUploadAccepted(BaseModel):
    submission: SubmissionDetail
    job: ProcessingJobRead


class AuditEventRead(OrmModel):
    id: int
    actor_id: int | None
    action: str
    target_type: str
    target_id: int | None
    timestamp_utc: datetime
    metadata_json: dict[str, Any]


class RoleUpdate(BaseModel):
    roles: list[UserRole]


class UserStatusUpdate(BaseModel):
    status: UserStatus
