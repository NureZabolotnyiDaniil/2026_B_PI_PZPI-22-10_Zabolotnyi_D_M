from datetime import UTC, datetime
from typing import Any

from sqlalchemy import DateTime, Enum, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.types import JSON

from app.core.database import Base
from app.domain import (
    ConflictStatus,
    ConflictType,
    ContestStatus,
    EventOutboxStatus,
    IssueSeverity,
    JudgeDecisionType,
    MatchingDecisionStatus,
    ParticipantStatus,
    ProcessingJobStatus,
    ProcessingJobType,
    QsoCheckStatus,
    SubmissionStatus,
    UserRole,
    UserStatus,
    ValidationIssueType,
)


def utc_now() -> datetime:
    return datetime.now(UTC)


def enum_column(enum_type: type, default: Any | None = None) -> Mapped[Any]:
    return mapped_column(Enum(enum_type, native_enum=False), default=default, nullable=False)


class TimestampMixin:
    created_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    updated_at_utc: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utc_now, onupdate=utc_now
    )


class User(TimestampMixin, Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    display_name: Mapped[str | None] = mapped_column(String(255))
    callsign: Mapped[str | None] = mapped_column(String(32), index=True)
    global_roles: Mapped[list[str]] = mapped_column(JSON, default=lambda: [UserRole.PARTICIPANT])
    status: Mapped[UserStatus] = enum_column(UserStatus, UserStatus.ACTIVE)

    contests: Mapped[list["Contest"]] = relationship(back_populates="creator")
    participations: Mapped[list["Participant"]] = relationship(back_populates="user")
    contest_judge_assignments: Mapped[list["ContestJudge"]] = relationship(back_populates="user")


class ContestJudge(TimestampMixin, Base):
    __tablename__ = "contest_judges"
    __table_args__ = (Index("ix_contest_judges_user_id", "user_id"),)

    contest_id: Mapped[int] = mapped_column(ForeignKey("contests.id", ondelete="CASCADE"), primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)

    contest: Mapped["Contest"] = relationship(back_populates="judge_assignments")
    user: Mapped["User"] = relationship(back_populates="contest_judge_assignments")


class Contest(TimestampMixin, Base):
    __tablename__ = "contests"

    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(255))
    description: Mapped[str] = mapped_column(Text)
    rules_text: Mapped[str] = mapped_column(Text)
    start_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    end_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    log_submission_open_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    log_submission_deadline_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    status: Mapped[ContestStatus] = enum_column(ContestStatus, ContestStatus.DRAFT)
    allowed_bands: Mapped[list[str]] = mapped_column(JSON, default=list)
    allowed_modes: Mapped[list[str]] = mapped_column(JSON, default=list)
    categories: Mapped[list[str]] = mapped_column(JSON, default=list)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"))

    creator: Mapped[User] = relationship(back_populates="contests")
    scoring_rule: Mapped["ScoringRule"] = relationship(
        back_populates="contest", cascade="all, delete-orphan", uselist=False
    )
    participants: Mapped[list["Participant"]] = relationship(back_populates="contest")
    judge_assignments: Mapped[list["ContestJudge"]] = relationship(
        back_populates="contest", cascade="all, delete-orphan"
    )


class ScoringRule(Base):
    __tablename__ = "scoring_rules"

    id: Mapped[int] = mapped_column(primary_key=True)
    contest_id: Mapped[int] = mapped_column(ForeignKey("contests.id"), unique=True)
    qso_points: Mapped[int] = mapped_column(Integer, default=1)
    required_exchange_fields: Mapped[list[str]] = mapped_column(JSON, default=list)
    time_tolerance_minutes: Mapped[int] = mapped_column(Integer, default=5)
    duplicate_policy: Mapped[str] = mapped_column(String(64), default="same_band_mode")
    multiplier_policy: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    penalty_policy: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    contest: Mapped[Contest] = relationship(back_populates="scoring_rule")


class Participant(TimestampMixin, Base):
    __tablename__ = "participants"
    __table_args__ = (
        UniqueConstraint("contest_id", "callsign", name="uq_participants_contest_callsign"),
        UniqueConstraint("user_id", "contest_id", name="uq_participants_user_contest"),
        Index("ix_participants_user_contest", "user_id", "contest_id"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    contest_id: Mapped[int] = mapped_column(ForeignKey("contests.id"))
    callsign: Mapped[str] = mapped_column(String(32))
    category: Mapped[str] = mapped_column(String(64))
    power: Mapped[str | None] = mapped_column(String(64))
    country_or_region: Mapped[str | None] = mapped_column(String(128))
    status: Mapped[ParticipantStatus] = enum_column(
        ParticipantStatus, ParticipantStatus.REGISTERED
    )
    current_submission_id: Mapped[int | None] = mapped_column(
        ForeignKey("log_submissions.id", use_alter=True), nullable=True
    )

    user: Mapped[User] = relationship(back_populates="participations")
    contest: Mapped[Contest] = relationship(back_populates="participants")
    submissions: Mapped[list["LogSubmission"]] = relationship(
        back_populates="participant",
        cascade="all, delete-orphan",
        foreign_keys="LogSubmission.participant_id",
    )
    current_submission: Mapped["LogSubmission | None"] = relationship(
        foreign_keys=[current_submission_id], post_update=True
    )


class LogSubmission(TimestampMixin, Base):
    __tablename__ = "log_submissions"
    __table_args__ = (
        UniqueConstraint("participant_id", "version", name="uq_submissions_participant_version"),
        Index("ix_log_submissions_contest_status", "contest_id", "status"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("participants.id"))
    contest_id: Mapped[int] = mapped_column(ForeignKey("contests.id"))
    original_file_path: Mapped[str] = mapped_column(String(512))
    original_file_hash: Mapped[str] = mapped_column(String(64))
    uploaded_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    version: Mapped[int] = mapped_column(Integer)
    status: Mapped[SubmissionStatus] = enum_column(SubmissionStatus, SubmissionStatus.UPLOADED)
    parsed_metadata: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    participant: Mapped[Participant] = relationship(
        back_populates="submissions", foreign_keys=[participant_id]
    )
    qso_records: Mapped[list["QSO"]] = relationship(back_populates="submission")
    issues: Mapped[list["ValidationIssue"]] = relationship(back_populates="submission")
    processing_jobs: Mapped[list["ProcessingJob"]] = relationship(back_populates="submission")


class EventOutbox(TimestampMixin, Base):
    __tablename__ = "event_outbox"
    __table_args__ = (
        UniqueConstraint("idempotency_key", name="uq_event_outbox_idempotency_key"),
        Index("ix_event_outbox_status_available", "status", "available_at_utc"),
        Index("ix_event_outbox_aggregate", "aggregate_type", "aggregate_id"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    event_type: Mapped[str] = mapped_column(String(128))
    aggregate_type: Mapped[str] = mapped_column(String(128))
    aggregate_id: Mapped[int] = mapped_column(Integer)
    partition_key: Mapped[str] = mapped_column(String(255))
    payload: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    status: Mapped[EventOutboxStatus] = enum_column(EventOutboxStatus, EventOutboxStatus.PENDING)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    available_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    published_at_utc: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    idempotency_key: Mapped[str] = mapped_column(String(255))
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)


class QSO(Base):
    __tablename__ = "qso"
    __table_args__ = (
        Index("ix_qso_contest_participant_callsign", "contest_id", "participant_callsign"),
        Index("ix_qso_contest_counterparty_callsign", "contest_id", "counterparty_callsign"),
        Index("ix_qso_contest_counterparty_time", "contest_id", "counterparty_callsign", "qso_at_utc"),
        Index("ix_qso_contest_band_mode_time", "contest_id", "band", "mode", "qso_at_utc"),
        Index("ix_qso_candidate_bucket", "contest_id", "time_bucket", "band", "mode", "counterparty_prefix"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    submission_id: Mapped[int] = mapped_column(ForeignKey("log_submissions.id"))
    contest_id: Mapped[int] = mapped_column(ForeignKey("contests.id"))
    participant_callsign: Mapped[str] = mapped_column(String(32))
    counterparty_callsign: Mapped[str] = mapped_column(String(32))
    qso_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    band: Mapped[str] = mapped_column(String(32))
    frequency: Mapped[str | None] = mapped_column(String(32))
    mode: Mapped[str] = mapped_column(String(32))
    sent_exchange: Mapped[str | None] = mapped_column(String(128))
    received_exchange: Mapped[str | None] = mapped_column(String(128))
    raw_line: Mapped[str] = mapped_column(Text)
    line_number: Mapped[int] = mapped_column(Integer)
    check_status: Mapped[QsoCheckStatus] = enum_column(QsoCheckStatus, QsoCheckStatus.PENDING)
    matched_qso_id: Mapped[int | None] = mapped_column(ForeignKey("qso.id"), nullable=True)
    normalized_participant_callsign: Mapped[str] = mapped_column(String(32), default="")
    normalized_counterparty_callsign: Mapped[str] = mapped_column(String(32), default="")
    participant_prefix: Mapped[str] = mapped_column(String(8), default="")
    counterparty_prefix: Mapped[str] = mapped_column(String(8), default="")
    time_bucket: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)

    submission: Mapped[LogSubmission] = relationship(back_populates="qso_records")
    matched_qso: Mapped["QSO | None"] = relationship(remote_side=[id])


class QsoCandidateIndex(Base):
    __tablename__ = "qso_candidate_index"
    __table_args__ = (
        UniqueConstraint("qso_id", name="uq_qso_candidate_index_qso"),
        Index(
            "ix_candidate_index_lookup",
            "contest_id",
            "time_bucket",
            "band",
            "mode",
            "participant_prefix",
        ),
        Index("ix_candidate_index_callsign", "contest_id", "normalized_participant_callsign"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    qso_id: Mapped[int] = mapped_column(ForeignKey("qso.id"))
    contest_id: Mapped[int] = mapped_column(ForeignKey("contests.id"))
    submission_id: Mapped[int] = mapped_column(ForeignKey("log_submissions.id"))
    time_bucket: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    band: Mapped[str] = mapped_column(String(32))
    mode: Mapped[str] = mapped_column(String(32))
    normalized_participant_callsign: Mapped[str] = mapped_column(String(32))
    normalized_counterparty_callsign: Mapped[str] = mapped_column(String(32))
    participant_prefix: Mapped[str] = mapped_column(String(8))
    counterparty_prefix: Mapped[str] = mapped_column(String(8))
    indexed_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)

    qso: Mapped[QSO] = relationship()


class ValidationIssue(Base):
    __tablename__ = "validation_issues"

    id: Mapped[int] = mapped_column(primary_key=True)
    submission_id: Mapped[int] = mapped_column(ForeignKey("log_submissions.id"))
    qso_id: Mapped[int | None] = mapped_column(ForeignKey("qso.id"), nullable=True)
    type: Mapped[ValidationIssueType] = enum_column(ValidationIssueType)
    severity: Mapped[IssueSeverity] = enum_column(IssueSeverity)
    message: Mapped[str] = mapped_column(Text)
    line_number: Mapped[int | None] = mapped_column(Integer)

    submission: Mapped[LogSubmission] = relationship(back_populates="issues")


class CrossCheckConflict(Base):
    __tablename__ = "cross_check_conflicts"
    __table_args__ = (Index("ix_conflicts_contest_status_type", "contest_id", "status", "type"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    contest_id: Mapped[int] = mapped_column(ForeignKey("contests.id"))
    qso_id: Mapped[int] = mapped_column(ForeignKey("qso.id"))
    candidate_qso_id: Mapped[int | None] = mapped_column(ForeignKey("qso.id"), nullable=True)
    type: Mapped[ConflictType] = enum_column(ConflictType)
    severity: Mapped[IssueSeverity] = enum_column(IssueSeverity, IssueSeverity.BLOCKING)
    status: Mapped[ConflictStatus] = enum_column(ConflictStatus, ConflictStatus.OPEN)
    detected_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    details: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    qso: Mapped[QSO] = relationship(foreign_keys=[qso_id])
    candidate_qso: Mapped[QSO | None] = relationship(foreign_keys=[candidate_qso_id])
    decisions: Mapped[list["JudgeDecision"]] = relationship(back_populates="conflict")


class MatchingDecision(Base):
    __tablename__ = "matching_decisions"
    __table_args__ = (
        UniqueConstraint("idempotency_key", name="uq_matching_decisions_idempotency_key"),
        Index("ix_matching_decisions_qso", "qso_id", "status"),
        Index("ix_matching_decisions_contest_bucket", "contest_id", "time_bucket"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    contest_id: Mapped[int] = mapped_column(ForeignKey("contests.id"))
    qso_id: Mapped[int] = mapped_column(ForeignKey("qso.id"))
    candidate_qso_id: Mapped[int | None] = mapped_column(ForeignKey("qso.id"), nullable=True)
    conflict_id: Mapped[int | None] = mapped_column(ForeignKey("cross_check_conflicts.id"), nullable=True)
    status: Mapped[MatchingDecisionStatus] = enum_column(MatchingDecisionStatus)
    confidence: Mapped[int] = mapped_column(Integer, default=0)
    stage: Mapped[str] = mapped_column(String(64))
    time_bucket: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    idempotency_key: Mapped[str] = mapped_column(String(255))
    details: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    decided_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)

    qso: Mapped[QSO] = relationship(foreign_keys=[qso_id])
    candidate_qso: Mapped[QSO | None] = relationship(foreign_keys=[candidate_qso_id])
    conflict: Mapped[CrossCheckConflict | None] = relationship()


class JudgeDecision(Base):
    __tablename__ = "judge_decisions"

    id: Mapped[int] = mapped_column(primary_key=True)
    conflict_id: Mapped[int] = mapped_column(ForeignKey("cross_check_conflicts.id"))
    judge_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    decision: Mapped[JudgeDecisionType] = enum_column(JudgeDecisionType)
    comment: Mapped[str] = mapped_column(Text)
    score_impact: Mapped[int] = mapped_column(Integer, default=0)
    metadata_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)

    conflict: Mapped[CrossCheckConflict] = relationship(back_populates="decisions")
    judge: Mapped[User] = relationship()


class ScoringResult(Base):
    __tablename__ = "scoring_results"
    __table_args__ = (
        UniqueConstraint("participant_id", "contest_id", name="uq_scoring_participant_contest"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("participants.id"))
    contest_id: Mapped[int] = mapped_column(ForeignKey("contests.id"))
    claimed_score_from_file: Mapped[int | None] = mapped_column(Integer)
    system_claimed_score: Mapped[int] = mapped_column(Integer, default=0)
    final_score: Mapped[int | None] = mapped_column(Integer)
    confirmed_qso_count: Mapped[int] = mapped_column(Integer, default=0)
    rejected_qso_count: Mapped[int] = mapped_column(Integer, default=0)
    duplicate_qso_count: Mapped[int] = mapped_column(Integer, default=0)
    multiplier_count: Mapped[int] = mapped_column(Integer, default=0)
    penalty_points: Mapped[int] = mapped_column(Integer, default=0)
    calculated_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)

    participant: Mapped[Participant] = relationship()


class PublicResult(Base):
    __tablename__ = "public_results"

    id: Mapped[int] = mapped_column(primary_key=True)
    contest_id: Mapped[int] = mapped_column(ForeignKey("contests.id"))
    participant_id: Mapped[int] = mapped_column(ForeignKey("participants.id"))
    rank_overall: Mapped[int | None] = mapped_column(Integer)
    rank_in_category: Mapped[int] = mapped_column(Integer)
    callsign: Mapped[str] = mapped_column(String(32))
    category: Mapped[str] = mapped_column(String(64))
    claimed_score: Mapped[int] = mapped_column(Integer, default=0)
    final_score: Mapped[int] = mapped_column(Integer, default=0)
    confirmed_qso_count: Mapped[int] = mapped_column(Integer, default=0)
    removed_qso_count: Mapped[int] = mapped_column(Integer, default=0)
    published_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class ProcessingJob(Base):
    __tablename__ = "processing_jobs"
    __table_args__ = (
        Index("ix_jobs_contest_type_status", "contest_id", "type", "status"),
        Index("ix_jobs_submission_status", "submission_id", "status"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    contest_id: Mapped[int | None] = mapped_column(ForeignKey("contests.id"), nullable=True)
    submission_id: Mapped[int | None] = mapped_column(
        ForeignKey("log_submissions.id"), nullable=True
    )
    type: Mapped[ProcessingJobType] = enum_column(ProcessingJobType)
    status: Mapped[ProcessingJobStatus] = enum_column(
        ProcessingJobStatus, ProcessingJobStatus.QUEUED
    )
    started_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    started_at_utc: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    finished_at_utc: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    summary: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    error_message: Mapped[str | None] = mapped_column(Text)

    submission: Mapped[LogSubmission | None] = relationship(back_populates="processing_jobs")


class AuditEvent(Base):
    __tablename__ = "audit_events"
    __table_args__ = (
        Index("ix_audit_actor_timestamp", "actor_id", "timestamp_utc"),
        Index("ix_audit_target", "target_type", "target_id"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    actor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    action: Mapped[str] = mapped_column(String(128))
    target_type: Mapped[str] = mapped_column(String(128))
    target_id: Mapped[int | None] = mapped_column(Integer)
    timestamp_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    metadata_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
