from dataclasses import dataclass
from datetime import UTC

from app.domain import IssueSeverity, ValidationIssueType
from app.models import Contest
from app.modules.cabrillo.parser import ParsedCabrillo
from app.modules.cross_check.normalization import normalize_callsign, normalize_exchange


@dataclass(slots=True)
class IssueCandidate:
    type: ValidationIssueType
    severity: IssueSeverity
    message: str
    line_number: int | None = None


def validate_cabrillo(content: str, parsed: ParsedCabrillo, contest: Contest) -> list[IssueCandidate]:
    issues: list[IssueCandidate] = []
    if not content.strip():
        return [
            IssueCandidate(
                ValidationIssueType.FILE_EMPTY,
                IssueSeverity.BLOCKING,
                "File is empty.",
            )
        ]

    if "CALLSIGN" not in parsed.headers:
        issues.append(
            IssueCandidate(
                ValidationIssueType.MISSING_REQUIRED_HEADER,
                IssueSeverity.BLOCKING,
                "Required CALLSIGN header is missing.",
            )
        )

    if not parsed.qso_records:
        issues.append(
            IssueCandidate(
                ValidationIssueType.MISSING_QSO_LINES,
                IssueSeverity.BLOCKING,
                "File must contain at least one QSO line.",
            )
        )

    for line_number, raw_line in parsed.invalid_qso_lines:
        issues.append(
            IssueCandidate(
                ValidationIssueType.INVALID_QSO_FORMAT,
                IssueSeverity.BLOCKING,
                f"Invalid QSO format: {raw_line}",
                line_number,
            )
        )

    seen_keys: set[tuple[object, ...]] = set()
    contest_start = contest.start_at_utc
    contest_end = contest.end_at_utc
    if contest_start.tzinfo is None:
        contest_start = contest_start.replace(tzinfo=UTC)
    if contest_end.tzinfo is None:
        contest_end = contest_end.replace(tzinfo=UTC)
    for qso in parsed.qso_records:
        if qso.qso_at_utc < contest_start or qso.qso_at_utc > contest_end:
            issues.append(
                IssueCandidate(
                    ValidationIssueType.QSO_OUT_OF_CONTEST_TIME,
                    IssueSeverity.BLOCKING,
                    "QSO is outside contest time boundaries.",
                    qso.line_number,
                )
            )
        if contest.allowed_bands and qso.band.upper() not in {band.upper() for band in contest.allowed_bands}:
            issues.append(
                IssueCandidate(
                    ValidationIssueType.UNSUPPORTED_BAND,
                    IssueSeverity.WARNING,
                    f"Band {qso.band} is not configured for this contest.",
                    qso.line_number,
                )
            )
        if contest.allowed_modes and qso.mode.upper() not in {mode.upper() for mode in contest.allowed_modes}:
            issues.append(
                IssueCandidate(
                    ValidationIssueType.UNSUPPORTED_MODE,
                    IssueSeverity.WARNING,
                    f"Mode {qso.mode} is not configured for this contest.",
                    qso.line_number,
                )
            )
        if contest.scoring_rule and contest.scoring_rule.required_exchange_fields:
            normalized_received = normalize_exchange(qso.received_exchange)
            received_parts = normalized_received.split() if normalized_received else []
            if len(received_parts) < len(contest.scoring_rule.required_exchange_fields):
                issues.append(
                    IssueCandidate(
                        ValidationIssueType.MISSING_EXCHANGE,
                        IssueSeverity.BLOCKING,
                        "Required received exchange fields are missing.",
                        qso.line_number,
                    )
                )
        duplicate_policy = contest.scoring_rule.duplicate_policy if contest.scoring_rule else "same_band_mode"
        candidate_duplicate_key = validation_duplicate_key(qso, duplicate_policy)
        if candidate_duplicate_key is not None and candidate_duplicate_key in seen_keys:
            issues.append(
                IssueCandidate(
                    ValidationIssueType.DUPLICATE_QSO_IN_FILE,
                    IssueSeverity.WARNING,
                    "Duplicate QSO in this submission.",
                    qso.line_number,
                )
            )
        if candidate_duplicate_key is not None:
            seen_keys.add(candidate_duplicate_key)

    return issues


def validation_duplicate_key(qso: object, policy: str) -> tuple[object, ...] | None:
    normalized_policy = (policy or "same_band_mode").lower()
    if normalized_policy in {"ignore", "none"}:
        return None
    callsign = normalize_callsign(qso.counterparty_callsign)
    if normalized_policy == "same_callsign":
        return (callsign,)
    if normalized_policy == "same_band":
        return (callsign, qso.band.upper())
    return (callsign, qso.band.upper(), qso.mode.upper())


def has_blocking_issues(issues: list[IssueCandidate]) -> bool:
    return any(issue.severity == IssueSeverity.BLOCKING for issue in issues)
