"""Lightweight observability helpers for API and worker instrumentation."""
