from collections import defaultdict
from collections.abc import Mapping
from threading import Lock

_lock = Lock()
_counters: dict[str, float] = defaultdict(float)
_observations: dict[str, list[float]] = defaultdict(list)


def _key(name: str, labels: Mapping[str, object] | None = None) -> str:
    if not labels:
        return name
    label_text = ",".join(f'{label}="{value}"' for label, value in sorted(labels.items()))
    return f"{name}{{{label_text}}}"


def increment(name: str, value: float = 1, labels: Mapping[str, object] | None = None) -> None:
    with _lock:
        _counters[_key(name, labels)] += value


def observe(name: str, value: float, labels: Mapping[str, object] | None = None) -> None:
    with _lock:
        bucket = _observations[_key(name, labels)]
        bucket.append(value)
        if len(bucket) > 1024:
            del bucket[: len(bucket) - 1024]


def snapshot() -> dict[str, object]:
    with _lock:
        observations = {
            name: {
                "count": len(values),
                "min": min(values) if values else 0,
                "max": max(values) if values else 0,
                "avg": sum(values) / len(values) if values else 0,
            }
            for name, values in _observations.items()
        }
        return {"counters": dict(_counters), "observations": observations}


def prometheus_text() -> str:
    data = snapshot()
    lines: list[str] = []
    for name, value in data["counters"].items():
        lines.append(f"{name} {value}")
    for name, summary in data["observations"].items():
        if not isinstance(summary, dict):
            continue
        lines.append(f"{name}_count {summary['count']}")
        lines.append(f"{name}_avg {summary['avg']}")
        lines.append(f"{name}_max {summary['max']}")
    return "\n".join(lines) + "\n"
