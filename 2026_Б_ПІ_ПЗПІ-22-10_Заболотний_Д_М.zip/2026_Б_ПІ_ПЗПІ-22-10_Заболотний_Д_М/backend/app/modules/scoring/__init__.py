"""Scoring module."""
