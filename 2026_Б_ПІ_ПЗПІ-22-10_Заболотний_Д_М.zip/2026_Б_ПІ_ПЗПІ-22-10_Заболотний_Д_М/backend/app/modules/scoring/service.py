from sqlalchemy import select
from sqlalchemy.orm import Session

from app.domain import QsoCheckStatus
from app.models import QSO, Contest, LogSubmission, Participant, ScoringResult, utc_now


def calculate_claimed_score(db: Session, participant: Participant, submission: LogSubmission) -> ScoringResult:
    qso_points = participant.contest.scoring_rule.qso_points if participant.contest.scoring_rule else 1
    qso_count = len(submission.qso_records)
    claimed_from_file = None
    raw_claimed = submission.parsed_metadata.get("CLAIMED-SCORE")
    if raw_claimed and str(raw_claimed).isdigit():
        claimed_from_file = int(raw_claimed)
    result = db.scalar(
        select(ScoringResult).where(
            ScoringResult.participant_id == participant.id,
            ScoringResult.contest_id == participant.contest_id,
        )
    )
    if result is None:
        result = ScoringResult(participant_id=participant.id, contest_id=participant.contest_id)
        db.add(result)
    result.claimed_score_from_file = claimed_from_file
    result.system_claimed_score = qso_count * qso_points
    result.final_score = result.system_claimed_score
    result.confirmed_qso_count = qso_count
    result.rejected_qso_count = 0
    result.duplicate_qso_count = 0
    result.penalty_points = 0
    return result


def recalculate_final_score(db: Session, participant: Participant) -> ScoringResult:
    qso_points = participant.contest.scoring_rule.qso_points if participant.contest.scoring_rule else 1
    qso_records = list(
        db.scalars(
            select(QSO).join(LogSubmission).where(
                LogSubmission.id == participant.current_submission_id,
                LogSubmission.participant_id == participant.id,
            )
        )
    )
    confirmed = [qso for qso in qso_records if qso.check_status == QsoCheckStatus.CONFIRMED]
    rejected = [qso for qso in qso_records if qso.check_status == QsoCheckStatus.REJECTED]
    duplicates = [qso for qso in qso_records if qso.check_status == QsoCheckStatus.DUPLICATE]
    result = db.scalar(
        select(ScoringResult).where(
            ScoringResult.participant_id == participant.id,
            ScoringResult.contest_id == participant.contest_id,
        )
    )
    if result is None:
        result = ScoringResult(participant_id=participant.id, contest_id=participant.contest_id)
        db.add(result)
    result.confirmed_qso_count = len(confirmed)
    result.rejected_qso_count = len(rejected)
    result.duplicate_qso_count = len(duplicates)
    result.final_score = max(len(confirmed) * qso_points - (result.penalty_points or 0), 0)
    result.calculated_at_utc = utc_now()
    return result


def recalculate_contest_scores(db: Session, contest: Contest) -> int:
    participants = list(
        db.scalars(
            select(Participant).where(
                Participant.contest_id == contest.id,
                Participant.current_submission_id.is_not(None),
            )
        ).all()
    )
    for participant in participants:
        recalculate_final_score(db, participant)
    return len(participants)
