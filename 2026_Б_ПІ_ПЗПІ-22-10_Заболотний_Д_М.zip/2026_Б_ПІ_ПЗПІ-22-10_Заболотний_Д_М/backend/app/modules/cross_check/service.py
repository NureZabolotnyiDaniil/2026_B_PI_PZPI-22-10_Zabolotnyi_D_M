import json
from datetime import timedelta

from sqlalchemy import delete, select, update
from sqlalchemy.orm import Session

from app.domain import (
    ConflictStatus,
    ConflictType,
    IssueSeverity,
    MatchingDecisionStatus,
    QsoCheckStatus,
)
from app.models import (
    QSO,
    Contest,
    CrossCheckConflict,
    JudgeDecision,
    MatchingDecision,
    Participant,
)
from app.modules.cross_check.index import upsert_candidate_index
from app.modules.cross_check.matching import _summarize_score, resolve_matching_pipeline
from app.modules.cross_check.normalization import normalize_exchange
from app.modules.cross_check.retrieval import find_candidate_matches
from app.modules.cross_check.rules import duplicate_key, matching_rules
from app.modules.observability.metrics import increment
from app.modules.scoring.service import recalculate_contest_scores


def run_cross_check(
    write_db: Session,
    contest: Contest,
    *,
    read_db: Session | None = None,
    cache_client: object | None = None,
    cache_ttl_seconds: int = 180,
    include_details: bool = False,
) -> (
    dict[str, int]
    | tuple[dict[str, int], list[CrossCheckConflict], list[dict[str, object]]]
):
    db = read_db or write_db
    current_submission_ids = [
        submission_id
        for submission_id in db.scalars(
            select(Participant.current_submission_id).where(
                Participant.contest_id == contest.id,
                Participant.current_submission_id.is_not(None),
            )
        )
        if submission_id is not None
    ]
    cache_key = f"contest:{contest.id}:bucket:{hash(tuple(sorted(current_submission_ids)))}"
    qso_records: list[QSO] | None = None
    if cache_client:
        cached_qso_ids = cache_client.get(cache_key)
        if cached_qso_ids:
            qso_records = list(
                db.scalars(
                    select(QSO).where(QSO.id.in_(json.loads(cached_qso_ids))).order_by(QSO.id.asc())
                ).all()
            )
    if qso_records is None:
        qso_records = list(
            db.scalars(
                select(QSO).where(
                    QSO.contest_id == contest.id,
                    QSO.submission_id.in_(current_submission_ids),
                ).order_by(QSO.id.asc())
            ).all()
        )
        if cache_client:
            cache_client.setex(cache_key, cache_ttl_seconds, json.dumps([qso.id for qso in qso_records]))
    created_conflicts = 0
    matched = 0
    created_conflict_refs: list[CrossCheckConflict] = []
    reasoning_log: list[dict[str, object]] = []

    for qso in qso_records:
        writable_qso = write_db.get(QSO, qso.id)
        if writable_qso is not None:
            upsert_candidate_index(write_db, writable_qso)
    write_db.flush()

    for qso in qso_records:
        summary_item, conflict, reasoning = match_qso(
            write_db,
            contest,
            qso.id,
            read_db=write_db,
            cache_client=cache_client,
            cache_ttl_seconds=cache_ttl_seconds,
        )
        if summary_item["matched"]:
            matched += 1
        if conflict is not None:
            created_conflict_refs.append(conflict)
            created_conflicts += 1
        reasoning_log.append(reasoning)

    write_db.flush()
    scores_recalculated = recalculate_contest_scores(write_db, contest)

    summary = {
        "qso_checked": len(qso_records),
        "matched": matched,
        "conflicts": created_conflicts,
        "scores_recalculated": scores_recalculated,
    }
    if include_details:
        return summary, created_conflict_refs, reasoning_log
    return summary


def match_qso(
    write_db: Session,
    contest: Contest,
    qso_id: int,
    *,
    read_db: Session | None = None,
    cache_client: object | None = None,
    cache_ttl_seconds: int = 180,
) -> tuple[dict[str, int], CrossCheckConflict | None, dict[str, object]]:
    del cache_client, cache_ttl_seconds
    db = read_db or write_db
    qso = db.get(QSO, qso_id)
    if qso is None:
        return {"checked": 0, "matched": 0, "conflicts": 0}, None, {"qso_id": qso_id, "result": "missing"}

    writable_qso = write_db.get(QSO, qso_id)
    if writable_qso is None:
        return {"checked": 0, "matched": 0, "conflicts": 0}, None, {"qso_id": qso_id, "result": "missing"}

    upsert_candidate_index(write_db, writable_qso)
    write_db.flush()
    qso_conflict_ids = select(CrossCheckConflict.id).where(CrossCheckConflict.qso_id == qso_id)
    write_db.execute(delete(JudgeDecision).where(JudgeDecision.conflict_id.in_(qso_conflict_ids)))
    write_db.execute(
        update(MatchingDecision)
        .where(MatchingDecision.qso_id == qso_id)
        .values(conflict_id=None)
    )
    write_db.execute(delete(CrossCheckConflict).where(CrossCheckConflict.qso_id == qso_id))

    rules = matching_rules(contest)
    duplicate = find_duplicate_qso(write_db, writable_qso, rules.duplicate_policy)
    if duplicate is not None:
        conflict = CrossCheckConflict(
            contest_id=contest.id,
            qso_id=writable_qso.id,
            candidate_qso_id=duplicate.id,
            type=ConflictType.DUPLICATE_QSO,
            severity=IssueSeverity.WARNING,
            status=ConflictStatus.AUTO_RESOLVED,
            details={
                "confidence": 1.0,
                "confidence_label": "high",
                "reasoning": ["Duplicate key in same submission"],
                "stage": "duplicate_detection",
                "lifecycle": "resolved",
                "duplicate_policy": rules.duplicate_policy,
            },
        )
        write_db.add(conflict)
        writable_qso.check_status = QsoCheckStatus.DUPLICATE
        writable_qso.matched_qso_id = duplicate.id
        write_db.flush()
        decision = record_matching_decision(
            write_db,
            qso=writable_qso,
            candidate=duplicate,
            conflict=conflict,
            status=MatchingDecisionStatus.DUPLICATE,
            confidence=10000,
            stage="duplicate_detection",
            details=conflict.details,
        )
        reasoning = {
            "qso_id": writable_qso.id,
            "candidate_qso_id": duplicate.id,
            "decision_id": decision.id,
            "result": ConflictType.DUPLICATE_QSO.value,
            "confidence": 1.0,
            "reasoning": conflict.details["reasoning"],
        }
        return {"checked": 1, "matched": 0, "conflicts": 1}, conflict, reasoning

    search_result = find_candidate_matches(db, contest, qso)
    candidates = search_result.candidates
    resolution = resolve_matching_pipeline(qso, candidates, contest)
    retrieval_details = {
        "candidate_count": search_result.diagnostics.candidate_count,
        "retrieval_strategy": search_result.diagnostics.strategy,
        "retrieval_elapsed_ms": search_result.diagnostics.elapsed_ms,
        "fallback_triggered": search_result.diagnostics.fallback_triggered,
        "relaxed_dimensions_merged": search_result.diagnostics.relaxed_dimensions_merged,
        "relaxed_extra_count": search_result.diagnostics.relaxed_extra_count,
        "fuzzy_neighborhood_merged": search_result.diagnostics.fuzzy_neighborhood_merged,
        "fuzzy_neighborhood_count": search_result.diagnostics.fuzzy_neighborhood_count,
        "bucket_count": search_result.diagnostics.bucket_count,
        "candidate_limit": search_result.diagnostics.limit,
        "retrieval_notes": search_result.diagnostics.notes,
    }

    export_n = max(rules.matching_candidate_export_limit, 5)
    sorted_candidates = sorted(
        resolution.all_scored,
        key=lambda sc: (-sc.confidence, abs((sc.qso.qso_at_utc - qso.qso_at_utc).total_seconds()), sc.qso.id),
    )
    matching_candidates = [_summarize_score(s, qso) for s in sorted_candidates[:export_n]]

    explainability = {
        **resolution.explainability,
        "matching_status": resolution.matching_status.value,
        "probable_typo": resolution.probable_typo,
        "pipeline_decision": resolution.pipeline_decision,
    }

    if resolution.outcome == "confirmed" and resolution.primary is not None:
        best = resolution.primary
        writable_qso.check_status = QsoCheckStatus.CONFIRMED
        writable_qso.matched_qso_id = best.qso.id
        decision = record_matching_decision(
            write_db,
            qso=writable_qso,
            candidate=best.qso,
            conflict=None,
            status=MatchingDecisionStatus.CONFIRMED,
            confidence=best.confidence,
            stage=best.stage,
            details={
                "reasoning": best.reasoning,
                "score_breakdown": best.breakdown,
                "retrieval": retrieval_details,
                "lifecycle": "matched",
                "explainability": explainability,
                "matching_candidates": matching_candidates,
            },
        )
        reasoning = {
            "qso_id": writable_qso.id,
            "matched_qso_id": best.qso.id,
            "decision_id": decision.id,
            "result": "confirmed",
            "confidence": best.confidence / 10000,
            "reasoning": best.reasoning,
            "retrieval": retrieval_details,
            "explainability": explainability,
            "pipeline_decision": resolution.pipeline_decision,
        }
        increment("matching_confirmed_total", labels={"stage": best.stage})
        return {"checked": 1, "matched": 1, "conflicts": 0}, None, reasoning

    conflict_type = resolution.conflict_type or ConflictType.NIL
    candidate = resolution.primary.qso if resolution.primary else None
    confidence = resolution.primary.confidence if resolution.primary else 0
    reasoning_items = list(explainability.get("reasoning", []))
    if resolution.outcome == "no_match":
        writable_qso.check_status = QsoCheckStatus.NO_MATCH
        writable_qso.matched_qso_id = None
    elif resolution.outcome == "ambiguous":
        writable_qso.check_status = QsoCheckStatus.AMBIGUOUS
        writable_qso.matched_qso_id = None
    else:
        writable_qso.check_status = QsoCheckStatus.CONFLICT
        writable_qso.matched_qso_id = candidate.id if candidate else None

    conflict = CrossCheckConflict(
        contest_id=contest.id,
        qso_id=writable_qso.id,
        candidate_qso_id=candidate.id if candidate else None,
        type=conflict_type,
        severity=IssueSeverity.BLOCKING,
        status=ConflictStatus.OPEN,
        details={
            "participant": writable_qso.participant_callsign,
            "counterparty": writable_qso.counterparty_callsign,
            "confidence": confidence / 10000 if candidate else float(explainability.get("confidence", 0.0)),
            "confidence_label": confidence_label_from_float(
                (confidence / 10000) if candidate else float(explainability.get("confidence", 0.0))
            ),
            "reasoning": reasoning_items,
            "stage": resolution.primary.stage if resolution.primary else "candidate_search",
            "score_breakdown": resolution.primary.breakdown if resolution.primary else {},
            "retrieval": retrieval_details,
            "lifecycle": "conflict",
            "explainability": explainability,
            "matching_candidates": matching_candidates,
            "probable_typo": resolution.probable_typo,
            "pipeline_decision": resolution.pipeline_decision,
        },
    )
    write_db.add(conflict)
    write_db.flush()

    decision_status = resolution.matching_status
    decision = record_matching_decision(
        write_db,
        qso=writable_qso,
        candidate=candidate,
        conflict=conflict,
        status=decision_status,
        confidence=confidence,
        stage=resolution.primary.stage if resolution.primary else "candidate_search",
        details=conflict.details,
    )
    reasoning = {
        "qso_id": writable_qso.id,
        "candidate_qso_id": candidate.id if candidate else None,
        "decision_id": decision.id,
        "result": decision_status.value,
        "confidence": confidence / 10000 if confidence else float(explainability.get("confidence", 0.0)),
        "reasoning": reasoning_items,
        "retrieval": retrieval_details,
        "explainability": explainability,
        "pipeline_decision": resolution.pipeline_decision,
    }
    increment(
        "matching_conflict_total",
        labels={
            "type": conflict_type.value,
            "outcome": resolution.outcome,
        },
    )
    return {"checked": 1, "matched": 0, "conflicts": 1}, conflict, reasoning


def confidence_label_from_float(score: float) -> str:
    if score >= 0.95:
        return "high"
    if score >= 0.70:
        return "medium"
    return "low"


def record_matching_decision(
    db: Session,
    *,
    qso: QSO,
    candidate: QSO | None,
    conflict: CrossCheckConflict | None,
    status: MatchingDecisionStatus,
    confidence: int,
    stage: str,
    details: dict[str, object],
) -> MatchingDecision:
    idempotency_key = f"match:{qso.id}:latest"
    decision = db.scalar(
        select(MatchingDecision).where(MatchingDecision.idempotency_key == idempotency_key)
    )
    if decision is None:
        decision = MatchingDecision(
            contest_id=qso.contest_id,
            qso_id=qso.id,
            idempotency_key=idempotency_key,
            time_bucket=qso.time_bucket,
        )
        db.add(decision)
    decision.candidate_qso_id = candidate.id if candidate else None
    decision.conflict_id = conflict.id if conflict else None
    decision.status = status
    decision.confidence = confidence
    decision.stage = stage
    decision.details = details
    db.flush()
    return decision


def find_duplicate_qso(db: Session, qso: QSO, duplicate_policy: str) -> QSO | None:
    key = duplicate_key(qso, duplicate_policy)
    if key is None:
        return None
    query = select(QSO).where(
        QSO.submission_id == qso.submission_id,
        QSO.id != qso.id,
        QSO.counterparty_callsign == qso.counterparty_callsign,
        QSO.line_number < qso.line_number,
    )
    policy = (duplicate_policy or "same_band_mode").lower()
    if policy in {"same_band", "same_band_mode"}:
        query = query.where(QSO.band == qso.band)
    if policy == "same_band_mode":
        query = query.where(QSO.mode == qso.mode)
    return db.scalar(query.order_by(QSO.line_number.asc()))


def classify_conflict(qso: QSO, reciprocal: list[QSO], tolerance: timedelta) -> ConflictType:
    if not reciprocal:
        return ConflictType.NIL
    candidate = reciprocal[0]
    if abs(candidate.qso_at_utc - qso.qso_at_utc) > tolerance:
        return ConflictType.TIME_MISMATCH
    if candidate.band.upper() != qso.band.upper():
        return ConflictType.BAND_MISMATCH
    if candidate.mode.upper() != qso.mode.upper():
        return ConflictType.MODE_MISMATCH
    if not exchanges_match(qso, candidate):
        return ConflictType.EXCHANGE_MISMATCH
    return ConflictType.BUSTED_CALL


def exchanges_match(qso: QSO, candidate: QSO) -> bool:
    return normalize_exchange(qso.sent_exchange) == normalize_exchange(
        candidate.received_exchange
    ) and normalize_exchange(qso.received_exchange) == normalize_exchange(candidate.sent_exchange)


def build_conflict_reasoning(qso: QSO, reciprocal: list[QSO], tolerance: timedelta) -> list[str]:
    if not reciprocal:
        return ["No reciprocal QSO found in participant logs"]
    candidate = reciprocal[0]
    reasons = ["Reciprocal callsign found"]
    delta_seconds = abs(int((candidate.qso_at_utc - qso.qso_at_utc).total_seconds()))
    reasons.append(f"Timestamp delta = {delta_seconds}s (tolerance={int(tolerance.total_seconds())}s)")
    if candidate.band.upper() != qso.band.upper():
        reasons.append("Band mismatch")
    if candidate.mode.upper() != qso.mode.upper():
        reasons.append("Mode mismatch")
    if not exchanges_match(qso, candidate):
        reasons.append("Exchange mismatch")
    return reasons
