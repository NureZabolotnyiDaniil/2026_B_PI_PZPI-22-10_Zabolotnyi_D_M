from dataclasses import dataclass

from app.models import QSO, Contest


@dataclass(frozen=True)
class MatchingRules:
    time_tolerance_minutes: int = 5
    fuzzy_callsign_distance: int = 1
    candidate_limit: int = 250
    fallback_candidate_limit: int = 500
    # Secondary retrieval: widen index query (ignore band/mode) for typo/logging-error recovery.
    retrieval_relax_band_mode: bool = True
    relax_band_mode_candidate_limit: int = 200
    # Top-N reciprocal candidates surfaced to judges / explainability.
    matching_candidate_export_limit: int = 15
    duplicate_policy: str = "same_band_mode"
    weights: dict[str, float] | None = None
    # Soft credit when band/mode differ but callsign reciprocal is a typo match (typo-recovery lane).
    soft_band_score: float = 0.42
    soft_mode_score: float = 0.42
    # Extra credit when reciprocal callsign typo is keyboard-adjacent (0..1 add-on applied before clamp).
    keyboard_adjacency_typo_bonus: float = 0.04
    # Confidence thresholds on 0..1 scale (stored as 0..10000 ints elsewhere).
    confidence_auto_accept: float = 0.95
    confidence_medium: float = 0.70
    # If top two candidates in the same tier differ by at most this many "confidence units"
    # (out of 10000), treat as AMBIGUOUS — deterministic tie-breaker refuses to guess.
    ambiguity_score_gap: int = 200
    # Small deterministic boost when fuzzy match aligns on indexed prefix (contest locality).
    region_prefix_match_bonus: float = 0.05


DEFAULT_WEIGHTS = {
    "callsign": 0.50,
    "time": 0.20,
    "band": 0.10,
    "mode": 0.10,
    "exchange": 0.10,
}


def matching_rules(contest: Contest) -> MatchingRules:
    scoring_rule = contest.scoring_rule
    policy = scoring_rule.penalty_policy if scoring_rule and scoring_rule.penalty_policy else {}
    matching_policy = policy.get("matching", {}) if isinstance(policy, dict) else {}
    weights = matching_policy.get("weights") if isinstance(matching_policy, dict) else None
    return MatchingRules(
        time_tolerance_minutes=max(
            int(scoring_rule.time_tolerance_minutes) if scoring_rule else 5,
            1,
        ),
        fuzzy_callsign_distance=int(matching_policy.get("fuzzy_callsign_distance", 1))
        if isinstance(matching_policy, dict)
        else 1,
        candidate_limit=int(matching_policy.get("candidate_limit", 250))
        if isinstance(matching_policy, dict)
        else 250,
        fallback_candidate_limit=int(matching_policy.get("fallback_candidate_limit", 500))
        if isinstance(matching_policy, dict)
        else 500,
        retrieval_relax_band_mode=bool(matching_policy.get("retrieval_relax_band_mode", True))
        if isinstance(matching_policy, dict)
        else True,
        relax_band_mode_candidate_limit=int(matching_policy.get("relax_band_mode_candidate_limit", 200))
        if isinstance(matching_policy, dict)
        else 200,
        matching_candidate_export_limit=int(matching_policy.get("matching_candidate_export_limit", 15))
        if isinstance(matching_policy, dict)
        else 15,
        duplicate_policy=scoring_rule.duplicate_policy if scoring_rule else "same_band_mode",
        weights=weights if isinstance(weights, dict) else DEFAULT_WEIGHTS,
        confidence_auto_accept=float(matching_policy.get("confidence_auto_accept", 0.95))
        if isinstance(matching_policy, dict)
        else 0.95,
        confidence_medium=float(matching_policy.get("confidence_medium", 0.70))
        if isinstance(matching_policy, dict)
        else 0.70,
        ambiguity_score_gap=int(matching_policy.get("ambiguity_score_gap", 200))
        if isinstance(matching_policy, dict)
        else 200,
        region_prefix_match_bonus=float(matching_policy.get("region_prefix_match_bonus", 0.05))
        if isinstance(matching_policy, dict)
        else 0.05,
        soft_band_score=float(matching_policy.get("soft_band_score", 0.42))
        if isinstance(matching_policy, dict)
        else 0.42,
        soft_mode_score=float(matching_policy.get("soft_mode_score", 0.42))
        if isinstance(matching_policy, dict)
        else 0.42,
        keyboard_adjacency_typo_bonus=float(matching_policy.get("keyboard_adjacency_typo_bonus", 0.04))
        if isinstance(matching_policy, dict)
        else 0.04,
    )


def duplicate_key(qso: QSO, policy: str) -> tuple[object, ...] | None:
    normalized_policy = (policy or "same_band_mode").lower()
    if normalized_policy in {"ignore", "none"}:
        return None
    if normalized_policy == "same_band":
        return (qso.submission_id, qso.counterparty_callsign.upper(), qso.band.upper())
    if normalized_policy == "same_callsign":
        return (qso.submission_id, qso.counterparty_callsign.upper())
    return (
        qso.submission_id,
        qso.counterparty_callsign.upper(),
        qso.band.upper(),
        qso.mode.upper(),
    )
