from dataclasses import dataclass
from datetime import datetime, timedelta
from random import Random


@dataclass(frozen=True)
class SyntheticQso:
    participant_callsign: str
    counterparty_callsign: str
    qso_at_utc: datetime
    band: str
    mode: str
    sent_exchange: str
    received_exchange: str
    scenario: str


@dataclass(frozen=True)
class SyntheticContest:
    qso_records: list[SyntheticQso]
    scenario_counts: dict[str, int]


def generate_synthetic_contest(
    *,
    qso_count: int,
    start_at_utc: datetime,
    seed: int = 1,
    exact_rate: float = 0.82,
    busted_call_rate: float = 0.05,
    time_mismatch_rate: float = 0.04,
    exchange_mismatch_rate: float = 0.04,
    duplicate_rate: float = 0.02,
) -> SyntheticContest:
    rng = Random(seed)
    bands = ["80M", "40M", "20M", "15M", "10M"]
    modes = ["CW", "SSB"]
    records: list[SyntheticQso] = []
    scenario_counts: dict[str, int] = {}
    pair_count = max(qso_count // 2, 1)

    for index in range(pair_count):
        scenario = _scenario(
            rng.random(),
            exact_rate=exact_rate,
            busted_call_rate=busted_call_rate,
            time_mismatch_rate=time_mismatch_rate,
            exchange_mismatch_rate=exchange_mismatch_rate,
            duplicate_rate=duplicate_rate,
        )
        scenario_counts[scenario] = scenario_counts.get(scenario, 0) + 2
        call_a = f"UT{index % 10}{index:04d}"
        call_b = f"UR{(index + 3) % 10}{index:04d}"
        qso_at = start_at_utc + timedelta(seconds=index * 17)
        band = bands[index % len(bands)]
        mode = modes[index % len(modes)]
        sent_a = f"599 {index % 999:03d}"
        sent_b = f"599 {(index + 1) % 999:03d}"
        candidate_call_b = _bust_callsign(call_b) if scenario == "busted_call" else call_b
        candidate_time = qso_at + (timedelta(minutes=15) if scenario == "time_mismatch" else timedelta(seconds=rng.randint(-20, 20)))
        candidate_exchange = "599 000" if scenario == "exchange_mismatch" else sent_a

        records.append(
            SyntheticQso(call_a, call_b, qso_at, band, mode, sent_a, sent_b, scenario)
        )
        records.append(
            SyntheticQso(candidate_call_b, call_a, candidate_time, band, mode, sent_b, candidate_exchange, scenario)
        )
        if scenario == "duplicate":
            records.append(
                SyntheticQso(call_a, call_b, qso_at + timedelta(seconds=3), band, mode, sent_a, sent_b, scenario)
            )

    return SyntheticContest(qso_records=records[:qso_count], scenario_counts=scenario_counts)


def _scenario(
    roll: float,
    *,
    exact_rate: float,
    busted_call_rate: float,
    time_mismatch_rate: float,
    exchange_mismatch_rate: float,
    duplicate_rate: float,
) -> str:
    if roll < exact_rate:
        return "exact"
    roll -= exact_rate
    if roll < busted_call_rate:
        return "busted_call"
    roll -= busted_call_rate
    if roll < time_mismatch_rate:
        return "time_mismatch"
    roll -= time_mismatch_rate
    if roll < exchange_mismatch_rate:
        return "exchange_mismatch"
    roll -= exchange_mismatch_rate
    if roll < duplicate_rate:
        return "duplicate"
    return "nil"


def _bust_callsign(callsign: str) -> str:
    if len(callsign) < 3:
        return callsign + "A"
    replacement = "I" if callsign[2] != "I" else "1"
    return callsign[:2] + replacement + callsign[3:]
