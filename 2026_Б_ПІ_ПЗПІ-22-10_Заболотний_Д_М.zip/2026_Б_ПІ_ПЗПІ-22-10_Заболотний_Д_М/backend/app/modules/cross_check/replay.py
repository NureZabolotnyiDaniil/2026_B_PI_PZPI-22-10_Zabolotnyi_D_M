from dataclasses import dataclass

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.models import (
    QSO,
    Contest,
    CrossCheckConflict,
    JudgeDecision,
    MatchingDecision,
    Participant,
)
from app.modules.cross_check.index import rebuild_candidate_index_for_submission
from app.modules.cross_check.service import run_cross_check


@dataclass(frozen=True)
class ReplaySummary:
    submissions_reindexed: int
    qso_reindexed: int
    decisions_deleted: int
    conflicts_deleted: int
    matching_summary: dict[str, int]


def replay_contest_matching(db: Session, contest: Contest) -> ReplaySummary:
    submission_ids = [
        submission_id
        for submission_id in db.scalars(
            select(Participant.current_submission_id).where(
                Participant.contest_id == contest.id,
                Participant.current_submission_id.is_not(None),
            )
        )
        if submission_id is not None
    ]
    qso_ids = list(
        db.scalars(
            select(QSO.id).where(
                QSO.contest_id == contest.id,
                QSO.submission_id.in_(submission_ids),
            )
        ).all()
    )
    contest_conflict_ids = select(CrossCheckConflict.id).where(CrossCheckConflict.contest_id == contest.id)
    db.execute(delete(JudgeDecision).where(JudgeDecision.conflict_id.in_(contest_conflict_ids)))
    conflicts_deleted = (
        db.execute(delete(CrossCheckConflict).where(CrossCheckConflict.contest_id == contest.id)).rowcount
        or 0
    )
    decisions_deleted = (
        db.execute(delete(MatchingDecision).where(MatchingDecision.contest_id == contest.id)).rowcount
        or 0
    )
    reindexed = 0
    for submission_id in submission_ids:
        reindexed += rebuild_candidate_index_for_submission(db, submission_id)
    db.flush()
    summary = run_cross_check(db, contest)
    return ReplaySummary(
        submissions_reindexed=len(submission_ids),
        qso_reindexed=reindexed or len(qso_ids),
        decisions_deleted=decisions_deleted,
        conflicts_deleted=conflicts_deleted,
        matching_summary=summary,
    )
