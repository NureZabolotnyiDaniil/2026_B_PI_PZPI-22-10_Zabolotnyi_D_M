from dataclasses import dataclass, field

PORTABLE_SUFFIXES = {"P", "M", "MM", "AM", "QRP", "A"}


@dataclass(frozen=True)
class NormalizationConfig:
    callsign_aliases: dict[str, str] = field(default_factory=dict)
    strip_portable_suffixes: bool = True


def normalize_callsign(callsign: str, config: NormalizationConfig | None = None) -> str:
    """Uppercase/strip + optional portable suffix handling."""
    normalized = "".join(callsign.upper().split())
    config = config or NormalizationConfig()
    normalized = config.callsign_aliases.get(normalized, normalized)
    if config.strip_portable_suffixes and "/" in normalized:
        base, suffix = normalized.rsplit("/", 1)
        if suffix in PORTABLE_SUFFIXES and base:
            normalized = base
    return normalized


def callsign_prefix(callsign: str, *, length: int = 3, config: NormalizationConfig | None = None) -> str:
    return normalize_callsign(callsign, config)[:length]


def levenshtein(left: str, right: str) -> int:
    if left == right:
        return 0
    if len(left) < len(right):
        left, right = right, left
    previous = list(range(len(right) + 1))
    for left_index, left_char in enumerate(left, start=1):
        current = [left_index]
        for right_index, right_char in enumerate(right, start=1):
            insertions = previous[right_index] + 1
            deletions = current[right_index - 1] + 1
            substitutions = previous[right_index - 1] + (left_char != right_char)
            current.append(min(insertions, deletions, substitutions))
        previous = current
    return previous[-1]


def swap_adjacent_once_matches(left: str, right: str) -> bool:
    """True if two equal-length strings differ only by swapping one adjacent pair."""
    if left == right or len(left) != len(right) or len(left) < 2:
        return False
    for i in range(len(left) - 1):
        swapped = f"{left[:i]}{left[i + 1]}{left[i]}{left[i + 2:]}"
        if swapped == right:
            return True
    return False


def effective_callsign_distance(left: str, right: str) -> int:
    """Levenshtein distance with a single adjacent transposition counting as one edit."""
    if left == right:
        return 0
    base = levenshtein(left, right)
    if swap_adjacent_once_matches(left, right):
        return min(base, 1)
    return base


def normalize_exchange(exchange: str | None) -> str | None:
    if exchange is None:
        return None
    return " ".join(exchange.upper().split())
