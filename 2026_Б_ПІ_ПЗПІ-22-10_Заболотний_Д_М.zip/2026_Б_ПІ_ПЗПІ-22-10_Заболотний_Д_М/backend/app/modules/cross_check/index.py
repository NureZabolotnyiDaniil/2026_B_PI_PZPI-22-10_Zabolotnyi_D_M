from datetime import datetime

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.models import QSO, QsoCandidateIndex, utc_now
from app.modules.cross_check.normalization import callsign_prefix, normalize_callsign


def qso_time_bucket(qso_at_utc: datetime, *, minutes: int = 5) -> datetime:
    minute = (qso_at_utc.minute // minutes) * minutes
    return qso_at_utc.replace(minute=minute, second=0, microsecond=0)


def populate_qso_index_fields(qso: QSO) -> None:
    qso.normalized_participant_callsign = normalize_callsign(qso.participant_callsign)
    qso.normalized_counterparty_callsign = normalize_callsign(qso.counterparty_callsign)
    qso.participant_prefix = callsign_prefix(qso.participant_callsign)
    qso.counterparty_prefix = callsign_prefix(qso.counterparty_callsign)
    qso.time_bucket = qso_time_bucket(qso.qso_at_utc)


def upsert_candidate_index(db: Session, qso: QSO) -> QsoCandidateIndex:
    populate_qso_index_fields(qso)
    existing = db.scalar(select(QsoCandidateIndex).where(QsoCandidateIndex.qso_id == qso.id))
    if existing is None:
        existing = QsoCandidateIndex(qso_id=qso.id)
        db.add(existing)
    existing.contest_id = qso.contest_id
    existing.submission_id = qso.submission_id
    existing.time_bucket = qso.time_bucket
    existing.band = qso.band.upper()
    existing.mode = qso.mode.upper()
    existing.normalized_participant_callsign = qso.normalized_participant_callsign
    existing.normalized_counterparty_callsign = qso.normalized_counterparty_callsign
    existing.participant_prefix = qso.participant_prefix
    existing.counterparty_prefix = qso.counterparty_prefix
    existing.indexed_at_utc = utc_now()
    return existing


def rebuild_candidate_index_for_submission(db: Session, submission_id: int) -> int:
    db.execute(delete(QsoCandidateIndex).where(QsoCandidateIndex.submission_id == submission_id))
    qso_records = list(db.scalars(select(QSO).where(QSO.submission_id == submission_id)).all())
    for qso in qso_records:
        upsert_candidate_index(db, qso)
    return len(qso_records)
