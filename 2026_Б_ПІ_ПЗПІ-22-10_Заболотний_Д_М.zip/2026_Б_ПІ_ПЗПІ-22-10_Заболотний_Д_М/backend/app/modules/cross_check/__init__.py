"""Cross-check module."""
