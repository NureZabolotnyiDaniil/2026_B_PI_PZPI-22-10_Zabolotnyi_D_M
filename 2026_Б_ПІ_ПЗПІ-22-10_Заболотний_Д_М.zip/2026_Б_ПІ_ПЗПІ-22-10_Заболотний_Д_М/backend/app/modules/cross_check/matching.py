from collections.abc import Sequence
from dataclasses import dataclass
from datetime import timedelta
from typing import Any, Literal

from sqlalchemy.orm import Session

from app.domain import ConflictType, MatchingDecisionStatus
from app.models import QSO, Contest
from app.modules.cross_check.normalization import (
    effective_callsign_distance,
    levenshtein,
    normalize_callsign,
    normalize_exchange,
    swap_adjacent_once_matches,
)
from app.modules.cross_check.retrieval import find_candidate_matches
from app.modules.cross_check.rules import MatchingRules, matching_rules

__all__ = [
    "CandidateScore",
    "MatchResolution",
    "choose_best_candidate",
    "effective_callsign_distance",
    "levenshtein",
    "resolve_matching_pipeline",
    "score_candidate",
]


@dataclass(frozen=True)
class CandidateScore:
    qso: QSO
    stage: str
    confidence: int
    conflict_type: ConflictType | None
    reasoning: list[str]
    breakdown: dict[str, object]


@dataclass(frozen=True)
class MatchResolution:
    """Deterministic outcome of exact → relaxed → fuzzy narrowing."""

    outcome: Literal["confirmed", "ambiguous", "no_match", "conflict"]
    primary: CandidateScore | None
    ordered_tier: list[CandidateScore]
    all_scored: list[CandidateScore]
    matching_status: MatchingDecisionStatus
    conflict_type: ConflictType | None
    probable_typo: bool
    pipeline_decision: str
    explainability: dict[str, Any]


def _build_keyboard_neighbor_map() -> dict[str, set[str]]:
    rows = [
        "1234567890",
        "QWERTYUIOP",
        "ASDFGHJKL",
        "ZXCVBNM",
    ]
    neighbors: dict[str, set[str]] = {}
    for row in rows:
        for index, ch in enumerate(row):
            bucket = neighbors.setdefault(ch, set())
            if index > 0:
                bucket.add(row[index - 1])
            if index + 1 < len(row):
                bucket.add(row[index + 1])
    for row_index, row in enumerate(rows):
        for col_index, ch in enumerate(row):
            bucket = neighbors.setdefault(ch, set())
            if row_index > 0:
                above = rows[row_index - 1]
                if col_index < len(above):
                    bucket.add(above[col_index])
                if col_index > 0 and col_index - 1 < len(above):
                    bucket.add(above[col_index - 1])
                if col_index + 1 < len(above):
                    bucket.add(above[col_index + 1])
            if row_index + 1 < len(rows):
                below = rows[row_index + 1]
                if col_index < len(below):
                    bucket.add(below[col_index])
                if col_index > 0 and col_index - 1 < len(below):
                    bucket.add(below[col_index - 1])
                if col_index + 1 < len(below):
                    bucket.add(below[col_index + 1])
    return neighbors


_KEYBOARD_NEIGHBORS = _build_keyboard_neighbor_map()


def keyboard_substitution_typo_bonus(left: str, right: str, rules: MatchingRules) -> float:
    """Extra credit when the only difference is a single keyboard-adjacent substitution."""
    if len(left) != len(right):
        return 0.0
    diffs = [(a, b) for a, b in zip(left, right, strict=True) if a != b]
    if len(diffs) != 1:
        return 0.0
    a, b = diffs[0]
    if b in _KEYBOARD_NEIGHBORS.get(a, set()) or a in _KEYBOARD_NEIGHBORS.get(b, set()):
        return float(rules.keyboard_adjacency_typo_bonus)
    return 0.0


def exchanges_match(qso: QSO, candidate: QSO) -> bool:
    return normalize_exchange(qso.sent_exchange) == normalize_exchange(
        candidate.received_exchange
    ) and normalize_exchange(qso.received_exchange) == normalize_exchange(candidate.sent_exchange)


def find_candidates(db: Session, contest: Contest, qso: QSO) -> list[QSO]:
    return find_candidate_matches(db, contest, qso).candidates


def confidence_label_for(confidence: int, rules: MatchingRules | None = None) -> str:
    high = int(round((rules.confidence_auto_accept if rules else 0.95) * 10000))
    medium = int(round((rules.confidence_medium if rules else 0.70) * 10000))
    if confidence >= high:
        return "high"
    if confidence >= medium:
        return "medium"
    return "low"


def score_candidate(qso: QSO, candidate: QSO, contest: Contest) -> CandidateScore:
    rules = matching_rules(contest)
    weights = dict(rules.weights or {})
    qso_call = normalize_callsign(qso.participant_callsign)
    qso_counterparty = normalize_callsign(qso.counterparty_callsign)
    candidate_call = normalize_callsign(candidate.participant_callsign)
    candidate_counterparty = normalize_callsign(candidate.counterparty_callsign)
    tolerance = timedelta(minutes=rules.time_tolerance_minutes)
    tolerance_seconds = max(int(tolerance.total_seconds()), 1)
    delta_seconds = abs(int((candidate.qso_at_utc - qso.qso_at_utc).total_seconds()))
    same_band = candidate.band.upper() == qso.band.upper()
    same_mode = candidate.mode.upper() == qso.mode.upper()
    reciprocal_exact = candidate_call == qso_counterparty and candidate_counterparty == qso_call
    participant_distance = effective_callsign_distance(candidate_call, qso_counterparty)
    counterparty_distance = effective_callsign_distance(candidate_counterparty, qso_call)
    reciprocal_fuzzy = participant_distance <= rules.fuzzy_callsign_distance and counterparty_distance <= rules.fuzzy_callsign_distance
    exchange_ok = exchanges_match(qso, candidate)

    time_score = max(0.0, 1.0 - (delta_seconds / tolerance_seconds)) if delta_seconds <= tolerance_seconds else 0.0

    if reciprocal_exact:
        callsign_score = 1.0
    elif reciprocal_fuzzy:
        max_distance = max(rules.fuzzy_callsign_distance * 2, 1)
        callsign_score = max(
            0.0,
            1.0 - ((participant_distance + counterparty_distance) / max_distance),
        )
    else:
        callsign_score = 0.0

    stage: str
    conflict_type: ConflictType | None

    if reciprocal_exact:
        if not same_band:
            stage, conflict_type = "relaxed", ConflictType.BAND_MISMATCH
        elif not same_mode:
            stage, conflict_type = "relaxed", ConflictType.MODE_MISMATCH
        elif delta_seconds > tolerance_seconds:
            stage, conflict_type = "relaxed", ConflictType.TIME_MISMATCH
        elif not exchange_ok:
            stage, conflict_type = "relaxed", ConflictType.EXCHANGE_MISMATCH
        else:
            stage, conflict_type = "exact", None
        band_score = 1.0 if same_band else 0.0
        mode_score = 1.0 if same_mode else 0.0
    elif reciprocal_fuzzy:
        stage, conflict_type = "fuzzy", ConflictType.BUSTED_CALL
        band_score = 1.0 if same_band else float(rules.soft_band_score)
        mode_score = 1.0 if same_mode else float(rules.soft_mode_score)
    else:
        stage, conflict_type = "candidate_search", ConflictType.NIL
        band_score = 1.0 if same_band else 0.0
        mode_score = 1.0 if same_mode else 0.0

    signal_scores: dict[str, float] = {
        "callsign": callsign_score,
        "time": time_score,
        "band": band_score,
        "mode": mode_score,
        "exchange": 1.0 if exchange_ok else 0.0,
    }

    typo_notes: list[str] = []
    if participant_distance > 0:
        typo_notes.append(
            f"Reciprocal leg A: logged {candidate_call} vs needed {qso_counterparty} (effective distance {participant_distance})"
        )
    if counterparty_distance > 0:
        typo_notes.append(
            f"Reciprocal leg B: logged {candidate_counterparty} vs needed {qso_call} (effective distance {counterparty_distance})"
        )
    if reciprocal_fuzzy and (
        participant_distance == 1
        or counterparty_distance == 1
        or swap_adjacent_once_matches(candidate_call, qso_counterparty)
        or swap_adjacent_once_matches(candidate_counterparty, qso_call)
    ):
        typo_notes.append("Typo heuristic: distance-1 reciprocal path (deterministic scorer)")

    keyboard_bonus_total = 0.0
    if reciprocal_fuzzy:
        keyboard_bonus_total = min(
            1.0,
            keyboard_substitution_typo_bonus(candidate_call, qso_counterparty, rules)
            + keyboard_substitution_typo_bonus(candidate_counterparty, qso_call, rules),
        )

    weighted_core = sum(signal_scores[name] * float(weights.get(name, 0.0)) for name in signal_scores)

    prefix_bonus = 0.0
    if stage == "fuzzy":
        prefix_bonus = (
            rules.region_prefix_match_bonus if candidate.counterparty_prefix == qso.participant_prefix else 0.0
        )
        weighted_score = min(1.0, max(0.0, weighted_core + prefix_bonus + keyboard_bonus_total))
    else:
        weighted_score = max(0.0, min(weighted_core, 1.0))

    confidence_float = weighted_score
    confidence = int(round(confidence_float * 10000))
    label = confidence_label_for(confidence, rules)

    contributions = [
        {
            "signal": name,
            "raw": signal_scores[name],
            "weight": float(weights.get(name, 0.0)),
            "weighted": signal_scores[name] * float(weights.get(name, 0.0)),
        }
        for name in ("callsign", "time", "band", "mode", "exchange")
    ]
    if prefix_bonus > 0:
        contributions.append({"signal": "region_prefix_bonus", "raw": prefix_bonus, "weight": 1.0, "weighted": prefix_bonus})
    if keyboard_bonus_total > 0:
        contributions.append(
            {
                "signal": "keyboard_adjacency_typo_bonus",
                "raw": keyboard_bonus_total,
                "weight": 1.0,
                "weighted": keyboard_bonus_total,
            }
        )

    breakdown = {
        "signals": signal_scores | ({"keyboard_adjacency_bonus": keyboard_bonus_total} if keyboard_bonus_total else {}),
        "weights": weights,
        "score": confidence_float,
        "confidence": label,
        "stage": stage,
        "conflict_type": conflict_type.value if conflict_type else None,
        "participant_callsign_distance": participant_distance,
        "counterparty_callsign_distance": counterparty_distance,
        "same_band_mode": {"band": same_band, "mode": same_mode},
        "weighted_core_before_bonuses": weighted_core,
        "contributions": contributions,
        "keyboard_adjacency_bonus": keyboard_bonus_total,
        "probable_typo_hints": typo_notes,
    }

    reasoning = [
        f"Pipeline stage = {stage}",
        f"Timestamp delta = {delta_seconds}s (tolerance={tolerance_seconds}s)",
        f"Participant callsign effective distance = {participant_distance}",
        f"Counterparty callsign effective distance = {counterparty_distance}",
        f"Signals: callsign={signal_scores['callsign']:.4f}, time={signal_scores['time']:.4f}, "
        f"band={signal_scores['band']:.4f}, mode={signal_scores['mode']:.4f}, exchange={signal_scores['exchange']:.4f}",
        f"Weighted confidence V2 = {confidence_float:.4f} ({label})",
    ]
    if reciprocal_fuzzy and (not same_band or not same_mode):
        reasoning.append(
            "Soft band/mode credit applied — cross-check surfaced candidate despite logging mismatch "
            "(judge verifies band/mode truthfulness)."
        )
    if stage == "fuzzy" and prefix_bonus > 0:
        reasoning.append("Region/prefix alignment bonus applied (deterministic)")
    if keyboard_bonus_total > 0:
        reasoning.append("Keyboard-adjacent substitution bonus applied")

    return CandidateScore(
        qso=candidate,
        stage=stage,
        confidence=confidence,
        conflict_type=conflict_type,
        reasoning=reasoning,
        breakdown=breakdown,
    )


def _sort_tier(qso: QSO, tier: list[CandidateScore]) -> list[CandidateScore]:
    return sorted(
        tier,
        key=lambda score: (
            -score.confidence,
            abs((score.qso.qso_at_utc - qso.qso_at_utc).total_seconds()),
            score.qso.id,
        ),
    )


def _pipeline_decision_label(tier_name: str, top: CandidateScore | None) -> str:
    if top is None:
        return "NIL"
    if tier_name == "exact":
        return "EXACT_MATCH"
    if top.conflict_type == ConflictType.TIME_MISMATCH:
        return "TIME_DRIFT"
    if top.conflict_type == ConflictType.EXCHANGE_MISMATCH:
        return "BUSTED_EXCHANGE"
    if top.conflict_type == ConflictType.BUSTED_CALL:
        return "BUSTED_CALL"
    return (top.conflict_type.value if top.conflict_type else tier_name).upper()


def resolve_matching_pipeline(qso: QSO, candidates: list[QSO], contest: Contest) -> MatchResolution:
    rules = matching_rules(contest)
    auto_high = int(round(rules.confidence_auto_accept * 10000))
    auto_med = int(round(rules.confidence_medium * 10000))

    if not candidates:
        expl = {
            "decision": "NIL",
            "confidence": 0.0,
            "reasoning": ["No candidates returned from retrieval buckets"],
            "stages_considered": ["exact", "relaxed", "fuzzy"],
            "ranked_hints": [],
            "judge_view": _build_judge_view(
                qso,
                headline="No indexed candidates retrieved",
                detail="Indexing + time-window filters returned zero rows; nothing to compare against.",
                confidence_ratio=0.0,
                pipeline_decision="NIL",
                ranked_cards=[],
                probable_typo=False,
            ),
        }
        return MatchResolution(
            outcome="no_match",
            primary=None,
            ordered_tier=[],
            all_scored=[],
            matching_status=MatchingDecisionStatus.NO_MATCH,
            conflict_type=ConflictType.NIL,
            probable_typo=False,
            pipeline_decision="NIL",
            explainability=expl,
        )

    all_scored = [score_candidate(qso, candidate, contest) for candidate in candidates]

    tier_name: str | None = None
    tier_list: list[CandidateScore] = []

    exact_ok = [s for s in all_scored if s.stage == "exact" and s.conflict_type is None]
    if exact_ok:
        tier_name, tier_list = "exact", _sort_tier(qso, exact_ok)
    else:
        relaxed = [s for s in all_scored if s.stage == "relaxed"]
        if relaxed:
            tier_name, tier_list = "relaxed", _sort_tier(qso, relaxed)
        else:
            fuzzy = [s for s in all_scored if s.stage == "fuzzy"]
            if fuzzy:
                tier_name, tier_list = "fuzzy", _sort_tier(qso, fuzzy)

    if not tier_list or tier_name is None:
        export_limit = max(rules.matching_candidate_export_limit, 5)
        sorted_pool = _sort_tier(qso, all_scored)
        ranked_cards = [_summarize_score(s, qso) for s in sorted_pool[:export_limit]]
        expl = {
            "decision": "NIL",
            "confidence": 0.0,
            "reasoning": ["No reciprocal candidates passed exact, relaxed, or fuzzy gates"],
            "candidate_summaries": [_summarize_score(s, qso) for s in sorted_pool[: min(export_limit, 10)]],
            "ranked_hints": ranked_cards,
            "judge_view": _build_judge_view(
                qso,
                headline="No reciprocal linkage within scorer gates",
                detail="Candidates were retrieved but none formed a reciprocal match within fuzzy distance rules.",
                confidence_ratio=float(sorted_pool[0].confidence / 10000) if sorted_pool else 0.0,
                pipeline_decision="NIL",
                ranked_cards=ranked_cards,
                probable_typo=False,
            ),
        }
        return MatchResolution(
            outcome="no_match",
            primary=None,
            ordered_tier=[],
            all_scored=all_scored,
            matching_status=MatchingDecisionStatus.NO_MATCH,
            conflict_type=ConflictType.NIL,
            probable_typo=False,
            pipeline_decision="NIL",
            explainability=expl,
        )

    top = tier_list[0]
    ambiguous = (
        len(tier_list) >= 2
        and tier_list[0].confidence - tier_list[1].confidence <= rules.ambiguity_score_gap
    )

    timeline = {
        "qso_at_utc": qso.qso_at_utc.isoformat(),
        "tier": tier_name,
        "top_candidate_qso_at_utc": top.qso.qso_at_utc.isoformat(),
    }

    if ambiguous:
        export_limit = max(rules.matching_candidate_export_limit, 5)
        ranked_cards = [_summarize_score(s, qso) for s in tier_list[:export_limit]]
        expl = {
            "decision": "AMBIGUOUS",
            "confidence": top.confidence / 10000,
            "reasoning": [
                "Top candidates tie within configured score gap; system does not guess.",
                f"Tier={tier_name}, gap_rule={rules.ambiguity_score_gap}",
            ],
            "candidates": ranked_cards,
            "timeline": timeline,
            "judge_view": _build_judge_view(
                qso,
                headline="Ambiguous — multiple plausible reciprocal rows",
                detail="Top candidates score within the ambiguity window; pick manually or mark NIL/busted.",
                confidence_ratio=top.confidence / 10000,
                pipeline_decision="AMBIGUOUS",
                ranked_cards=ranked_cards,
                probable_typo=False,
            ),
        }
        return MatchResolution(
            outcome="ambiguous",
            primary=None,
            ordered_tier=tier_list,
            all_scored=all_scored,
            matching_status=MatchingDecisionStatus.AMBIGUOUS,
            conflict_type=ConflictType.AMBIGUOUS,
            probable_typo=False,
            pipeline_decision="AMBIGUOUS",
            explainability=expl,
        )

    decision_label = _pipeline_decision_label(tier_name, top)

    # Exact reciprocal + matching fields: always confirm (deterministic match).
    if tier_name == "exact" and top.conflict_type is None:
        expl = {
            "decision": decision_label,
            "confidence": top.confidence / 10000,
            "reasoning": top.reasoning + ["Exact reciprocal match"],
            "timeline": timeline,
            "judge_view": _build_judge_view(
                qso,
                headline="Exact reciprocal match",
                detail="Band, mode, time, and exchange line up with the opposing log.",
                confidence_ratio=top.confidence / 10000,
                pipeline_decision=decision_label,
                ranked_cards=[_summarize_score(top, qso)],
                probable_typo=False,
            ),
        }
        return MatchResolution(
            outcome="confirmed",
            primary=top,
            ordered_tier=tier_list,
            all_scored=all_scored,
            matching_status=MatchingDecisionStatus.CONFIRMED,
            conflict_type=None,
            probable_typo=False,
            pipeline_decision=decision_label,
            explainability=expl,
        )

    if top.confidence >= auto_high:
        export_limit = max(rules.matching_candidate_export_limit, 5)
        ranked_cards = [_summarize_score(s, qso) for s in tier_list[:export_limit]]
        expl = {
            "decision": decision_label,
            "confidence": top.confidence / 10000,
            "reasoning": top.reasoning + ["Auto-accepted: confidence meets high threshold"],
            "timeline": timeline,
            "candidates": ranked_cards,
            "judge_view": _build_judge_view(
                qso,
                headline="High-confidence automatic match",
                detail="Heuristic V2 score cleared the auto-accept threshold (still auditable below).",
                confidence_ratio=top.confidence / 10000,
                pipeline_decision=decision_label,
                ranked_cards=ranked_cards,
                probable_typo=False,
            ),
        }
        return MatchResolution(
            outcome="confirmed",
            primary=top,
            ordered_tier=tier_list,
            all_scored=all_scored,
            matching_status=MatchingDecisionStatus.CONFIRMED,
            conflict_type=top.conflict_type,
            probable_typo=False,
            pipeline_decision=decision_label,
            explainability=expl,
        )

    probable = auto_med <= top.confidence < auto_high
    export_limit = max(rules.matching_candidate_export_limit, 5)
    ranked_cards = [_summarize_score(s, qso) for s in tier_list[:export_limit]]
    detail = (
        "Medium band: treat as probable logging typo (verify callsign + exchange manually)."
        if probable
        else "Low band: needs eyes on raw Cabrillo + timeline before accepting."
    )
    expl = {
        "decision": decision_label,
        "confidence": top.confidence / 10000,
        "reasoning": top.reasoning
        + (
            ["Marked probable typo (medium confidence band)"]
            if probable
            else ["Low confidence — judge queue"]
        ),
        "probable_typo": probable,
        "timeline": timeline,
        "candidates": ranked_cards,
        "judge_view": _build_judge_view(
            qso,
            headline="Needs judge decision",
            detail=detail,
            confidence_ratio=top.confidence / 10000,
            pipeline_decision=decision_label,
            ranked_cards=ranked_cards,
            probable_typo=probable,
        ),
    }
    return MatchResolution(
        outcome="conflict",
        primary=top,
        ordered_tier=tier_list,
        all_scored=all_scored,
        matching_status=MatchingDecisionStatus.CONFLICT,
        conflict_type=top.conflict_type,
        probable_typo=probable,
        pipeline_decision=decision_label,
        explainability=expl,
    )


def _build_judge_view(
    qso: QSO,
    *,
    headline: str,
    detail: str | None,
    confidence_ratio: float,
    pipeline_decision: str,
    ranked_cards: Sequence[dict[str, Any]],
    probable_typo: bool,
) -> dict[str, Any]:
    ratio = float(max(0.0, min(confidence_ratio, 1.0)))
    payload: dict[str, Any] = {
        "headline": headline,
        "confidence_percent": round(ratio * 100, 2),
        "pipeline_decision": pipeline_decision,
        "logged_qso": {
            "participant_callsign": qso.participant_callsign,
            "counterparty_callsign": qso.counterparty_callsign,
            "band": qso.band,
            "mode": qso.mode,
            "qso_at_utc": qso.qso_at_utc.isoformat(),
        },
        "ranked_candidates": list(ranked_cards),
        "nearby_callsigns": _nearby_callsigns(ranked_cards),
        "probable_typo": probable_typo,
    }
    if detail:
        payload["detail"] = detail
    return payload


def _nearby_callsigns(ranked_cards: Sequence[dict[str, Any]]) -> list[str]:
    callsigns: list[str] = []
    seen: set[str] = set()
    for row in ranked_cards:
        callsign = row.get("candidate_callsign") or row.get("candidate_station_callsign")
        if not isinstance(callsign, str) or not callsign or callsign in seen:
            continue
        seen.add(callsign)
        callsigns.append(callsign)
    return callsigns


def _summarize_score(score: CandidateScore, baseline_qso: QSO | None = None) -> dict[str, Any]:
    dt = (
        abs(int((score.qso.qso_at_utc - baseline_qso.qso_at_utc).total_seconds()))
        if baseline_qso is not None
        else None
    )
    bd = dict(score.breakdown) if isinstance(score.breakdown, dict) else {}

    rationale: list[str] = []
    p_dist = bd.get("participant_callsign_distance")
    c_dist = bd.get("counterparty_callsign_distance")
    if isinstance(p_dist, int):
        rationale.append(f"Leg A reciprocal distance vs logged counterparty: {p_dist}")
    if isinstance(c_dist, int):
        rationale.append(f"Leg B reciprocal distance vs originating station: {c_dist}")

    bm = bd.get("signals", {})
    if isinstance(bm, dict):

        def _is_soft_cred(v: object) -> bool:
            try:
                x = float(v)
            except (TypeError, ValueError):
                return False
            return 0.0 < x < 1.0

        if _is_soft_cred(bm.get("band")):
            rationale.append("Band soft-credit engaged (recovering typo/logging mismatch)")
        if _is_soft_cred(bm.get("mode")):
            rationale.append("Mode soft-credit engaged (recovering typo/logging mismatch)")

    kb = bd.get("keyboard_adjacency_bonus")
    if isinstance(kb, (int, float)) and kb > 0:
        rationale.append("Keyboard-adjacent substitution reinforces typo hypothesis")

    comparison = None
    if baseline_qso is not None:
        differences: list[str] = []
        mismatch_count = 0
        if isinstance(p_dist, int):
            mismatch_count += p_dist
        if isinstance(c_dist, int):
            mismatch_count += c_dist
        if mismatch_count:
            differences.append(f"{mismatch_count} callsign edit{'s' if mismatch_count != 1 else ''}")
        if dt is not None:
            differences.append(f"timestamp delta {dt}s")
        differences.append("exchange identical" if exchanges_match(baseline_qso, score.qso) else "exchange differs")
        comparison = {
            "your_qso": {
                "participant_callsign": normalize_callsign(baseline_qso.participant_callsign),
                "counterparty_callsign": normalize_callsign(baseline_qso.counterparty_callsign),
            },
            "candidate_qso": {
                "participant_callsign": normalize_callsign(score.qso.participant_callsign),
                "counterparty_callsign": normalize_callsign(score.qso.counterparty_callsign),
            },
            "differences": differences,
        }

    return {
        "candidate_qso_id": score.qso.id,
        "candidate_station_callsign": normalize_callsign(score.qso.participant_callsign),
        "candidate_callsign": normalize_callsign(score.qso.participant_callsign),
        "their_logged_counterparty": normalize_callsign(score.qso.counterparty_callsign),
        "comparison": comparison,
        "stage": score.stage,
        "confidence": score.confidence / 10000,
        "confidence_percent": round(score.confidence / 100.0, 2),
        "conflict_type": score.conflict_type.value if score.conflict_type else None,
        "time_delta_seconds": dt,
        "band": score.qso.band,
        "mode": score.qso.mode,
        "signals": bm if isinstance(bm, dict) else {},
        "signal_contributions": bd.get("contributions"),
        "probable_typo_hints": bd.get("probable_typo_hints"),
        "rationale": rationale,
        "reasoning_head": score.reasoning[:5],
        "keyboard_adjacency_bonus": kb,
        "weighted_core_before_bonuses": bd.get("weighted_core_before_bonuses"),
        "score_breakdown": score.breakdown,
    }


def choose_best_candidate(qso: QSO, candidates: list[QSO], contest: Contest) -> CandidateScore | None:
    """Backward-compatible helper: returns primary scored candidate or None when unresolved tier."""
    resolution = resolve_matching_pipeline(qso, candidates, contest)
    return resolution.primary
