from dataclasses import dataclass, field
from datetime import timedelta
from time import perf_counter

from sqlalchemy import Select, select
from sqlalchemy.orm import Session

from app.models import QSO, Contest, QsoCandidateIndex
from app.modules.cross_check.normalization import (
    callsign_prefix,
    effective_callsign_distance,
    normalize_callsign,
)
from app.modules.cross_check.rules import MatchingRules, matching_rules
from app.modules.observability.metrics import observe


@dataclass(frozen=True)
class RetrievalDiagnostics:
    strategy: str
    candidate_count: int
    elapsed_ms: float
    fallback_triggered: bool = False
    relaxed_dimensions_merged: bool = False
    relaxed_extra_count: int = 0
    fuzzy_neighborhood_merged: bool = False
    fuzzy_neighborhood_count: int = 0
    bucket_count: int = 0
    limit: int = 0
    notes: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class CandidateSearchResult:
    candidates: list[QSO]
    diagnostics: RetrievalDiagnostics


def candidate_window(contest: Contest) -> timedelta:
    rules = matching_rules(contest)
    return timedelta(minutes=max(rules.time_tolerance_minutes, 5))


def find_candidate_matches(db: Session, contest: Contest, qso: QSO) -> CandidateSearchResult:
    rules = matching_rules(contest)
    window = candidate_window(contest)
    lower = qso.qso_at_utc - window
    upper = qso.qso_at_utc + window
    started = perf_counter()
    notes: list[str] = []

    index_ids = _index_lookup(db, contest, qso, lower, upper, rules, prefix_length=3)
    strategy = "index_full_dimensions"
    fallback_triggered = False
    relaxed_merged = False
    relaxed_extra_count = 0

    if not index_ids:
        fallback_triggered = True
        notes.append("primary index lookup returned no candidates")
        index_ids = _index_lookup(db, contest, qso, lower, upper, rules, prefix_length=2)
        strategy = "index_short_prefix_fallback"

    if not index_ids:
        notes.append("short-prefix lookup returned no candidates")
        index_ids = _bounded_qso_fallback(db, contest, qso, lower, upper, rules)
        strategy = "bounded_band_mode_fallback"

    merged_ids = list(index_ids)
    limit_cap = max(
        rules.fallback_candidate_limit if strategy.endswith("fallback") else rules.candidate_limit,
        rules.matching_candidate_export_limit,
    )
    fuzzy_merged = False
    fuzzy_count = 0

    fuzzy_ids = _fuzzy_neighborhood_lookup(db, contest, qso, lower, upper, rules)
    new_fuzzy_ids = [fid for fid in fuzzy_ids if fid not in merged_ids and fid != qso.id]
    if new_fuzzy_ids:
        fuzzy_merged = True
        fuzzy_count = len(new_fuzzy_ids)
        notes.append(
            f"merged {len(new_fuzzy_ids)} fuzzy-neighborhood rows after bounded time/band/mode retrieval"
        )
        _append_unique(merged_ids, new_fuzzy_ids, limit_cap)

    if rules.retrieval_relax_band_mode:
        relax_limit = max(rules.relax_band_mode_candidate_limit, 1)
        relaxed_ids = _index_lookup_relaxed_dimensions(db, contest, qso, lower, upper, relax_limit, prefix_length=3)
        if not relaxed_ids:
            relaxed_ids = _index_lookup_relaxed_dimensions(db, contest, qso, lower, upper, relax_limit, prefix_length=2)
        prefix_set = set(qso_id for qso_id in merged_ids if qso_id != qso.id)
        new_ids = [rid for rid in relaxed_ids if rid not in prefix_set and rid != qso.id]
        if new_ids:
            relaxed_merged = True
            relaxed_extra_count = len(new_ids)
            notes.append(
                f"merged {len(new_ids)} relaxed-dimension index rows (band/mode not filtered) for typo recovery"
            )
            _append_unique(merged_ids, new_ids, limit_cap)

    candidates = _load_candidates(db, merged_ids, limit_cap)
    elapsed_ms = (perf_counter() - started) * 1000
    diagnostics = RetrievalDiagnostics(
        strategy=strategy,
        candidate_count=len(candidates),
        elapsed_ms=round(elapsed_ms, 3),
        fallback_triggered=fallback_triggered,
        relaxed_dimensions_merged=relaxed_merged,
        relaxed_extra_count=relaxed_extra_count,
        fuzzy_neighborhood_merged=fuzzy_merged,
        fuzzy_neighborhood_count=fuzzy_count,
        bucket_count=_bucket_count(lower, upper),
        limit=limit_cap,
        notes=notes,
    )
    observe("matching_candidate_count", len(candidates), {"strategy": strategy})
    observe("matching_retrieval_latency_ms", elapsed_ms, {"strategy": strategy})
    return CandidateSearchResult(candidates=candidates, diagnostics=diagnostics)


def find_candidates(db: Session, contest: Contest, qso: QSO) -> list[QSO]:
    return find_candidate_matches(db, contest, qso).candidates


def _index_lookup(
    db: Session,
    contest: Contest,
    qso: QSO,
    lower,
    upper,
    rules: MatchingRules,
    *,
    prefix_length: int,
) -> list[int]:
    prefix = callsign_prefix(qso.counterparty_callsign, length=prefix_length)
    query = (
        select(QsoCandidateIndex.qso_id)
        .where(
            QsoCandidateIndex.contest_id == contest.id,
            QsoCandidateIndex.submission_id != qso.submission_id,
            QsoCandidateIndex.participant_prefix.startswith(prefix),
            QsoCandidateIndex.band == qso.band.upper(),
            QsoCandidateIndex.mode == qso.mode.upper(),
            QsoCandidateIndex.qso_id != qso.id,
            QsoCandidateIndex.time_bucket >= lower,
            QsoCandidateIndex.time_bucket <= upper,
        )
        .order_by(QsoCandidateIndex.time_bucket.asc(), QsoCandidateIndex.qso_id.asc())
        .limit(rules.candidate_limit)
    )
    return list(db.scalars(query).all())


def _index_lookup_relaxed_dimensions(
    db: Session,
    contest: Contest,
    qso: QSO,
    lower,
    upper,
    limit: int,
    *,
    prefix_length: int,
) -> list[int]:
    """Same as full index lookup but without band/mode filters — recovers cross-band/mode logging typos."""
    prefix = callsign_prefix(qso.counterparty_callsign, length=prefix_length)
    query = (
        select(QsoCandidateIndex.qso_id)
        .where(
            QsoCandidateIndex.contest_id == contest.id,
            QsoCandidateIndex.submission_id != qso.submission_id,
            QsoCandidateIndex.participant_prefix.startswith(prefix),
            QsoCandidateIndex.qso_id != qso.id,
            QsoCandidateIndex.time_bucket >= lower,
            QsoCandidateIndex.time_bucket <= upper,
        )
        .order_by(QsoCandidateIndex.time_bucket.asc(), QsoCandidateIndex.qso_id.asc())
        .limit(limit)
    )
    return list(db.scalars(query).all())


def _fuzzy_neighborhood_lookup(db: Session, contest: Contest, qso: QSO, lower, upper, rules: MatchingRules) -> list[int]:
    """Generate typo-aware candidates inside the already bounded time/band/mode search space."""
    target = normalize_callsign(qso.counterparty_callsign)
    if not target:
        return []
    query = (
        select(QsoCandidateIndex.qso_id, QsoCandidateIndex.normalized_participant_callsign)
        .where(
            QsoCandidateIndex.contest_id == contest.id,
            QsoCandidateIndex.submission_id != qso.submission_id,
            QsoCandidateIndex.band == qso.band.upper(),
            QsoCandidateIndex.mode == qso.mode.upper(),
            QsoCandidateIndex.qso_id != qso.id,
            QsoCandidateIndex.time_bucket >= lower,
            QsoCandidateIndex.time_bucket <= upper,
        )
        .order_by(QsoCandidateIndex.time_bucket.asc(), QsoCandidateIndex.qso_id.asc())
        .limit(max(rules.fallback_candidate_limit, rules.candidate_limit, 1))
    )
    rows = db.execute(query).all()
    return [
        qso_id
        for qso_id, candidate_call in rows
        if effective_callsign_distance(str(candidate_call or ""), target) <= rules.fuzzy_callsign_distance
    ]


def _bounded_qso_fallback(db: Session, contest: Contest, qso: QSO, lower, upper, rules: MatchingRules) -> list[int]:
    query = (
        select(QSO.id)
        .where(
            QSO.contest_id == contest.id,
            QSO.id != qso.id,
            QSO.submission_id != qso.submission_id,
            QSO.qso_at_utc >= lower,
            QSO.qso_at_utc <= upper,
            QSO.band == qso.band,
            QSO.mode == qso.mode,
        )
        .order_by(QSO.qso_at_utc.asc(), QSO.id.asc())
        .limit(rules.fallback_candidate_limit)
    )
    return list(db.scalars(query).all())


def _load_candidates(db: Session, qso_ids: list[int], limit: int) -> list[QSO]:
    if not qso_ids:
        return []
    limited_ids = qso_ids[:limit]
    ordering = {qso_id: index for index, qso_id in enumerate(limited_ids)}
    query: Select[tuple[QSO]] = select(QSO).where(QSO.id.in_(limited_ids))
    return sorted(db.scalars(query).all(), key=lambda candidate: ordering[candidate.id])


def _append_unique(target: list[int], source: list[int], limit: int) -> None:
    seen = set(target)
    for qso_id in source:
        if len(target) >= limit:
            break
        if qso_id in seen:
            continue
        target.append(qso_id)
        seen.add(qso_id)


def _bucket_count(lower, upper) -> int:
    return max(int((upper - lower).total_seconds() // 300) + 1, 1)
