import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.permissions import can_access_judge_workbench, get_current_user
from app.domain import ContestStatus, ProcessingJobStatus, ProcessingJobType
from app.models import Contest, ProcessingJob, User
from app.modules.messaging.contracts import MatchingRequestedEvent
from app.modules.messaging.outbox import enqueue_event
from app.modules.processing_jobs.service import create_queued_job
from app.schemas import ProcessingJobRead

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Organizer"])


def cross_check_actor(
    contest_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> User:
    if not can_access_judge_workbench(db, user, contest_id):
        raise HTTPException(status_code=403, detail="Not allowed to run cross-check for this contest")
    return user


def enqueue_cross_check(
    db: Session,
    *,
    contest: Contest,
    actor: User,
    replay: bool,
) -> ProcessingJob:
    active_job = db.scalar(
        select(ProcessingJob)
        .where(
            ProcessingJob.contest_id == contest.id,
            ProcessingJob.type == ProcessingJobType.CROSS_CHECK,
            ProcessingJob.status.in_(
                [ProcessingJobStatus.QUEUED, ProcessingJobStatus.RUNNING]
            ),
        )
        .order_by(ProcessingJob.id.desc())
    )
    if active_job is not None:
        return active_job
    contest.status = ContestStatus.CHECKING
    job = create_queued_job(
        db,
        contest_id=contest.id,
        job_type=ProcessingJobType.CROSS_CHECK,
        actor=actor,
    )
    event = MatchingRequestedEvent(
        contest_id=contest.id,
        job_id=job.id,
        actor_id=actor.id,
        replay=replay,
    )
    enqueue_event(
        db,
        event_type="matching.requested.v1",
        aggregate_type="contest",
        aggregate_id=contest.id,
        partition_key=str(contest.id),
        payload=event,
        idempotency_key=f"matching-requested:{job.id}",
    )
    return job


@router.post(
    "/api/organizer/contests/{contest_id}/cross-check",
    response_model=ProcessingJobRead,
    status_code=202,
)
def cross_check_contest(
    contest_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(cross_check_actor),
) -> ProcessingJob:
    logger.info(
        "cross_check.request contest_id=%s actor_id=%s", contest_id, current_user.id
    )
    contest = db.get(Contest, contest_id)
    if contest is None:
        logger.warning("cross_check.contest_missing contest_id=%s", contest_id)
        raise HTTPException(status_code=404, detail="Contest not found")
    if contest.status not in {ContestStatus.LOG_SUBMISSION_CLOSED, ContestStatus.CHECKING, ContestStatus.JUDGE_REVIEW}:
        logger.warning(
            "cross_check.invalid_status contest_id=%s status=%s",
            contest_id,
            contest.status.value,
        )
        raise HTTPException(status_code=409, detail="Close log submission before cross-check")
    job = enqueue_cross_check(db, contest=contest, actor=current_user, replay=False)
    logger.debug("cross_check.job_created contest_id=%s job_id=%s", contest_id, job.id)
    db.commit()
    db.refresh(job)
    return job


@router.post(
    "/api/organizer/contests/{contest_id}/cross-check/replay",
    response_model=ProcessingJobRead,
    status_code=202,
)
def replay_cross_check_contest(
    contest_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(cross_check_actor),
) -> ProcessingJob:
    contest = db.get(Contest, contest_id)
    if contest is None:
        raise HTTPException(status_code=404, detail="Contest not found")
    if contest.status not in {
        ContestStatus.LOG_SUBMISSION_CLOSED,
        ContestStatus.CHECKING,
        ContestStatus.JUDGE_REVIEW,
    }:
        raise HTTPException(
            status_code=409,
            detail="Close log submission before replaying cross-check",
        )
    job = enqueue_cross_check(db, contest=contest, actor=current_user, replay=True)
    db.commit()
    db.refresh(job)
    return job
