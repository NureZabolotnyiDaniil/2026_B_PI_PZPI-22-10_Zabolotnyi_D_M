from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, selectinload

from app.core.database import get_db
from app.core.permissions import can_access_judge_workbench, get_current_user
from app.domain import ConflictStatus, ConflictType, JudgeDecisionType, QsoCheckStatus, UserRole
from app.models import (
    QSO,
    Contest,
    ContestJudge,
    CrossCheckConflict,
    JudgeDecision,
    MatchingDecision,
    Participant,
    User,
)
from app.modules.audit.service import record_audit
from app.modules.scoring.service import recalculate_final_score
from app.schemas import (
    ConflictNeighborRead,
    ConflictQueueItem,
    ConflictQueueRead,
    ConflictWorkbenchDetail,
    JudgeContestRead,
    JudgeDashboardRead,
    JudgeDecisionCreate,
    JudgeDecisionRead,
    MatchingDecisionRead,
    ParticipantStationSearchHit,
)

router = APIRouter(prefix="/api/judge", tags=["Judge"])


@router.get("/contests", response_model=list[JudgeContestRead])
def list_judge_contests(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> list[JudgeContestRead]:
    roles = set(user.global_roles or [])
    if UserRole.ADMIN in roles or UserRole.ORGANIZER in roles:
        contests = list(db.scalars(select(Contest).order_by(Contest.start_at_utc.desc())).all())
    elif UserRole.JUDGE in roles:
        contests = list(
            db.scalars(
                select(Contest)
                .join(ContestJudge, ContestJudge.contest_id == Contest.id)
                .where(ContestJudge.user_id == user.id)
                .order_by(Contest.start_at_utc.desc())
            ).all()
        )
    else:
        raise HTTPException(status_code=403, detail="Judge role required")
    return [
        JudgeContestRead(
            id=contest.id,
            title=contest.title,
            status=contest.status,
            start_at_utc=contest.start_at_utc,
            end_at_utc=contest.end_at_utc,
        )
        for contest in contests
    ]


def judge_workspace_user_for_contest(
    contest_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> User:
    if not can_access_judge_workbench(db, user, contest_id):
        raise HTTPException(status_code=403, detail="No judge access for this contest")
    return user


def judge_workspace_user_for_conflict(
    conflict_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> User:
    conflict = db.get(CrossCheckConflict, conflict_id)
    if conflict is None:
        raise HTTPException(status_code=404, detail="Conflict not found")
    if not can_access_judge_workbench(db, user, conflict.contest_id):
        raise HTTPException(status_code=403, detail="No judge access for this contest")
    return user


def _load_conflict(db: Session, conflict_id: int) -> CrossCheckConflict:
    conflict = db.scalar(
        select(CrossCheckConflict)
        .where(CrossCheckConflict.id == conflict_id)
        .options(selectinload(CrossCheckConflict.qso), selectinload(CrossCheckConflict.candidate_qso))
    )
    if conflict is None:
        raise HTTPException(status_code=404, detail="Conflict not found")
    return conflict


def _build_workbench_detail(conflict: CrossCheckConflict, db: Session) -> ConflictWorkbenchDetail:
    details = conflict.details or {}
    explainability = details.get("explainability") if isinstance(details.get("explainability"), dict) else None
    matching_candidates = details.get("matching_candidates") if isinstance(details.get("matching_candidates"), list) else []
    timeline = None
    if isinstance(explainability, dict):
        timeline = explainability.get("timeline") if isinstance(explainability.get("timeline"), dict) else None

    prior = list(
        db.scalars(
            select(MatchingDecision)
            .where(MatchingDecision.qso_id == conflict.qso_id)
            .order_by(MatchingDecision.decided_at_utc.desc())
        ).all()
    )

    return ConflictWorkbenchDetail(
        id=conflict.id,
        contest_id=conflict.contest_id,
        qso_id=conflict.qso_id,
        candidate_qso_id=conflict.candidate_qso_id,
        type=conflict.type,
        severity=conflict.severity,
        status=conflict.status,
        detected_at_utc=conflict.detected_at_utc,
        details=details,
        qso=conflict.qso,
        candidate_qso=conflict.candidate_qso,
        explainability=explainability,
        matching_candidates=list(matching_candidates),
        timeline=timeline,
        prior_matching_decisions=[MatchingDecisionRead.model_validate(row) for row in prior],
    )


@router.get("/contests/{contest_id}/conflicts", response_model=ConflictQueueRead)
def list_conflicts(
    contest_id: int,
    conflict_type: ConflictType | None = Query(default=None),
    status_filter: ConflictStatus | None = Query(default=None, alias="status"),
    participant_callsign: str | None = Query(default=None, alias="station"),
    band: str | None = None,
    region: str | None = None,
    category: str | None = None,
    confidence_lt: float | None = None,
    sort_by: str = Query(default="confidence"),
    sort_dir: str = Query(default="asc"),
    unresolved_first: bool = Query(default=True),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
    _: User = Depends(judge_workspace_user_for_contest),
) -> ConflictQueueRead:
    items = _gather_conflict_queue_items(
        db,
        contest_id,
        conflict_type=conflict_type,
        status_filter=status_filter,
        station=participant_callsign,
        band=band,
        region=region,
        category=category,
        confidence_lt=confidence_lt,
    )
    items = _sort_queue_snapshot(items, sort_by=sort_by, sort_dir=sort_dir, unresolved_first=unresolved_first)
    total = len(items)
    paged = items[offset : offset + limit]
    return ConflictQueueRead(items=paged, total=total, limit=limit, offset=offset)


@router.get("/contests/{contest_id}/participants/search", response_model=list[ParticipantStationSearchHit])
def search_contest_station_registry(
    contest_id: int,
    q: str = Query(default="", min_length=1),
    limit: int = Query(default=40, ge=1, le=100),
    db: Session = Depends(get_db),
    _: User = Depends(judge_workspace_user_for_contest),
) -> list[ParticipantStationSearchHit]:
    trimmed = q.strip().upper()
    like_pat = f"%{trimmed}%"
    rows = list(
        db.scalars(
            select(Participant)
            .where(Participant.contest_id == contest_id, func.upper(Participant.callsign).like(like_pat))
            .order_by(Participant.callsign.asc())
            .limit(limit)
        ).all()
    )
    return [
        ParticipantStationSearchHit(callsign=row.callsign, category=row.category, region=row.country_or_region)
        for row in rows
    ]


@router.get("/conflicts/{conflict_id}/neighbors", response_model=ConflictNeighborRead)
def conflict_neighbors(
    conflict_id: int,
    contest_id: int = Query(..., description="Must match the contest that owns this conflict (drives filter parity with the queue)."),
    conflict_type: ConflictType | None = Query(default=None),
    status_filter: ConflictStatus | None = Query(default=None, alias="status"),
    station: str | None = Query(default=None),
    band: str | None = None,
    region: str | None = None,
    category: str | None = None,
    confidence_lt: float | None = None,
    sort_by: str = Query(default="confidence"),
    sort_dir: str = Query(default="asc"),
    unresolved_first: bool = Query(default=True),
    db: Session = Depends(get_db),
    _: User = Depends(judge_workspace_user_for_conflict),
) -> ConflictNeighborRead:
    anchor = _load_conflict(db, conflict_id)
    if anchor.contest_id != contest_id:
        raise HTTPException(status_code=400, detail="contest_id does not match this conflict")

    ordered = _sort_queue_snapshot(
        _gather_conflict_queue_items(
            db,
            contest_id,
            conflict_type=conflict_type,
            status_filter=status_filter,
            station=station,
            band=band,
            region=region,
            category=category,
            confidence_lt=confidence_lt,
        ),
        sort_by=sort_by,
        sort_dir=sort_dir,
        unresolved_first=unresolved_first,
    )
    ids = [row.id for row in ordered]
    try:
        index = ids.index(conflict_id)
    except ValueError:
        return ConflictNeighborRead(
            contest_id=contest_id,
            conflict_id=conflict_id,
            index=None,
            prev_conflict_id=None,
            next_conflict_id=None,
            total_matching_filters=len(ids),
        )
    prev_id = ids[index - 1] if index > 0 else None
    next_id = ids[index + 1] if index + 1 < len(ids) else None
    return ConflictNeighborRead(
        contest_id=contest_id,
        conflict_id=conflict_id,
        index=index,
        prev_conflict_id=prev_id,
        next_conflict_id=next_id,
        total_matching_filters=len(ids),
    )


@router.get("/contests/{contest_id}/dashboard", response_model=JudgeDashboardRead)
def get_dashboard(
    contest_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(judge_workspace_user_for_contest),
) -> JudgeDashboardRead:
    total_qso = len(list(db.scalars(select(QSO.id).where(QSO.contest_id == contest_id)).all()))
    conflicts = list(db.scalars(select(CrossCheckConflict).where(CrossCheckConflict.contest_id == contest_id)).all())
    pending = [row for row in conflicts if row.status == ConflictStatus.OPEN]
    auto_resolved = [row for row in conflicts if row.status == ConflictStatus.AUTO_RESOLVED]
    high_priority = [row for row in pending if _confidence_from_details(row.details) < 0.7 or _impact_from_details(row.details) >= 5]
    confidence_values = [_confidence_from_details(row.details) for row in conflicts]
    avg_confidence = sum(confidence_values) / len(confidence_values) if confidence_values else 0.0
    ratio = (len(auto_resolved) / len(conflicts)) if conflicts else 0.0
    return JudgeDashboardRead(
        total_qso=total_qso,
        auto_resolved_ratio=round(ratio, 4),
        pending_conflicts=len(pending),
        high_priority_conflicts=len(high_priority),
        avg_confidence=round(avg_confidence, 4),
    )


@router.get("/conflicts/{conflict_id}", response_model=ConflictWorkbenchDetail)
def get_conflict(
    conflict_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(judge_workspace_user_for_conflict),
) -> ConflictWorkbenchDetail:
    conflict = _load_conflict(db, conflict_id)
    return _build_workbench_detail(conflict, db)


@router.post("/conflicts/{conflict_id}/decisions", response_model=JudgeDecisionRead, status_code=201)
def create_decision(
    conflict_id: int,
    payload: JudgeDecisionCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(judge_workspace_user_for_conflict),
) -> JudgeDecision:
    conflict = _load_conflict(db, conflict_id)
    requires_comment = payload.decision in {
        JudgeDecisionType.OVERRIDE_MATCH,
        JudgeDecisionType.MARK_NIL,
        JudgeDecisionType.MARK_BUSTED_CALL,
    }
    if requires_comment and not payload.comment.strip():
        raise HTTPException(status_code=422, detail="Comment is required for score-changing decisions")

    if payload.decision == JudgeDecisionType.OVERRIDE_MATCH and payload.selected_candidate_qso_id is None:
        raise HTTPException(status_code=422, detail="selected_candidate_qso_id is required for override decisions")

    previous_candidate_qso_id = conflict.qso.matched_qso_id
    selected_candidate_qso_id = payload.selected_candidate_qso_id or conflict.candidate_qso_id
    decision_metadata = {
        "previous_candidate_qso_id": previous_candidate_qso_id,
        "selected_candidate_qso_id": selected_candidate_qso_id,
        "reason": payload.comment,
        "confidence_snapshot": _confidence_from_details(conflict.details),
    }

    decision = JudgeDecision(
        conflict_id=conflict_id,
        judge_id=current_user.id,
        decision=payload.decision,
        comment=payload.comment,
        score_impact=payload.score_impact,
        metadata_json=decision_metadata,
    )
    db.add(decision)
    apply_decision(conflict, payload)
    conflict.status = ConflictStatus.JUDGE_RESOLVED
    _recalculate_impacted_participants(db, conflict)
    record_audit(
        db,
        actor=current_user,
        action="judge.decision_created",
        target_type="cross_check_conflict",
        target_id=conflict_id,
        metadata={"decision": payload.decision.value, **decision_metadata},
    )
    db.commit()
    db.refresh(decision)
    return decision


@router.get("/conflicts/{conflict_id}/decisions", response_model=list[JudgeDecisionRead])
def list_decisions(
    conflict_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(judge_workspace_user_for_conflict),
) -> list[JudgeDecision]:
    return list(
        db.scalars(
            select(JudgeDecision)
            .where(JudgeDecision.conflict_id == conflict_id)
            .order_by(JudgeDecision.created_at_utc.desc())
        ).all()
    )


def apply_decision(conflict: CrossCheckConflict, payload: JudgeDecisionCreate) -> None:
    decision = payload.decision
    if decision == JudgeDecisionType.ACCEPT_MATCH:
        if conflict.qso.matched_qso_id is None and conflict.candidate_qso_id is not None:
            conflict.qso.matched_qso_id = conflict.candidate_qso_id
        conflict.qso.check_status = QsoCheckStatus.CONFIRMED
    elif decision == JudgeDecisionType.OVERRIDE_MATCH:
        conflict.qso.matched_qso_id = payload.selected_candidate_qso_id
        conflict.qso.check_status = QsoCheckStatus.CONFIRMED
    elif decision == JudgeDecisionType.MARK_NIL:
        conflict.qso.matched_qso_id = None
        conflict.qso.check_status = QsoCheckStatus.NO_MATCH
    elif decision == JudgeDecisionType.MARK_BUSTED_CALL:
        conflict.qso.matched_qso_id = None
        conflict.qso.check_status = QsoCheckStatus.REJECTED
    elif decision == JudgeDecisionType.IGNORE_CONFLICT:
        conflict.qso.check_status = QsoCheckStatus.CONFLICT
    else:
        # RECALCULATE keeps matching state unchanged and only recomputes scores.
        pass


def _station_scope_clause(participant_callsign: str):
    trimmed = participant_callsign.strip().upper()
    if not trimmed:
        return None
    like_pat = f"%{trimmed}%"
    return CrossCheckConflict.qso.has(
        or_(
            func.upper(QSO.participant_callsign).like(like_pat),
            func.upper(QSO.counterparty_callsign).like(like_pat),
        )
    )


def _gather_conflict_queue_items(
    db: Session,
    contest_id: int,
    *,
    conflict_type: ConflictType | None = None,
    status_filter: ConflictStatus | None = None,
    station: str | None = None,
    band: str | None = None,
    region: str | None = None,
    category: str | None = None,
    confidence_lt: float | None = None,
) -> list[ConflictQueueItem]:
    query = select(CrossCheckConflict).where(CrossCheckConflict.contest_id == contest_id)
    if conflict_type:
        query = query.where(CrossCheckConflict.type == conflict_type)
    if status_filter:
        query = query.where(CrossCheckConflict.status == status_filter)
    if station and station.strip():
        clause = _station_scope_clause(station)
        if clause is not None:
            query = query.where(clause)
    elif station is not None and not station.strip():
        pass  # whitespace-only behaves as no station filter (same as unspecified)
    if band:
        query = query.where(CrossCheckConflict.qso.has(QSO.band == band.upper()))
    conflicts = list(
        db.scalars(
            query.options(selectinload(CrossCheckConflict.qso)).order_by(CrossCheckConflict.detected_at_utc.desc())
        ).all()
    )
    items = [_build_queue_item(db, conflict) for conflict in conflicts]
    if region:
        region_upper = region.upper()
        items = [item for item in items if item.region and item.region.upper() == region_upper]
    if category:
        category_upper = category.upper()
        items = [item for item in items if item.category and item.category.upper() == category_upper]
    if confidence_lt is not None:
        items = [item for item in items if item.confidence < confidence_lt]
    return items


def _sort_queue_snapshot(
    items: list[ConflictQueueItem],
    *,
    sort_by: str,
    sort_dir: str,
    unresolved_first: bool,
) -> list[ConflictQueueItem]:
    return sorted(
        items,
        key=lambda item: conflict_priority_key(item, sort_by=sort_by, sort_dir=sort_dir, unresolved_first=unresolved_first),
    )


def _build_queue_item(db: Session, conflict: CrossCheckConflict) -> ConflictQueueItem:
    participant = db.scalar(
        select(Participant).where(
            Participant.contest_id == conflict.contest_id,
            Participant.callsign == conflict.qso.participant_callsign,
        )
    )
    return ConflictQueueItem(
        id=conflict.id,
        contest_id=conflict.contest_id,
        qso_id=conflict.qso_id,
        candidate_qso_id=conflict.candidate_qso_id,
        type=conflict.type,
        severity=conflict.severity,
        status=conflict.status,
        detected_at_utc=conflict.detected_at_utc,
        participant_callsign=conflict.qso.participant_callsign,
        counterparty_callsign=conflict.qso.counterparty_callsign,
        band=conflict.qso.band,
        mode=conflict.qso.mode,
        qso_at_utc=conflict.qso.qso_at_utc,
        confidence=_confidence_from_details(conflict.details),
        impact=_impact_from_details(conflict.details),
        category=participant.category if participant else None,
        region=participant.country_or_region if participant else None,
        details=conflict.details or {},
    )


def _confidence_from_details(details: dict | None) -> float:
    if not isinstance(details, dict):
        return 0.0
    try:
        return float(details.get("confidence", 0.0))
    except (TypeError, ValueError):
        return 0.0


def _impact_from_details(details: dict | None) -> int:
    if not isinstance(details, dict):
        return 0
    if "impact" in details:
        try:
            return int(details["impact"])
        except (TypeError, ValueError):
            pass
    retrieval = details.get("retrieval")
    if isinstance(retrieval, dict):
        try:
            return int(retrieval.get("candidate_count", 0))
        except (TypeError, ValueError):
            return 0
    return 0


def _recalculate_impacted_participants(db: Session, conflict: CrossCheckConflict) -> None:
    impacted_callsigns = {conflict.qso.participant_callsign}
    if conflict.qso.matched_qso_id is not None:
        matched_qso = db.get(QSO, conflict.qso.matched_qso_id)
        if matched_qso is not None:
            impacted_callsigns.add(matched_qso.participant_callsign)
    participants = list(
        db.scalars(
            select(Participant).where(
                Participant.contest_id == conflict.contest_id,
                Participant.callsign.in_(impacted_callsigns),
            )
        ).all()
    )
    for participant in participants:
        recalculate_final_score(db, participant)


def conflict_priority_key(
    item: ConflictQueueItem,
    *,
    sort_by: str,
    sort_dir: str,
    unresolved_first: bool,
) -> tuple[object, ...]:
    direction = -1 if sort_dir.lower() == "desc" else 1
    if sort_by == "impact":
        sort_value: object = direction * item.impact
    elif sort_by == "detected_at":
        sort_value = item.detected_at_utc.timestamp() * direction
    else:
        sort_value = item.confidence * direction
    unresolved = 0 if (unresolved_first and item.status == ConflictStatus.OPEN) else 1 if unresolved_first else 0
    return (unresolved, sort_value, item.detected_at_utc.timestamp())
