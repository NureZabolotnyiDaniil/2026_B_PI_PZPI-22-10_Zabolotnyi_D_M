"""Judge workbench module."""
