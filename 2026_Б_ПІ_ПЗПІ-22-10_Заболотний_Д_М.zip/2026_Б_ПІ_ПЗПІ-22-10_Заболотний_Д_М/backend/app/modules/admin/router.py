from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.permissions import require_role
from app.domain import UserRole
from app.models import User
from app.modules.audit.service import record_audit
from app.schemas import RoleUpdate, UserRead, UserStatusUpdate

router = APIRouter(prefix="/api/admin/users", tags=["Admin"])


@router.get("", response_model=list[UserRead])
def list_users(
    db: Session = Depends(get_db),
    _: User = Depends(require_role(UserRole.ADMIN)),
) -> list[User]:
    return list(db.scalars(select(User).order_by(User.email)).all())


@router.patch("/{user_id}/roles", response_model=UserRead)
def update_user_roles(
    user_id: int,
    payload: RoleUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN)),
) -> User:
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    user.global_roles = payload.roles
    record_audit(
        db,
        actor=current_user,
        action="admin.user_roles_updated",
        target_type="user",
        target_id=user.id,
        metadata={"roles": payload.roles},
    )
    db.commit()
    db.refresh(user)
    return user


@router.patch("/{user_id}/status", response_model=UserRead)
def update_user_status(
    user_id: int,
    payload: UserStatusUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN)),
) -> User:
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    user.status = payload.status
    record_audit(
        db,
        actor=current_user,
        action="admin.user_status_updated",
        target_type="user",
        target_id=user.id,
        metadata={"status": payload.status},
    )
    db.commit()
    db.refresh(user)
    return user
