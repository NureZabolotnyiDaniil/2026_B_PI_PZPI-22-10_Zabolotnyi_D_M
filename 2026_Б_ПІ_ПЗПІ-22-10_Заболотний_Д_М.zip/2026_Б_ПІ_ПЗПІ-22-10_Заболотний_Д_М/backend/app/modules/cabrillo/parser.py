from dataclasses import dataclass
from datetime import UTC, datetime


@dataclass(slots=True)
class ParsedQso:
    line_number: int
    raw_line: str
    qso_at_utc: datetime
    band: str
    frequency: str | None
    mode: str
    participant_callsign: str
    counterparty_callsign: str
    sent_exchange: str | None
    received_exchange: str | None


@dataclass(slots=True)
class ParsedCabrillo:
    headers: dict[str, str]
    qso_records: list[ParsedQso]
    invalid_qso_lines: list[tuple[int, str]]


def parse_cabrillo_text(content: str) -> ParsedCabrillo:
    headers: dict[str, str] = {}
    qso_records: list[ParsedQso] = []
    invalid_qso_lines: list[tuple[int, str]] = []

    for line_number, raw_line in enumerate(content.splitlines(), start=1):
        line = raw_line.strip()
        if not line:
            continue
        if line.upper().startswith("QSO:"):
            parsed = parse_qso_line(line_number, raw_line)
            if parsed is None:
                invalid_qso_lines.append((line_number, raw_line))
            else:
                qso_records.append(parsed)
            continue
        if ":" in line:
            key, value = line.split(":", 1)
            headers[key.strip().upper()] = value.strip()

    return ParsedCabrillo(headers=headers, qso_records=qso_records, invalid_qso_lines=invalid_qso_lines)


def parse_qso_line(line_number: int, raw_line: str) -> ParsedQso | None:
    parts = raw_line.strip().split()
    if len(parts) < 8 or parts[0].upper() != "QSO:":
        return None

    band_or_frequency = parts[1].upper()
    mode = parts[2].upper()
    date_text = parts[3]
    time_text = parts[4]
    participant_callsign = parts[5].upper()

    # Cabrillo variants differ; locate the next callsign after the sender's exchange.
    counterparty_index = next(
        (index for index in range(6, len(parts)) if looks_like_callsign(parts[index])),
        None,
    )
    if counterparty_index is None:
        return None
    counterparty_callsign = parts[counterparty_index].upper()
    sent_exchange = " ".join(parts[6:counterparty_index]) or None
    received_exchange = " ".join(parts[counterparty_index + 1 :]) or None

    try:
        qso_at = datetime.strptime(f"{date_text} {time_text}", "%Y-%m-%d %H%M").replace(
            tzinfo=UTC
        )
    except ValueError:
        return None

    frequency = band_or_frequency if band_or_frequency.isdigit() else None
    band = normalize_band(band_or_frequency)
    return ParsedQso(
        line_number=line_number,
        raw_line=raw_line,
        qso_at_utc=qso_at,
        band=band,
        frequency=frequency,
        mode=mode,
        participant_callsign=participant_callsign,
        counterparty_callsign=counterparty_callsign,
        sent_exchange=sent_exchange,
        received_exchange=received_exchange,
    )


def looks_like_callsign(value: str) -> bool:
    normalized = value.upper().replace("/", "")
    return any(char.isalpha() for char in normalized) and any(char.isdigit() for char in normalized)


def normalize_band(value: str) -> str:
    if value.isdigit():
        frequency = int(value)
        if 1800 <= frequency <= 2000:
            return "160M"
        if 3500 <= frequency <= 4000:
            return "80M"
        if 7000 <= frequency <= 7300:
            return "40M"
        if 14000 <= frequency <= 14350:
            return "20M"
        if 21000 <= frequency <= 21450:
            return "15M"
        if 28000 <= frequency <= 29700:
            return "10M"
    return value.upper()
