import re

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.permissions import get_current_user
from app.domain import ContestStatus
from app.models import Contest, Participant, User
from app.modules.audit.service import record_audit
from app.schemas import ParticipantRead, ParticipationCreate

router = APIRouter(tags=["Participants"])
CALLSIGN_RE = re.compile(r"^[A-Z0-9/]{2,32}$")


@router.post("/api/contests/{contest_id}/participation", response_model=ParticipantRead, status_code=201)
def register_participation(
    contest_id: int,
    payload: ParticipationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> Participant:
    contest = db.get(Contest, contest_id)
    if contest is None or contest.status == ContestStatus.DRAFT:
        raise HTTPException(status_code=404, detail="Contest not found")
    callsign = payload.callsign.upper()
    if not CALLSIGN_RE.match(callsign):
        raise HTTPException(status_code=422, detail="Invalid callsign")
    if payload.category not in contest.categories:
        raise HTTPException(status_code=422, detail="Category is not allowed for contest")
    existing = db.scalar(
        select(Participant).where(
            Participant.user_id == current_user.id,
            Participant.contest_id == contest_id,
        )
    )
    if existing:
        raise HTTPException(status_code=409, detail="Already registered for this contest")
    participant = Participant(
        user_id=current_user.id,
        contest_id=contest_id,
        callsign=callsign,
        category=payload.category,
        power=payload.power,
        country_or_region=payload.country_or_region,
    )
    db.add(participant)
    db.flush()
    record_audit(
        db,
        actor=current_user,
        action="participant.registered",
        target_type="participant",
        target_id=participant.id,
        metadata={"contest_id": contest_id},
    )
    db.commit()
    db.refresh(participant)
    return participant


@router.get("/api/me/participations", response_model=list[ParticipantRead])
def list_my_participations(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> list[Participant]:
    return list(
        db.scalars(
            select(Participant)
            .where(Participant.user_id == current_user.id)
            .order_by(Participant.created_at_utc.desc())
        ).all()
    )
