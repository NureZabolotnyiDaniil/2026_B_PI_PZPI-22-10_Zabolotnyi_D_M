from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.permissions import get_current_user, require_role
from app.domain import ContestStatus, UserRole
from app.models import (
    QSO,
    Contest,
    CrossCheckConflict,
    Participant,
    PublicResult,
    ScoringResult,
    User,
)
from app.modules.audit.service import record_audit
from app.modules.contests.service import transition_contest
from app.modules.results.service import publish_results
from app.schemas import PersonalReport, PublicResultRead

router = APIRouter(tags=["Results"])


@router.post(
    "/api/organizer/contests/{contest_id}/publish-results",
    response_model=list[PublicResultRead],
    tags=["Organizer"],
)
def publish_contest_results(
    contest_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ORGANIZER)),
) -> list[PublicResult]:
    contest = db.get(Contest, contest_id)
    if contest is None:
        raise HTTPException(status_code=404, detail="Contest not found")
    if contest.status != ContestStatus.FINALIZED:
        raise HTTPException(status_code=409, detail="Finalize contest before publishing results")
    transition_contest(contest, ContestStatus.RESULTS_PUBLISHED)
    results = publish_results(db, contest)
    record_audit(
        db,
        actor=current_user,
        action="results.published",
        target_type="contest",
        target_id=contest_id,
        metadata={"result_count": len(results)},
    )
    db.commit()
    return list(db.scalars(select(PublicResult).where(PublicResult.contest_id == contest_id)).all())


@router.get("/api/public/contests/{contest_id}/results", response_model=list[PublicResultRead], tags=["Public"])
def get_public_results(contest_id: int, db: Session = Depends(get_db)) -> list[PublicResult]:
    contest = db.get(Contest, contest_id)
    if contest is None or contest.status != ContestStatus.RESULTS_PUBLISHED:
        raise HTTPException(status_code=404, detail="Published results not found")
    return list(
        db.scalars(
            select(PublicResult)
            .where(PublicResult.contest_id == contest_id)
            .order_by(PublicResult.rank_in_category)
        ).all()
    )


@router.get("/api/contests/{contest_id}/personal-report", response_model=PersonalReport)
def get_personal_report(
    contest_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> PersonalReport:
    participant = db.scalar(
        select(Participant).where(
            Participant.contest_id == contest_id,
            Participant.user_id == current_user.id,
        )
    )
    if participant is None:
        raise HTTPException(status_code=404, detail="Participation not found")
    scoring = db.scalar(
        select(ScoringResult).where(
            ScoringResult.contest_id == contest_id,
            ScoringResult.participant_id == participant.id,
        )
    )
    conflicts = list(
        db.scalars(
            select(CrossCheckConflict)
            .join(CrossCheckConflict.qso)
            .where(
                CrossCheckConflict.contest_id == contest_id,
                CrossCheckConflict.qso.has(QSO.participant_callsign == participant.callsign),
            )
        ).all()
    )
    return PersonalReport(
        participant=participant,
        scoring=scoring,
        removed_or_changed_qso=[
            {
                "qso_id": conflict.qso_id,
                "type": conflict.type,
                "status": conflict.status,
                "details": conflict.details,
            }
            for conflict in conflicts
        ],
    )
