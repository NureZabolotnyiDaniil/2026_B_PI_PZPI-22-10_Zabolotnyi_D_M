from collections import defaultdict

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.models import Contest, Participant, PublicResult, ScoringResult


def publish_results(db: Session, contest: Contest) -> list[PublicResult]:
    db.execute(delete(PublicResult).where(PublicResult.contest_id == contest.id))
    rows = list(
        db.execute(
            select(Participant, ScoringResult)
            .join(
                ScoringResult,
                (ScoringResult.participant_id == Participant.id)
                & (ScoringResult.contest_id == contest.id),
            )
            .where(Participant.contest_id == contest.id)
        ).all()
    )
    by_category: dict[str, list[tuple[Participant, ScoringResult]]] = defaultdict(list)
    for participant, scoring in rows:
        by_category[participant.category].append((participant, scoring))

    published: list[PublicResult] = []
    overall_rank = 1
    for _participant, scoring in sorted(rows, key=lambda row: row[1].final_score or 0, reverse=True):
        scoring_rank = overall_rank
        overall_rank += 1
        scoring._overall_rank = scoring_rank  # type: ignore[attr-defined]

    for category_rows in by_category.values():
        category_rows.sort(key=lambda row: row[1].final_score or 0, reverse=True)
        for rank, (participant, scoring) in enumerate(category_rows, start=1):
            result = PublicResult(
                contest_id=contest.id,
                participant_id=participant.id,
                rank_overall=getattr(scoring, "_overall_rank", None),
                rank_in_category=rank,
                callsign=participant.callsign,
                category=participant.category,
                claimed_score=scoring.system_claimed_score,
                final_score=scoring.final_score or scoring.system_claimed_score,
                confirmed_qso_count=scoring.confirmed_qso_count,
                removed_qso_count=scoring.rejected_qso_count + scoring.duplicate_qso_count,
            )
            db.add(result)
            published.append(result)
    db.flush()
    return published
