"""Contest lifecycle module."""
