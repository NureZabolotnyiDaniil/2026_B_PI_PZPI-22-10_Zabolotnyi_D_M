from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.core.database import get_db
from app.core.permissions import require_role
from app.domain import ContestStatus, UserRole
from app.models import Contest, ContestJudge, User
from app.modules.audit.service import record_audit
from app.modules.contests.service import (
    add_contest_judge_assignment,
    create_contest,
    remove_contest_judge_assignment,
    resolve_contest_judge_target_user,
    transition_contest,
    update_draft_contest,
)
from app.schemas import ContestCreate, ContestJudgeAdd, ContestJudgeRead, ContestRead, ContestUpdate

router = APIRouter(tags=["Contests"])


def get_contest_or_404(db: Session, contest_id: int) -> Contest:
    contest = db.scalar(
        select(Contest)
        .where(Contest.id == contest_id)
        .options(selectinload(Contest.scoring_rule))
    )
    if contest is None:
        raise HTTPException(status_code=404, detail="Contest not found")
    return contest


@router.get("/api/public/contests", response_model=list[ContestRead], tags=["Public"])
def list_public_contests(db: Session = Depends(get_db)) -> list[Contest]:
    return list(
        db.scalars(
            select(Contest)
            .where(Contest.status != ContestStatus.DRAFT)
            .options(selectinload(Contest.scoring_rule))
            .order_by(Contest.start_at_utc.desc())
        ).all()
    )


@router.get("/api/public/contests/{contest_id}", response_model=ContestRead, tags=["Public"])
def get_public_contest(contest_id: int, db: Session = Depends(get_db)) -> Contest:
    contest = get_contest_or_404(db, contest_id)
    if contest.status == ContestStatus.DRAFT:
        raise HTTPException(status_code=404, detail="Contest not found")
    return contest


@router.post("/api/organizer/contests", response_model=ContestRead, status_code=201)
def organizer_create_contest(
    payload: ContestCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ORGANIZER)),
) -> Contest:
    contest = create_contest(db, payload, current_user)
    record_audit(db, actor=current_user, action="contest.created", target_type="contest", target_id=contest.id)
    db.commit()
    return get_contest_or_404(db, contest.id)


@router.get("/api/organizer/contests", response_model=list[ContestRead])
def organizer_list_contests(
    db: Session = Depends(get_db),
    _: User = Depends(require_role(UserRole.ORGANIZER)),
) -> list[Contest]:
    return list(
        db.scalars(
            select(Contest)
            .options(selectinload(Contest.scoring_rule))
            .order_by(Contest.start_at_utc.desc())
        ).all()
    )


@router.get("/api/organizer/contests/{contest_id}", response_model=ContestRead)
def organizer_get_contest(
    contest_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_role(UserRole.ORGANIZER)),
) -> Contest:
    return get_contest_or_404(db, contest_id)


@router.patch("/api/organizer/contests/{contest_id}", response_model=ContestRead)
def organizer_update_contest(
    contest_id: int,
    payload: ContestUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ORGANIZER)),
) -> Contest:
    contest = get_contest_or_404(db, contest_id)
    update_draft_contest(db, contest, payload)
    record_audit(db, actor=current_user, action="contest.updated", target_type="contest", target_id=contest.id)
    db.commit()
    return get_contest_or_404(db, contest.id)


def transition_endpoint(
    contest_id: int,
    target: ContestStatus,
    action: str,
    db: Session,
    current_user: User,
) -> Contest:
    contest = get_contest_or_404(db, contest_id)
    transition_contest(contest, target)
    record_audit(db, actor=current_user, action=action, target_type="contest", target_id=contest.id)
    db.commit()
    return get_contest_or_404(db, contest.id)


@router.post("/api/organizer/contests/{contest_id}/publish", response_model=ContestRead)
def publish_contest(
    contest_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ORGANIZER)),
) -> Contest:
    return transition_endpoint(contest_id, ContestStatus.PUBLISHED, "contest.published", db, current_user)


@router.post("/api/organizer/contests/{contest_id}/open-logs", response_model=ContestRead)
def open_logs(
    contest_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ORGANIZER)),
) -> Contest:
    return transition_endpoint(
        contest_id, ContestStatus.ACCEPTING_LOGS, "contest.logs_opened", db, current_user
    )


@router.post("/api/organizer/contests/{contest_id}/close-logs", response_model=ContestRead)
def close_logs(
    contest_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ORGANIZER)),
) -> Contest:
    return transition_endpoint(
        contest_id, ContestStatus.LOG_SUBMISSION_CLOSED, "contest.logs_closed", db, current_user
    )


@router.get(
    "/api/organizer/contests/{contest_id}/judges",
    response_model=list[ContestJudgeRead],
    tags=["Organizer"],
)
def organizer_list_contest_judges(
    contest_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_role(UserRole.ORGANIZER)),
) -> list[ContestJudgeRead]:
    get_contest_or_404(db, contest_id)
    rows = list(
        db.scalars(
            select(ContestJudge)
            .where(ContestJudge.contest_id == contest_id)
            .options(selectinload(ContestJudge.user))
            .order_by(ContestJudge.created_at_utc.desc())
        ).all()
    )
    return [
        ContestJudgeRead(
            user_id=row.user_id,
            email=row.user.email,
            display_name=row.user.display_name,
            callsign=row.user.callsign,
            assigned_at_utc=row.created_at_utc,
        )
        for row in rows
    ]


@router.post(
    "/api/organizer/contests/{contest_id}/judges",
    response_model=ContestJudgeRead,
    status_code=201,
    tags=["Organizer"],
)
def organizer_add_contest_judge(
    contest_id: int,
    payload: ContestJudgeAdd,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ORGANIZER)),
) -> ContestJudgeRead:
    get_contest_or_404(db, contest_id)
    target = resolve_contest_judge_target_user(db, payload)
    row = add_contest_judge_assignment(db, contest_id, target)
    assigned_at = row.created_at_utc
    record_audit(
        db,
        actor=current_user,
        action="contest.judge_added",
        target_type="contest",
        target_id=contest_id,
        metadata={"judge_user_id": target.id},
    )
    db.commit()
    return ContestJudgeRead(
        user_id=target.id,
        email=target.email,
        display_name=target.display_name,
        callsign=target.callsign,
        assigned_at_utc=assigned_at,
    )


@router.delete(
    "/api/organizer/contests/{contest_id}/judges/{user_id}",
    status_code=204,
    tags=["Organizer"],
)
def organizer_remove_contest_judge(
    contest_id: int,
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ORGANIZER)),
) -> None:
    get_contest_or_404(db, contest_id)
    remove_contest_judge_assignment(db, contest_id, user_id)
    record_audit(
        db,
        actor=current_user,
        action="contest.judge_removed",
        target_type="contest",
        target_id=contest_id,
        metadata={"judge_user_id": user_id},
    )
    db.commit()


@router.post("/api/organizer/contests/{contest_id}/finalize", response_model=ContestRead)
def finalize_contest(
    contest_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ORGANIZER)),
) -> Contest:
    contest = get_contest_or_404(db, contest_id)
    if contest.status == ContestStatus.LOG_SUBMISSION_CLOSED:
        contest.status = ContestStatus.FINALIZED
    else:
        transition_contest(contest, ContestStatus.FINALIZED)
    record_audit(db, actor=current_user, action="contest.finalized", target_type="contest", target_id=contest.id)
    db.commit()
    return get_contest_or_404(db, contest.id)
