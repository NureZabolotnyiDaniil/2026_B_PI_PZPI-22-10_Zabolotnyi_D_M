from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.domain import ContestStatus, UserRole, UserStatus
from app.models import Contest, ContestJudge, ScoringRule, User
from app.schemas import ContestCreate, ContestJudgeAdd, ContestUpdate


def validate_contest_window(payload: ContestCreate | ContestUpdate) -> None:
    start = payload.start_at_utc
    end = payload.end_at_utc
    open_at = payload.log_submission_open_at_utc
    deadline = payload.log_submission_deadline_at_utc
    if start and end and end <= start:
        raise HTTPException(status_code=422, detail="Contest end must be after start")
    if open_at and deadline and deadline <= open_at:
        raise HTTPException(status_code=422, detail="Log deadline must be after opening time")


def create_contest(db: Session, payload: ContestCreate, creator: User) -> Contest:
    validate_contest_window(payload)
    contest = Contest(
        title=payload.title,
        description=payload.description,
        rules_text=payload.rules_text,
        start_at_utc=payload.start_at_utc,
        end_at_utc=payload.end_at_utc,
        log_submission_open_at_utc=payload.log_submission_open_at_utc,
        log_submission_deadline_at_utc=payload.log_submission_deadline_at_utc,
        allowed_bands=[band.upper() for band in payload.allowed_bands],
        allowed_modes=[mode.upper() for mode in payload.allowed_modes],
        categories=payload.categories,
        created_by_id=creator.id,
    )
    contest.scoring_rule = ScoringRule(**payload.scoring_rule.model_dump())
    db.add(contest)
    db.flush()
    return contest


def update_draft_contest(db: Session, contest: Contest, payload: ContestUpdate) -> Contest:
    if contest.status != ContestStatus.DRAFT:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Only draft contests can be edited")
    data = payload.model_dump(exclude_unset=True)
    validate_contest_window(payload)
    scoring_rule = data.pop("scoring_rule", None)
    for field, value in data.items():
        if field in {"allowed_bands", "allowed_modes"} and value is not None:
            value = [item.upper() for item in value]
        setattr(contest, field, value)
    if scoring_rule is not None:
        if contest.scoring_rule is None:
            contest.scoring_rule = ScoringRule(**scoring_rule)
        else:
            for field, value in scoring_rule.items():
                setattr(contest.scoring_rule, field, value)
    db.flush()
    return contest


def require_publishable(contest: Contest) -> None:
    missing = []
    for field in [
        "title",
        "description",
        "rules_text",
        "start_at_utc",
        "end_at_utc",
        "log_submission_open_at_utc",
        "log_submission_deadline_at_utc",
    ]:
        if not getattr(contest, field):
            missing.append(field)
    if not contest.categories:
        missing.append("categories")
    if contest.scoring_rule is None:
        missing.append("scoring_rule")
    if missing:
        raise HTTPException(status_code=422, detail={"missing": missing})


def resolve_contest_judge_target_user(db: Session, payload: ContestJudgeAdd) -> User:
    if payload.user_id is not None:
        user = db.get(User, payload.user_id)
    elif payload.email is not None:
        user = db.scalar(select(User).where(User.email == str(payload.email).lower()))
    else:
        raise HTTPException(status_code=422, detail="Provide user_id or email")
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    if user.status != UserStatus.ACTIVE:
        raise HTTPException(status_code=409, detail="Only active users can be contest judges")
    return user


def add_contest_judge_assignment(db: Session, contest_id: int, target: User) -> ContestJudge:
    roles = set(target.global_roles or [])
    if UserRole.JUDGE not in roles and UserRole.ADMIN not in roles:
        raise HTTPException(status_code=409, detail="User must have judge role before assignment")
    exists = db.scalar(
        select(ContestJudge).where(
            ContestJudge.contest_id == contest_id,
            ContestJudge.user_id == target.id,
        )
    )
    if exists is not None:
        raise HTTPException(status_code=409, detail="User is already a judge for this contest")
    row = ContestJudge(contest_id=contest_id, user_id=target.id)
    db.add(row)
    db.flush()
    return row


def remove_contest_judge_assignment(db: Session, contest_id: int, user_id: int) -> None:
    row = db.get(ContestJudge, (contest_id, user_id))
    if row is None:
        raise HTTPException(status_code=404, detail="Contest judge assignment not found")
    db.delete(row)
    db.flush()


def transition_contest(contest: Contest, target: ContestStatus) -> Contest:
    allowed: dict[ContestStatus, set[ContestStatus]] = {
        ContestStatus.DRAFT: {ContestStatus.PUBLISHED},
        ContestStatus.PUBLISHED: {ContestStatus.ACCEPTING_LOGS},
        ContestStatus.ACCEPTING_LOGS: {ContestStatus.LOG_SUBMISSION_CLOSED},
        ContestStatus.LOG_SUBMISSION_CLOSED: {ContestStatus.CHECKING, ContestStatus.FINALIZED},
        ContestStatus.CHECKING: {ContestStatus.JUDGE_REVIEW, ContestStatus.FINALIZED},
        ContestStatus.JUDGE_REVIEW: {ContestStatus.FINALIZED},
        ContestStatus.FINALIZED: {ContestStatus.RESULTS_PUBLISHED},
        ContestStatus.RESULTS_PUBLISHED: {ContestStatus.ARCHIVED},
    }
    if target not in allowed.get(contest.status, set()):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Cannot transition from {contest.status} to {target}",
        )
    if target == ContestStatus.PUBLISHED:
        require_publishable(contest)
    contest.status = target
    return contest
