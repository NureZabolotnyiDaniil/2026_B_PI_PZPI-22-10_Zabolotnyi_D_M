from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.permissions import require_role
from app.domain import UserRole
from app.models import AuditEvent, User
from app.schemas import AuditEventRead

router = APIRouter(prefix="/api/admin/audit-events", tags=["Admin"])


@router.get("", response_model=list[AuditEventRead])
def list_audit_events(
    db: Session = Depends(get_db),
    _: User = Depends(require_role(UserRole.ADMIN)),
) -> list[AuditEvent]:
    return list(db.scalars(select(AuditEvent).order_by(AuditEvent.timestamp_utc.desc())).all())
