from typing import Any

from sqlalchemy.orm import Session

from app.models import AuditEvent, User


def record_audit(
    db: Session,
    *,
    actor: User | None,
    action: str,
    target_type: str,
    target_id: int | None,
    metadata: dict[str, Any] | None = None,
    stage: str | None = None,
) -> AuditEvent:
    payload = metadata or {}
    if stage:
        payload = {"stage": stage, **payload}
    event = AuditEvent(
        actor_id=actor.id if actor else None,
        action=action,
        target_type=target_type,
        target_id=target_id,
        metadata_json=payload,
    )
    db.add(event)
    return event
