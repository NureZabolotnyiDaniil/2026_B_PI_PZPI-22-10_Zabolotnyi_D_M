import logging

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.permissions import get_current_user
from app.models import User
from app.modules.audit.service import record_audit
from app.modules.auth.service import authenticate_user, create_user, issue_token
from app.schemas import LoginRequest, ProfileUpdate, Token, UserCreate, UserRead

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Auth"])


@router.post("/api/auth/register", response_model=UserRead, status_code=201)
def register(payload: UserCreate, db: Session = Depends(get_db)) -> User:
    logger.info("auth.register.start email=%s", payload.email)
    user = create_user(db, payload)
    record_audit(db, actor=user, action="auth.register", target_type="user", target_id=user.id)
    db.commit()
    db.refresh(user)
    logger.info("auth.register.done user_id=%s roles=%s", user.id, list(user.global_roles or []))
    return user


@router.post("/api/auth/login", response_model=Token)
def login(payload: LoginRequest, db: Session = Depends(get_db)) -> Token:
    logger.info("auth.login.attempt email=%s", payload.email)
    user = authenticate_user(db, payload.email, payload.password)
    record_audit(db, actor=user, action="auth.login", target_type="user", target_id=user.id)
    db.commit()
    logger.info("auth.login.ok user_id=%s roles=%s", user.id, list(user.global_roles or []))
    return Token(access_token=issue_token(user))


@router.post("/api/auth/logout", status_code=204)
def logout(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> None:
    record_audit(db, actor=current_user, action="auth.logout", target_type="user", target_id=current_user.id)
    db.commit()


@router.get("/api/me", response_model=UserRead)
def me(current_user: User = Depends(get_current_user)) -> User:
    return current_user


@router.patch("/api/me/profile", response_model=UserRead)
def update_profile(
    payload: ProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> User:
    if payload.display_name is not None:
        current_user.display_name = payload.display_name
    if payload.callsign is not None:
        current_user.callsign = payload.callsign.upper()
    record_audit(
        db,
        actor=current_user,
        action="auth.profile_updated",
        target_type="user",
        target_id=current_user.id,
    )
    db.commit()
    db.refresh(current_user)
    return current_user
