"""Authentication module."""
