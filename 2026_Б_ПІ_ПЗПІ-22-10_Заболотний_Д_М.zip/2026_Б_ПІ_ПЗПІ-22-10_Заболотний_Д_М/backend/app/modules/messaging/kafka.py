import json
import logging
from typing import Any

try:
    from kafka import KafkaConsumer, KafkaProducer
except Exception:  # pragma: no cover - optional in test env
    KafkaConsumer = None  # type: ignore[assignment]
    KafkaProducer = None  # type: ignore[assignment]

from app.core.config import get_settings

logger = logging.getLogger(__name__)

_producer: Any | None = None


def _servers() -> list[str]:
    return [server.strip() for server in get_settings().kafka_bootstrap_servers.split(",") if server.strip()]


def create_producer() -> KafkaProducer:
    if KafkaProducer is None:
        raise RuntimeError("kafka-python is not installed")
    return KafkaProducer(
        bootstrap_servers=_servers(),
        value_serializer=lambda value: json.dumps(value).encode("utf-8"),
        key_serializer=lambda value: value.encode("utf-8") if value else None,
    )


def get_producer() -> KafkaProducer:
    global _producer
    if _producer is None:
        _producer = create_producer()
    return _producer


def close_producer() -> None:
    global _producer
    if _producer is not None:
        _producer.close()
        _producer = None


def create_consumer(*, topic: str, group_id: str | None = None) -> KafkaConsumer:
    if KafkaConsumer is None:
        raise RuntimeError("kafka-python is not installed")
    settings = get_settings()
    return KafkaConsumer(
        topic,
        bootstrap_servers=_servers(),
        group_id=group_id or settings.kafka_group_id,
        value_deserializer=lambda value: json.loads(value.decode("utf-8")),
        auto_offset_reset="earliest",
        enable_auto_commit=False,
    )


def publish(topic: str, *, key: str | None, payload: dict[str, Any]) -> None:
    producer = get_producer()
    logger.debug("kafka.publish topic=%s key=%s payload_keys=%s", topic, key, list(payload.keys()))
    producer.send(topic, key=key, value=payload)
    producer.flush()
    logger.info("kafka.publish.ok topic=%s key=%s", topic, key)
