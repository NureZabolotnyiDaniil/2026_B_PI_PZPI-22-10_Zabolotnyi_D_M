"""Messaging primitives for event-driven processing."""
