from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field


class MatchingRequestedEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: str(uuid4()))
    schema_version: str = "v1"
    occurred_at_utc: datetime = Field(default_factory=lambda: datetime.now(UTC))
    contest_id: int
    job_id: int
    actor_id: int | None = None
    replay: bool = False
    retry_count: int = 0


class LogUploadedEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: str(uuid4()))
    schema_version: str = "v1"
    occurred_at_utc: datetime = Field(default_factory=lambda: datetime.now(UTC))
    contest_id: int
    submission_id: int
    participant_id: int
    job_id: int | None = None
    actor_id: int | None = None
    retry_count: int = 0


class SubmissionParsedEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: str(uuid4()))
    schema_version: str = "v1"
    occurred_at_utc: datetime = Field(default_factory=lambda: datetime.now(UTC))
    contest_id: int
    submission_id: int
    participant_id: int
    qso_count: int
    blocking_issue_count: int


class QsoIngestedEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: str(uuid4()))
    schema_version: str = "v1"
    occurred_at_utc: datetime = Field(default_factory=lambda: datetime.now(UTC))
    contest_id: int
    submission_id: int
    participant_id: int
    qso_id: int
    time_bucket: datetime
    band: str
    mode: str
    participant_callsign: str
    counterparty_callsign: str
    retry_count: int = 0


class QsoIndexedEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: str(uuid4()))
    schema_version: str = "v1"
    occurred_at_utc: datetime = Field(default_factory=lambda: datetime.now(UTC))
    contest_id: int
    qso_id: int
    time_bucket: datetime
    band: str
    mode: str


class QsoMatchedEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: str(uuid4()))
    schema_version: str = "v2"
    occurred_at_utc: datetime = Field(default_factory=lambda: datetime.now(UTC))
    contest_id: int
    qso_id: int
    matched_qso_id: int | None = None
    decision_id: int
    status: str
    confidence: float
    pipeline_decision: str | None = None
    explainability: dict[str, Any] | None = None


class MatchingCompletedEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: str(uuid4()))
    schema_version: str = "v1"
    occurred_at_utc: datetime = Field(default_factory=lambda: datetime.now(UTC))
    contest_id: int
    job_id: int
    summary: dict[str, Any]


class MatchingFailedEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: str(uuid4()))
    schema_version: str = "v1"
    occurred_at_utc: datetime = Field(default_factory=lambda: datetime.now(UTC))
    contest_id: int
    job_id: int
    error_message: str
    retry_count: int = 0


class ConflictDetectedEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: str(uuid4()))
    schema_version: str = "v1"
    occurred_at_utc: datetime = Field(default_factory=lambda: datetime.now(UTC))
    contest_id: int
    conflict_id: int
    qso_id: int
    conflict_type: str


class DeadLetterEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: str(uuid4()))
    schema_version: str = "v1"
    occurred_at_utc: datetime = Field(default_factory=lambda: datetime.now(UTC))
    source_event_type: str
    source_event_id: str
    error_message: str
    payload: dict[str, Any]
