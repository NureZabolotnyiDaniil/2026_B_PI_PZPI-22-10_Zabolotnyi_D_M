import logging
from collections.abc import Iterable
from datetime import timedelta
from typing import Any

from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.domain import EventOutboxStatus
from app.models import EventOutbox, utc_now
from app.modules.messaging.kafka import publish

logger = logging.getLogger(__name__)

EVENT_TOPIC_SETTINGS = {
    "log.uploaded.v1": "kafka_topic_log_uploaded",
    "submission.parsed.v1": "kafka_topic_submission_parsed",
    "qso.ingested.v1": "kafka_topic_qso_ingested",
    "qso.indexed.v1": "kafka_topic_qso_indexed",
    "qso.matched.v1": "kafka_topic_qso_matched",
    "matching.requested.v1": "kafka_topic_matching_requested",
    "matching.completed.v1": "kafka_topic_matching_completed",
    "matching.failed.v1": "kafka_topic_matching_failed",
    "matching.conflict_detected.v1": "kafka_topic_conflict_detected",
    "dead_letter.v1": "kafka_topic_dead_letter",
}


def event_payload(event: BaseModel | dict[str, Any]) -> dict[str, Any]:
    if isinstance(event, BaseModel):
        return event.model_dump(mode="json")
    return event


def enqueue_event(
    db: Session,
    *,
    event_type: str,
    aggregate_type: str,
    aggregate_id: int,
    partition_key: str,
    payload: BaseModel | dict[str, Any],
    idempotency_key: str,
) -> EventOutbox:
    existing = db.scalar(
        select(EventOutbox).where(EventOutbox.idempotency_key == idempotency_key)
    )
    if existing is not None:
        logger.debug(
            "outbox.enqueue.duplicate event_type=%s idempotency_key=%s outbox_id=%s",
            event_type,
            idempotency_key,
            existing.id,
        )
        return existing
    event = EventOutbox(
        event_type=event_type,
        aggregate_type=aggregate_type,
        aggregate_id=aggregate_id,
        partition_key=partition_key,
        payload=event_payload(payload),
        idempotency_key=idempotency_key,
    )
    db.add(event)
    logger.info(
        "outbox.enqueue event_type=%s aggregate=%s/%s partition=%s key=%s",
        event_type,
        aggregate_type,
        aggregate_id,
        partition_key,
        idempotency_key,
    )
    return event


def pending_events(db: Session, *, limit: int = 100) -> Iterable[EventOutbox]:
    return db.scalars(
        select(EventOutbox)
        .where(
            EventOutbox.status == EventOutboxStatus.PENDING,
            EventOutbox.available_at_utc <= utc_now(),
        )
        .order_by(EventOutbox.id.asc())
        .limit(limit)
    )


def topic_for_event(event_type: str) -> str:
    setting_name = EVENT_TOPIC_SETTINGS.get(event_type)
    if setting_name is None:
        raise ValueError(f"No Kafka topic configured for event type {event_type}")
    return str(getattr(get_settings(), setting_name))


def publish_outbox_event(db: Session, event: EventOutbox) -> None:
    topic = topic_for_event(event.event_type)
    try:
        publish(topic, key=event.partition_key, payload=event.payload)
    except Exception as exc:
        event.attempts += 1
        event.last_error = str(exc)
        event.available_at_utc = utc_now() + timedelta(seconds=min(60, 2**event.attempts))
        if event.attempts >= get_settings().worker_max_retries:
            event.status = EventOutboxStatus.FAILED
        logger.warning(
            "outbox.publish.failed event_id=%s event_type=%s attempts=%s err=%s",
            event.id,
            event.event_type,
            event.attempts,
            exc,
        )
        raise
    event.status = EventOutboxStatus.PUBLISHED
    event.published_at_utc = utc_now()
    event.last_error = None
    logger.info(
        "outbox.publish.ok event_id=%s event_type=%s topic=%s key=%s",
        event.id,
        event.event_type,
        topic,
        event.partition_key,
    )


def dispatch_pending_events(db: Session, *, limit: int = 100) -> int:
    dispatched = 0
    event_ids = list(
        db.scalars(
            select(EventOutbox.id)
            .where(
                EventOutbox.status == EventOutboxStatus.PENDING,
                EventOutbox.available_at_utc <= utc_now(),
            )
            .order_by(EventOutbox.id.asc())
            .limit(limit)
        )
    )
    db.commit()
    for event_id in event_ids:
        event = db.scalar(
            select(EventOutbox)
            .where(
                EventOutbox.id == event_id,
                EventOutbox.status == EventOutboxStatus.PENDING,
                EventOutbox.available_at_utc <= utc_now(),
            )
            .with_for_update(skip_locked=True)
        )
        if event is None:
            db.rollback()
            continue
        try:
            publish_outbox_event(db, event)
        except Exception:
            db.commit()
            continue
        else:
            db.commit()
            dispatched += 1
    if dispatched:
        logger.info("outbox.dispatch.batch dispatched=%s limit=%s", dispatched, limit)
    return dispatched
