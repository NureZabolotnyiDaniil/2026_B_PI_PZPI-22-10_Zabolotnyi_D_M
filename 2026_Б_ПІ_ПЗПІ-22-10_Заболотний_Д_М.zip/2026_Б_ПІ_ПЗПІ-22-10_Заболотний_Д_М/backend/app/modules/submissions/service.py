import logging

from fastapi import HTTPException, UploadFile
from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from app.core.config import get_settings
from app.domain import IssueSeverity, ParticipantStatus, SubmissionStatus
from app.models import QSO, Contest, LogSubmission, Participant, User, ValidationIssue
from app.modules.audit.service import record_audit
from app.modules.cabrillo.parser import parse_cabrillo_text
from app.modules.cross_check.index import populate_qso_index_fields
from app.modules.messaging.contracts import (
    QsoIngestedEvent,
    SubmissionParsedEvent,
)
from app.modules.messaging.outbox import enqueue_event
from app.modules.scoring.service import calculate_claimed_score
from app.modules.submissions.storage import read_original_submission, save_original_submission
from app.modules.validation.service import has_blocking_issues, validate_cabrillo

logger = logging.getLogger(__name__)


def decode_upload(content: bytes) -> str:
    if len(content) > get_settings().max_upload_bytes:
        raise HTTPException(status_code=413, detail="File is too large")
    try:
        return content.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise HTTPException(status_code=422, detail="File must be UTF-8 text") from exc


def create_submission(
    db: Session,
    *,
    contest: Contest,
    participant: Participant,
    upload: UploadFile,
    actor,
) -> LogSubmission:
    logger.info(
        "submission.create.start contest_id=%s participant_id=%s actor=%s filename=%s",
        contest.id,
        participant.id,
        getattr(actor, "id", None),
        upload.filename,
    )
    content = upload.file.read()
    logger.debug("submission.create.read_bytes size=%s", len(content))
    decode_upload(content)
    latest_version = db.scalar(
        select(func.max(LogSubmission.version)).where(LogSubmission.participant_id == participant.id)
    )
    version = (latest_version or 0) + 1
    path, file_hash = save_original_submission(
        content, contest_id=contest.id, participant_id=participant.id, version=version
    )

    submission = LogSubmission(
        participant_id=participant.id,
        contest_id=contest.id,
        original_file_path=path,
        original_file_hash=file_hash,
        version=version,
        status=SubmissionStatus.PARSING_QUEUED,
        parsed_metadata={},
    )
    db.add(submission)
    db.flush()

    record_audit(
        db,
        actor=actor,
        action="submission.upload_received",
        target_type="log_submission",
        target_id=submission.id,
        metadata={
            "contest_id": contest.id,
            "participant_id": participant.id,
            "version": version,
        },
    )
    logger.info(
        "submission.create.done submission_id=%s version=%s status=%s",
        submission.id,
        version,
        submission.status.value,
    )
    return submission


def parse_and_persist_submission(
    db: Session,
    *,
    submission_id: int,
    actor: User | None = None,
) -> LogSubmission | None:
    logger.info("submission.parse.start submission_id=%s", submission_id)
    submission = db.scalar(
        select(LogSubmission)
        .where(LogSubmission.id == submission_id)
        .options(
            selectinload(LogSubmission.participant).selectinload(Participant.contest).selectinload(Contest.scoring_rule),
            selectinload(LogSubmission.qso_records),
        )
    )
    if submission is None:
        logger.warning("submission.parse.missing submission_id=%s", submission_id)
        return None
    if submission.status in {SubmissionStatus.ACCEPTED, SubmissionStatus.VALIDATION_FAILED}:
        logger.debug(
            "submission.parse.skip already_processed submission_id=%s status=%s",
            submission.id,
            submission.status.value,
        )
        return submission

    participant = submission.participant
    contest = participant.contest
    submission.status = SubmissionStatus.PARSING
    text = read_original_submission(submission.original_file_path)
    parsed = parse_cabrillo_text(text)
    submission.parsed_metadata = parsed.headers
    logger.info(
        "submission.parse.parsed submission_id=%s qso_count=%s headers=%s",
        submission.id,
        len(parsed.qso_records),
        list(parsed.headers.keys()),
    )

    issues = validate_cabrillo(text, parsed, contest)
    logger.debug(
        "submission.parse.validation submission_id=%s issues=%s blocking=%s",
        submission.id,
        len(issues),
        sum(1 for i in issues if i.severity == IssueSeverity.BLOCKING),
    )
    for issue in issues:
        db.add(
            ValidationIssue(
                submission_id=submission.id,
                type=issue.type,
                severity=issue.severity,
                message=issue.message,
                line_number=issue.line_number,
            )
        )

    if has_blocking_issues(issues):
        submission.status = SubmissionStatus.VALIDATION_FAILED
        participant.status = ParticipantStatus.SUBMITTED
        logger.warning(
            "submission.parse.blocked submission_id=%s blocking_issues=%s",
            submission.id,
            sum(1 for i in issues if i.severity == IssueSeverity.BLOCKING),
        )
    else:
        for old_submission in participant.submissions:
            if old_submission.id != submission.id and old_submission.status != SubmissionStatus.SUPERSEDED:
                old_submission.status = SubmissionStatus.SUPERSEDED
        created_qsos: list[QSO] = []
        for parsed_qso in parsed.qso_records:
            qso = QSO(
                submission_id=submission.id,
                contest_id=contest.id,
                participant_callsign=parsed_qso.participant_callsign,
                counterparty_callsign=parsed_qso.counterparty_callsign,
                qso_at_utc=parsed_qso.qso_at_utc,
                band=parsed_qso.band,
                frequency=parsed_qso.frequency,
                mode=parsed_qso.mode,
                sent_exchange=parsed_qso.sent_exchange,
                received_exchange=parsed_qso.received_exchange,
                raw_line=parsed_qso.raw_line,
                line_number=parsed_qso.line_number,
            )
            populate_qso_index_fields(qso)
            db.add(qso)
            created_qsos.append(qso)
        db.flush()
        for qso in created_qsos:
            qso_event = QsoIngestedEvent(
                contest_id=contest.id,
                submission_id=submission.id,
                participant_id=participant.id,
                qso_id=qso.id,
                time_bucket=qso.time_bucket,
                band=qso.band,
                mode=qso.mode,
                participant_callsign=qso.participant_callsign,
                counterparty_callsign=qso.counterparty_callsign,
            )
            enqueue_event(
                db,
                event_type="qso.ingested.v1",
                aggregate_type="qso",
                aggregate_id=qso.id,
                partition_key=(
                    f"{contest.id}:{qso.time_bucket.isoformat()}:{qso.band.upper()}"
                ),
                payload=qso_event,
                idempotency_key=f"qso-ingested:{qso.id}",
            )
        participant.current_submission_id = submission.id
        participant.status = ParticipantStatus.ACCEPTED
        submission.status = SubmissionStatus.ACCEPTED
        db.refresh(submission, attribute_names=["qso_records"])
        calculate_claimed_score(db, participant, submission)

    record_audit(
        db,
        actor=actor,
        action="submission.uploaded",
        target_type="log_submission",
        target_id=submission.id,
        metadata={
            "contest_id": contest.id,
            "participant_id": participant.id,
            "version": submission.version,
            "blocking_issues": sum(1 for issue in issues if issue.severity == IssueSeverity.BLOCKING),
        },
    )
    parsed_event = SubmissionParsedEvent(
        contest_id=contest.id,
        submission_id=submission.id,
        participant_id=participant.id,
        qso_count=len(parsed.qso_records),
        blocking_issue_count=sum(1 for issue in issues if issue.severity == IssueSeverity.BLOCKING),
    )
    enqueue_event(
        db,
        event_type="submission.parsed.v1",
        aggregate_type="log_submission",
        aggregate_id=submission.id,
        partition_key=str(contest.id),
        payload=parsed_event,
        idempotency_key=f"submission-parsed:{submission.id}",
    )
    logger.info(
        "submission.parse.done submission_id=%s status=%s qso_count=%s",
        submission.id,
        submission.status.value,
        len(parsed.qso_records),
    )
    return submission
