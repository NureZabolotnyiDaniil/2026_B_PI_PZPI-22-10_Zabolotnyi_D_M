from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.core.database import get_db
from app.core.permissions import can_access_judge_workbench, get_current_user, require_role
from app.domain import ContestStatus, ProcessingJobType, UserRole
from app.models import Contest, LogSubmission, Participant, User, ValidationIssue
from app.modules.messaging.contracts import LogUploadedEvent
from app.modules.messaging.outbox import enqueue_event
from app.modules.processing_jobs.service import create_queued_job
from app.modules.submissions.service import create_submission
from app.schemas import (
    SubmissionDetail,
    SubmissionRead,
    SubmissionUploadAccepted,
    ValidationIssueRead,
)

router = APIRouter(tags=["Submissions"])


def get_submission_or_404(db: Session, submission_id: int) -> LogSubmission:
    submission = db.scalar(
        select(LogSubmission)
        .where(LogSubmission.id == submission_id)
        .options(
            selectinload(LogSubmission.issues),
            selectinload(LogSubmission.qso_records),
        )
    )
    if submission is None:
        raise HTTPException(status_code=404, detail="Submission not found")
    return submission


@router.post(
    "/api/contests/{contest_id}/submissions",
    response_model=SubmissionUploadAccepted,
    status_code=202,
)
def upload_submission(
    contest_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> dict[str, object]:
    contest = db.get(Contest, contest_id)
    if contest is None:
        raise HTTPException(status_code=404, detail="Contest not found")
    if contest.status != ContestStatus.ACCEPTING_LOGS:
        raise HTTPException(status_code=409, detail="Contest is not accepting logs")
    participant = db.scalar(
        select(Participant)
        .where(Participant.user_id == current_user.id, Participant.contest_id == contest_id)
        .options(selectinload(Participant.submissions), selectinload(Participant.contest).selectinload(Contest.scoring_rule))
    )
    if participant is None:
        raise HTTPException(status_code=404, detail="Register participation before uploading")
    submission = create_submission(
        db, contest=contest, participant=participant, upload=file, actor=current_user
    )
    job = create_queued_job(
        db,
        contest_id=contest.id,
        submission_id=submission.id,
        job_type=ProcessingJobType.PARSING,
        actor=current_user,
    )
    event = LogUploadedEvent(
        contest_id=contest.id,
        submission_id=submission.id,
        participant_id=participant.id,
        job_id=job.id,
        actor_id=current_user.id,
    )
    enqueue_event(
        db,
        event_type="log.uploaded.v1",
        aggregate_type="log_submission",
        aggregate_id=submission.id,
        partition_key=str(contest.id),
        payload=event,
        idempotency_key=f"log-uploaded:{submission.id}",
    )
    db.commit()
    db.refresh(job)
    return {"submission": get_submission_or_404(db, submission.id), "job": job}


@router.get("/api/submissions/{submission_id}", response_model=SubmissionDetail)
def get_submission(
    submission_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> LogSubmission:
    submission = get_submission_or_404(db, submission_id)
    participant = db.get(Participant, submission.participant_id)
    if participant and participant.user_id == current_user.id:
        return submission
    if can_access_judge_workbench(db, current_user, submission.contest_id):
        return submission
    raise HTTPException(status_code=403, detail="Not allowed to view this submission")


@router.get("/api/submissions/{submission_id}/issues", response_model=list[ValidationIssueRead])
def get_submission_issues(
    submission_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> list[ValidationIssue]:
    submission = get_submission(submission_id, db, current_user)
    return submission.issues


@router.get(
    "/api/organizer/contests/{contest_id}/submissions",
    response_model=list[SubmissionRead],
    tags=["Organizer"],
)
def list_contest_submissions(
    contest_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_role(UserRole.ORGANIZER)),
) -> list[LogSubmission]:
    return list(
        db.scalars(
            select(LogSubmission)
            .where(LogSubmission.contest_id == contest_id)
            .order_by(LogSubmission.uploaded_at_utc.desc())
        ).all()
    )
