"""Log submission module."""
