import hashlib
from pathlib import Path

from app.core.config import get_settings


def compute_hash(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def save_original_submission(
    content: bytes, *, contest_id: int, participant_id: int, version: int
) -> tuple[str, str]:
    settings = get_settings()
    relative_path = Path("submissions") / str(contest_id) / str(participant_id) / f"v{version}.log"
    full_path = settings.storage_path / relative_path
    full_path.parent.mkdir(parents=True, exist_ok=True)
    full_path.write_bytes(content)
    return str(relative_path), compute_hash(content)


def read_original_submission(path: str) -> str:
    return (get_settings().storage_path / path).read_text(encoding="utf-8")
