from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.permissions import can_access_judge_workbench, get_current_user
from app.models import LogSubmission, Participant, ProcessingJob, User
from app.schemas import ProcessingJobRead

router = APIRouter(prefix="/api/jobs", tags=["Jobs"])


@router.get("/{job_id}", response_model=ProcessingJobRead)
def get_job(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> ProcessingJob:
    job = db.get(ProcessingJob, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    if job.submission_id is not None:
        submission = db.get(LogSubmission, job.submission_id)
        participant = (
            db.get(Participant, submission.participant_id) if submission is not None else None
        )
        if participant is not None and participant.user_id == current_user.id:
            return job
    if job.contest_id is not None and can_access_judge_workbench(
        db, current_user, job.contest_id
    ):
        return job
    if job.started_by_id == current_user.id:
        return job
    raise HTTPException(status_code=403, detail="Not allowed to view this job")
