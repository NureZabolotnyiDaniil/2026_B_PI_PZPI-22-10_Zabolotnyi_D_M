from datetime import UTC, datetime
from typing import Any

from sqlalchemy.orm import Session

from app.domain import ProcessingJobStatus, ProcessingJobType
from app.models import ProcessingJob, User


def create_queued_job(
    db: Session,
    *,
    contest_id: int | None,
    submission_id: int | None = None,
    job_type: ProcessingJobType,
    actor: User | None,
) -> ProcessingJob:
    job = ProcessingJob(
        contest_id=contest_id,
        submission_id=submission_id,
        type=job_type,
        status=ProcessingJobStatus.QUEUED,
        started_by_id=actor.id if actor else None,
        summary={},
    )
    db.add(job)
    db.flush()
    return job


def mark_job_running(db: Session, job: ProcessingJob) -> ProcessingJob:
    if job.status == ProcessingJobStatus.RUNNING:
        return job
    if job.status != ProcessingJobStatus.QUEUED:
        raise ValueError(f"Cannot start job in terminal state {job.status.value}")
    job.status = ProcessingJobStatus.RUNNING
    job.started_at_utc = datetime.now(UTC)
    job.finished_at_utc = None
    return job


def mark_job_succeeded(db: Session, job: ProcessingJob, *, summary: dict[str, Any]) -> ProcessingJob:
    if job.status == ProcessingJobStatus.SUCCEEDED:
        return job
    if job.status != ProcessingJobStatus.RUNNING:
        raise ValueError(f"Cannot succeed job from state {job.status.value}")
    job.status = ProcessingJobStatus.SUCCEEDED
    job.summary = summary
    job.error_message = None
    job.finished_at_utc = datetime.now(UTC)
    return job


def mark_job_failed(db: Session, job: ProcessingJob, *, error_message: str) -> ProcessingJob:
    if job.status == ProcessingJobStatus.FAILED:
        return job
    if job.status not in {ProcessingJobStatus.QUEUED, ProcessingJobStatus.RUNNING}:
        raise ValueError(f"Cannot fail job from state {job.status.value}")
    job.status = ProcessingJobStatus.FAILED
    job.error_message = error_message
    job.finished_at_utc = datetime.now(UTC)
    return job


def mark_job_queued_for_retry(
    db: Session,
    job: ProcessingJob,
    *,
    retry_count: int,
    error_message: str,
) -> ProcessingJob:
    if job.status == ProcessingJobStatus.QUEUED:
        return job
    if job.status != ProcessingJobStatus.RUNNING:
        raise ValueError(f"Cannot retry job from state {job.status.value}")
    job.status = ProcessingJobStatus.QUEUED
    job.summary = {**(job.summary or {}), "retry_count": retry_count}
    job.error_message = error_message
    job.finished_at_utc = None
    return job
