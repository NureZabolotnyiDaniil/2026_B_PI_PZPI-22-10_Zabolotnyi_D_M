"""Core application services."""
