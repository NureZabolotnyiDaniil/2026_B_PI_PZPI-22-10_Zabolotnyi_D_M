from itertools import cycle

from sqlalchemy.orm import Session

from app.core.database import ReadSessionLocals

_read_factory_cycle = cycle(ReadSessionLocals)


def get_replica_session() -> Session:
    """Returns a best-effort read replica session (round-robin policy)."""
    factory = next(_read_factory_cycle)
    return factory()
