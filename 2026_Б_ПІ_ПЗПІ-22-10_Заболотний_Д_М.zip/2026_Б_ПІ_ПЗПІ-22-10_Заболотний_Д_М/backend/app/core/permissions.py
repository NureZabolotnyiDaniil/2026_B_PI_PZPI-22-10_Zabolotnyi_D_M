from collections.abc import Callable

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer, OAuth2PasswordBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import decode_access_token
from app.domain import UserRole, UserStatus
from app.models import ContestJudge, User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login", auto_error=False)
http_bearer = HTTPBearer(auto_error=False)


def get_current_user(
    bearer: HTTPAuthorizationCredentials | None = Security(http_bearer),
    oauth_token: str | None = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User:
    token = (bearer.credentials if bearer else None) or oauth_token
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    user_id = decode_access_token(token)
    if user_id is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
    user = db.get(User, int(user_id))
    if user is None or user.status != UserStatus.ACTIVE:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Inactive user")
    return user


def require_role(*roles: UserRole) -> Callable[[User], User]:
    def dependency(current_user: User = Depends(get_current_user)) -> User:
        user_roles = set(current_user.global_roles or [])
        if UserRole.ADMIN in user_roles or any(role in user_roles for role in roles):
            return current_user
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient role")

    return dependency


def ensure_contest_staff(user: User) -> None:
    roles = set(user.global_roles or [])
    allowed = {UserRole.ORGANIZER, UserRole.JUDGE, UserRole.ADMIN}
    if roles.isdisjoint(allowed):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Contest staff required")


def can_access_judge_workbench(db: Session, user: User, contest_id: int) -> bool:
    roles = set(user.global_roles or [])
    if UserRole.ADMIN in roles:
        return True
    if UserRole.ORGANIZER in roles:
        return True
    if UserRole.JUDGE not in roles:
        return False
    assigned = db.scalar(
        select(ContestJudge.user_id).where(
            ContestJudge.contest_id == contest_id,
            ContestJudge.user_id == user.id,
        )
    )
    return assigned is not None
