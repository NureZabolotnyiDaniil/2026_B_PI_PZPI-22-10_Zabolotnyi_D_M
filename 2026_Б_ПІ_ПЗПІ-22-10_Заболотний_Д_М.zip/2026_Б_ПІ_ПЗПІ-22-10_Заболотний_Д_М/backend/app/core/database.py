from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.core.config import get_settings


class Base(DeclarativeBase):
    pass


settings = get_settings()
write_engine = create_engine(
    settings.database_url, pool_pre_ping=True, echo=settings.db_echo
)
read_engines = [
    create_engine(url, pool_pre_ping=True, echo=settings.db_echo)
    for url in (settings.read_database_urls if settings.read_database_urls else [settings.database_url])
]
WriteSessionLocal = sessionmaker(
    bind=write_engine, autoflush=False, autocommit=False, expire_on_commit=False
)
ReadSessionLocals = [
    sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False)
    for engine in read_engines
]


def get_db() -> Generator[Session, None, None]:
    db = WriteSessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_write_db() -> Generator[Session, None, None]:
    db = WriteSessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_read_db() -> Generator[Session, None, None]:
    db = ReadSessionLocals[0]()
    try:
        yield db
    finally:
        db.close()
