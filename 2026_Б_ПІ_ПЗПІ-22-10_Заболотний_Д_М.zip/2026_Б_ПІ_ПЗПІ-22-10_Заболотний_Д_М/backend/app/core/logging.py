"""Centralised logging configuration for API and workers.

Use ``configure_logging()`` once at process startup. After that any
``logging.getLogger(__name__)`` will inherit the formatter and level set here.

Behaviour can be tweaked via env variables:

- ``RADIOSCORE_LOG_LEVEL`` — root level for app loggers (default ``DEBUG``).
- ``RADIOSCORE_LOG_JSON`` — set to ``1`` to emit JSON lines (handy for log
  aggregation); otherwise human-readable text is produced.
- ``RADIOSCORE_LOG_SQL`` — set to ``1`` to surface SQLAlchemy engine logs at
  INFO so every executed statement appears in the console.

The module also exposes a :class:`RequestIdFilter` so the ASGI middleware can
attach a per-request id that ends up in every log record produced during the
handler.
"""

from __future__ import annotations

import json
import logging
import logging.config
import os
import sys
from contextvars import ContextVar
from typing import Any

_REQUEST_ID_CTX: ContextVar[str | None] = ContextVar("request_id", default=None)


def set_request_id(request_id: str | None) -> None:
    _REQUEST_ID_CTX.set(request_id)


def get_request_id() -> str | None:
    return _REQUEST_ID_CTX.get()


class RequestIdFilter(logging.Filter):
    """Inject ``request_id`` from contextvar into every log record."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = get_request_id() or "-"
        return True


class JsonFormatter(logging.Formatter):
    """Minimal JSON formatter suitable for stdout-based log shipping."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "request_id": getattr(record, "request_id", "-"),
        }
        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)
        for key, value in record.__dict__.items():
            if key in {
                "args", "asctime", "created", "exc_info", "exc_text", "filename",
                "funcName", "levelname", "levelno", "lineno", "module", "msecs",
                "message", "msg", "name", "pathname", "process", "processName",
                "relativeCreated", "stack_info", "thread", "threadName",
                "request_id", "taskName",
            }:
                continue
            try:
                json.dumps(value)
            except TypeError:
                value = repr(value)
            payload[key] = value
        return json.dumps(payload, ensure_ascii=False)


def _bool_env(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def configure_logging() -> None:
    level = os.getenv("RADIOSCORE_LOG_LEVEL", "DEBUG").upper()
    json_logs = _bool_env("RADIOSCORE_LOG_JSON", default=False)
    sql_logs = _bool_env("RADIOSCORE_LOG_SQL", default=False)

    formatter: dict[str, Any]
    if json_logs:
        formatter = {"()": JsonFormatter}
    else:
        formatter = {
            "format": (
                "%(asctime)s %(levelname)-7s [%(name)s] "
                "[req=%(request_id)s] %(message)s"
            ),
            "datefmt": "%Y-%m-%d %H:%M:%S",
        }

    config: dict[str, Any] = {
        "version": 1,
        "disable_existing_loggers": False,
        "filters": {
            "request_id": {"()": RequestIdFilter},
        },
        "formatters": {"default": formatter},
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "stream": sys.stdout,
                "formatter": "default",
                "filters": ["request_id"],
            },
        },
        "loggers": {
            "app": {"handlers": ["console"], "level": level, "propagate": False},
            "uvicorn": {"handlers": ["console"], "level": "INFO", "propagate": False},
            "uvicorn.error": {"handlers": ["console"], "level": "INFO", "propagate": False},
            "uvicorn.access": {"handlers": ["console"], "level": "INFO", "propagate": False},
            "sqlalchemy.engine": {
                "handlers": ["console"],
                "level": "INFO" if sql_logs else "WARNING",
                "propagate": False,
            },
            "kafka": {"handlers": ["console"], "level": "WARNING", "propagate": False},
        },
        "root": {"handlers": ["console"], "level": level},
    }
    logging.config.dictConfig(config)
    logging.getLogger("app").debug(
        "logging configured", extra={"level": level, "json": json_logs, "sql": sql_logs}
    )
