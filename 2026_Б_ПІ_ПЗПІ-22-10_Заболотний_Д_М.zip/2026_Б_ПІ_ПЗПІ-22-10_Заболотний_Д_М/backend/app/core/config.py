from functools import lru_cache
from pathlib import Path
from typing import Annotated

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="RADIOSCORE_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    app_name: str = "RadioScore API"
    database_url: str = "postgresql+psycopg://radioscore:radioscore@localhost:5432/radioscore"
    read_database_urls: Annotated[list[str], NoDecode] = Field(default_factory=list)
    redis_url: str = "redis://localhost:6379/0"
    kafka_bootstrap_servers: str = "localhost:9092"
    kafka_group_id: str = "radioscore-cross-check"
    kafka_topic_matching_requested: str = "matching.requested.v1"
    kafka_topic_log_uploaded: str = "log.uploaded.v1"
    kafka_topic_submission_parsed: str = "submission.parsed.v1"
    kafka_topic_qso_ingested: str = "qso.ingested.v1"
    kafka_topic_qso_indexed: str = "qso.indexed.v1"
    kafka_topic_qso_matched: str = "qso.matched.v1"
    kafka_topic_matching_completed: str = "matching.completed.v1"
    kafka_topic_matching_failed: str = "matching.failed.v1"
    kafka_topic_conflict_detected: str = "matching.conflict_detected.v1"
    kafka_topic_dead_letter: str = "matching.dlq.v1"
    worker_max_retries: int = 3
    matching_cache_ttl_seconds: int = 180
    storage_path: Path = Path("storage")
    secret_key: str = Field(default="dev-only-change-me")
    access_token_expire_minutes: int = 120
    max_upload_bytes: int = 1_048_576
    log_level: str = "DEBUG"
    log_json: bool = False
    log_sql: bool = False
    db_echo: bool = False

    @field_validator("read_database_urls", mode="before")
    @classmethod
    def _split_read_urls(cls, value: str | list[str] | None) -> list[str]:
        if value is None:
            return []
        if isinstance(value, str):
            return [part.strip() for part in value.split(",") if part.strip()]
        return value


@lru_cache
def get_settings() -> Settings:
    return Settings()
