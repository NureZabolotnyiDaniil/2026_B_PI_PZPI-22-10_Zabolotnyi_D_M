import logging
from dataclasses import asdict
from uuid import uuid4

from sqlalchemy import select

from app.core.config import get_settings
from app.core.database import WriteSessionLocal
from app.core.replica_router import get_replica_session
from app.domain import ContestStatus, ProcessingJobStatus, ProcessingJobType
from app.models import QSO, Contest, LogSubmission, ProcessingJob
from app.modules.audit.service import record_audit
from app.modules.cross_check.replay import replay_contest_matching
from app.modules.cross_check.service import match_qso, run_cross_check
from app.modules.messaging.contracts import (
    ConflictDetectedEvent,
    DeadLetterEvent,
    LogUploadedEvent,
    MatchingCompletedEvent,
    MatchingFailedEvent,
    MatchingRequestedEvent,
    QsoIndexedEvent,
    QsoIngestedEvent,
    QsoMatchedEvent,
)
from app.modules.messaging.outbox import enqueue_event
from app.modules.observability.metrics import increment, observe
from app.modules.processing_jobs.service import (
    create_queued_job,
    mark_job_failed,
    mark_job_queued_for_retry,
    mark_job_running,
    mark_job_succeeded,
)
from app.modules.scoring.service import recalculate_final_score
from app.modules.submissions.service import parse_and_persist_submission

try:
    from redis import Redis
except Exception:  # pragma: no cover - keeps app bootable without optional deps
    Redis = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


def _cache_client() -> object | None:
    if Redis is None:
        return None
    return Redis.from_url(get_settings().redis_url, decode_responses=True)


def handle_log_uploaded(payload: dict) -> None:
    event = LogUploadedEvent.model_validate(payload)
    logger.info(
        "task.log_uploaded.start contest_id=%s submission_id=%s event_id=%s",
        event.contest_id,
        event.submission_id,
        event.event_id,
    )
    write_db = WriteSessionLocal()
    try:
        job = (
            write_db.get(ProcessingJob, event.job_id)
            if event.job_id is not None
            else write_db.scalar(
                select(ProcessingJob)
                .where(ProcessingJob.submission_id == event.submission_id)
                .order_by(ProcessingJob.id.desc())
            )
        )
        if job is None and event.job_id is None:
            submission = write_db.get(LogSubmission, event.submission_id)
            if submission is not None:
                job = create_queued_job(
                    write_db,
                    contest_id=event.contest_id,
                    submission_id=event.submission_id,
                    job_type=ProcessingJobType.PARSING,
                    actor=None,
                )
                event = event.model_copy(update={"job_id": job.id})
        if job is None:
            logger.warning("task.log_uploaded.job_missing job_id=%s", event.job_id)
            return
        if job.status in {
            ProcessingJobStatus.SUCCEEDED,
            ProcessingJobStatus.FAILED,
            ProcessingJobStatus.CANCELLED,
        }:
            logger.info(
                "task.log_uploaded.skip_terminal job_id=%s status=%s",
                job.id,
                job.status.value,
            )
            return
        mark_job_running(write_db, job)
        submission = parse_and_persist_submission(
            write_db,
            submission_id=event.submission_id,
        )
        if submission is not None:
            record_audit(
                write_db,
                actor=None,
                action="submission.parsed",
                target_type="log_submission",
                target_id=submission.id,
                metadata={"event_id": event.event_id, "contest_id": event.contest_id},
            )
            mark_job_succeeded(
                write_db,
                job,
                summary={
                    "event_id": event.event_id,
                    "submission_id": submission.id,
                    "submission_status": submission.status.value,
                    "qso_count": len(submission.qso_records),
                    "validation_issue_count": len(submission.issues),
                },
            )
        else:
            mark_job_failed(write_db, job, error_message="Submission not found")
        write_db.commit()
        logger.info(
            "task.log_uploaded.done submission_id=%s status=%s",
            event.submission_id,
            getattr(submission, "status", None) and submission.status.value,
        )
    except Exception as exc:
        write_db.rollback()
        logger.exception(
            "task.log_uploaded.error submission_id=%s err=%s", event.submission_id, exc
        )
        _schedule_retry_or_dead_letter(
            write_db,
            event=event,
            source_event_type="log.uploaded.v1",
            error_message=str(exc),
            job_id=event.job_id,
        )
    finally:
        write_db.close()


def handle_qso_ingested(payload: dict) -> None:
    settings = get_settings()
    event = QsoIngestedEvent.model_validate(payload)
    logger.info(
        "task.qso_ingested.start contest_id=%s qso_id=%s event_id=%s",
        event.contest_id,
        event.qso_id,
        event.event_id,
    )
    write_db = WriteSessionLocal()
    read_db = get_replica_session()
    cache = _cache_client()
    try:
        contest = write_db.get(Contest, event.contest_id)
        if contest is None:
            return
        qso = write_db.get(QSO, event.qso_id)
        if qso is not None:
            indexed_event = QsoIndexedEvent(
                contest_id=event.contest_id,
                qso_id=event.qso_id,
                time_bucket=qso.time_bucket,
                band=qso.band,
                mode=qso.mode,
            )
            enqueue_event(
                write_db,
                event_type="qso.indexed.v1",
                aggregate_type="qso",
                aggregate_id=event.qso_id,
                partition_key=f"{event.contest_id}:{qso.time_bucket.isoformat()}:{qso.band.upper()}",
                payload=indexed_event,
                idempotency_key=f"qso-indexed:{event.qso_id}",
            )
        summary, conflict, reasoning = match_qso(
            write_db,
            contest,
            event.qso_id,
            read_db=read_db,
            cache_client=cache,
            cache_ttl_seconds=settings.matching_cache_ttl_seconds,
        )
        if qso is not None and qso.submission and qso.submission.participant:
            recalculate_final_score(write_db, qso.submission.participant)
        if conflict is not None:
            conflict_event = ConflictDetectedEvent(
                contest_id=event.contest_id,
                conflict_id=conflict.id,
                qso_id=event.qso_id,
                conflict_type=conflict.type.value,
            )
            enqueue_event(
                write_db,
                event_type="matching.conflict_detected.v1",
                aggregate_type="cross_check_conflict",
                aggregate_id=conflict.id,
                partition_key=str(event.contest_id),
                payload=conflict_event,
                idempotency_key=f"conflict-detected:{conflict.id}",
            )
            if summary.get("conflicts", 0):
                contest.status = ContestStatus.JUDGE_REVIEW
        matched_event = QsoMatchedEvent(
            contest_id=event.contest_id,
            qso_id=event.qso_id,
            matched_qso_id=reasoning.get("matched_qso_id") or reasoning.get("candidate_qso_id"),
            decision_id=int(reasoning.get("decision_id", 0)),
            status=str(reasoning.get("result", "unknown")),
            confidence=float(reasoning.get("confidence", 0.0)),
            pipeline_decision=str(reasoning.get("pipeline_decision"))
            if reasoning.get("pipeline_decision")
            else None,
            explainability=reasoning.get("explainability")
            if isinstance(reasoning.get("explainability"), dict)
            else None,
        )
        enqueue_event(
            write_db,
            event_type="qso.matched.v1",
            aggregate_type="qso",
            aggregate_id=event.qso_id,
            partition_key=f"{event.contest_id}:{event.time_bucket.isoformat()}:{event.band.upper()}",
            payload=matched_event,
            idempotency_key=f"qso-matched:{event.qso_id}:{reasoning.get('result', 'unknown')}",
        )
        record_audit(
            write_db,
            actor=None,
            action="qso.matched",
            target_type="qso",
            target_id=event.qso_id,
            metadata={"event_id": event.event_id, "summary": summary, "reasoning": reasoning},
        )
        write_db.commit()
        increment("worker_qso_ingested_success_total", labels={"result": str(reasoning.get("result", "unknown"))})
        retrieval = reasoning.get("retrieval")
        if isinstance(retrieval, dict):
            observe(
                "worker_qso_candidate_count",
                float(retrieval.get("candidate_count", 0)),
                {"strategy": str(retrieval.get("retrieval_strategy", "unknown"))},
            )
        logger.info(
            "task.qso_ingested.done qso_id=%s result=%s confidence=%.3f",
            event.qso_id,
            reasoning.get("result", "unknown"),
            float(reasoning.get("confidence", 0.0)),
        )
    except Exception as exc:
        write_db.rollback()
        increment("worker_qso_ingested_error_total")
        logger.exception("task.qso_ingested.error qso_id=%s err=%s", event.qso_id, exc)
        _schedule_retry_or_dead_letter(
            write_db,
            event=event,
            source_event_type="qso.ingested.v1",
            error_message=str(exc),
        )
    finally:
        read_db.close()
        write_db.close()


def handle_matching_requested(payload: dict) -> None:
    settings = get_settings()
    event = MatchingRequestedEvent.model_validate(payload)
    logger.info(
        "task.matching_requested.start contest_id=%s job_id=%s event_id=%s retry=%s",
        event.contest_id,
        event.job_id,
        event.event_id,
        event.retry_count,
    )
    write_db = WriteSessionLocal()
    read_db = get_replica_session()
    cache = _cache_client()
    try:
        contest = write_db.get(Contest, event.contest_id)
        job = write_db.get(ProcessingJob, event.job_id)
        if contest is None or job is None:
            return
        if job.status in {
            ProcessingJobStatus.SUCCEEDED,
            ProcessingJobStatus.FAILED,
            ProcessingJobStatus.CANCELLED,
        }:
            return
        if job.summary.get("idempotency_key") == event.event_id:
            return
        mark_job_running(write_db, job)
        if event.replay:
            replay_summary = replay_contest_matching(write_db, contest)
            summary = asdict(replay_summary)
            conflicts = []
            reasoning_log = []
        else:
            summary, conflicts, reasoning_log = run_cross_check(
                write_db,
                contest,
                read_db=read_db,
                cache_client=cache,
                cache_ttl_seconds=settings.matching_cache_ttl_seconds,
                include_details=True,
            )
        matching_summary = (
            summary.get("matching_summary", {}) if event.replay else summary
        )
        if isinstance(matching_summary, dict) and matching_summary.get("conflicts", 0):
            contest.status = ContestStatus.JUDGE_REVIEW
        job.summary = {"idempotency_key": event.event_id, **summary}
        mark_job_succeeded(write_db, job, summary=job.summary)
        for conflict in conflicts:
            conflict_event = ConflictDetectedEvent(
                contest_id=contest.id,
                conflict_id=conflict.id,
                qso_id=conflict.qso_id,
                conflict_type=conflict.type.value,
            )
            enqueue_event(
                write_db,
                event_type="matching.conflict_detected.v1",
                aggregate_type="cross_check_conflict",
                aggregate_id=conflict.id,
                partition_key=str(contest.id),
                payload=conflict_event,
                idempotency_key=f"conflict-detected:{conflict.id}",
            )
        completed_event = MatchingCompletedEvent(contest_id=contest.id, job_id=job.id, summary=summary)
        enqueue_event(
            write_db,
            event_type="matching.completed.v1",
            aggregate_type="processing_job",
            aggregate_id=job.id,
            partition_key=str(contest.id),
            payload=completed_event,
            idempotency_key=f"matching-completed:{job.id}",
        )
        record_audit(
            write_db,
            actor=None,
            action="cross_check.replayed" if event.replay else "cross_check.completed",
            target_type="contest",
            target_id=contest.id,
            metadata={"job_id": job.id, "summary": summary, "reasoning_log": reasoning_log},
        )
        write_db.commit()
        increment("worker_matching_requested_success_total")
        logger.info(
            "task.matching_requested.done contest_id=%s job_id=%s summary=%s",
            event.contest_id,
            event.job_id,
            summary,
        )
    except Exception as exc:  # pragma: no cover - operational path
        write_db.rollback()
        logger.exception(
            "task.matching_requested.error contest_id=%s job_id=%s err=%s",
            event.contest_id,
            event.job_id,
            exc,
        )
        increment("worker_matching_requested_error_total")
        failed_event = MatchingFailedEvent(
            contest_id=event.contest_id,
            job_id=event.job_id,
            error_message=str(exc),
            retry_count=event.retry_count,
        )
        enqueue_event(
            write_db,
            event_type="matching.failed.v1",
            aggregate_type="processing_job",
            aggregate_id=event.job_id,
            partition_key=str(event.contest_id),
            payload=failed_event,
            idempotency_key=f"matching-failed:{event.job_id}:{event.retry_count}",
        )
        _schedule_retry_or_dead_letter(
            write_db,
            event=event,
            source_event_type="matching.requested.v1",
            error_message=str(exc),
            job_id=event.job_id,
        )
    finally:
        read_db.close()
        write_db.close()


def _schedule_retry_or_dead_letter(
    db,
    *,
    event,
    source_event_type: str,
    error_message: str,
    job_id: int | None = None,
) -> None:
    settings = get_settings()
    next_retry_count = event.retry_count + 1
    job = db.get(ProcessingJob, job_id) if job_id is not None else None
    if next_retry_count < settings.worker_max_retries:
        if job is not None and job.status not in {
            ProcessingJobStatus.SUCCEEDED,
            ProcessingJobStatus.FAILED,
            ProcessingJobStatus.CANCELLED,
        }:
            mark_job_queued_for_retry(
                db,
                job,
                retry_count=next_retry_count,
                error_message=error_message,
            )
        retry_event = event.model_copy(
            update={
                "event_id": str(uuid4()),
                "retry_count": next_retry_count,
            }
        )
        aggregate_id = (
            job_id
            or getattr(event, "qso_id", None)
            or getattr(event, "submission_id", None)
            or event.contest_id
        )
        enqueue_event(
            db,
            event_type=source_event_type,
            aggregate_type="processing_job" if job_id is not None else "event_retry",
            aggregate_id=aggregate_id,
            partition_key=str(event.contest_id),
            payload=retry_event,
            idempotency_key=(
                f"retry:{source_event_type}:{event.event_id}:{next_retry_count}"
            ),
        )
        increment("worker_retry_total", labels={"source_topic": source_event_type})
    else:
        if job is not None and job.status not in {
            ProcessingJobStatus.SUCCEEDED,
            ProcessingJobStatus.FAILED,
            ProcessingJobStatus.CANCELLED,
        }:
            mark_job_failed(db, job, error_message=error_message)
        dead_letter = DeadLetterEvent(
            source_event_type=source_event_type,
            source_event_id=event.event_id,
            error_message=error_message,
            payload=event.model_dump(mode="json"),
        )
        enqueue_event(
            db,
            event_type="dead_letter.v1",
            aggregate_type="processing_job" if job_id is not None else "event",
            aggregate_id=job_id or getattr(event, "qso_id", event.contest_id),
            partition_key=str(event.contest_id),
            payload=dead_letter,
            idempotency_key=f"dead-letter:{source_event_type}:{event.event_id}",
        )
        increment("worker_dead_letter_total", labels={"source_topic": source_event_type})
    db.commit()
