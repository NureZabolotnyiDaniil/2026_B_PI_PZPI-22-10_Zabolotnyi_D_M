import argparse
import logging
import time

from app.core.config import get_settings
from app.core.database import WriteSessionLocal
from app.core.logging import configure_logging, set_request_id
from app.modules.messaging.kafka import create_consumer
from app.modules.messaging.outbox import dispatch_pending_events
from app.worker.tasks import handle_log_uploaded, handle_matching_requested, handle_qso_ingested

logger = logging.getLogger("app.worker")

HANDLERS = {
    "log-uploaded": ("kafka_topic_log_uploaded", handle_log_uploaded),
    "qso-ingested": ("kafka_topic_qso_ingested", handle_qso_ingested),
    "matching-requested": ("kafka_topic_matching_requested", handle_matching_requested),
}


def run_consumer(worker_type: str) -> None:
    settings = get_settings()
    topic_setting, handler = HANDLERS[worker_type]
    topic = str(getattr(settings, topic_setting))
    consumer = create_consumer(
        topic=topic,
        group_id=f"{settings.kafka_group_id}-{worker_type}",
    )
    logger.info("worker.consumer.start type=%s topic=%s", worker_type, topic)
    for message in consumer:
        event_id = None
        if isinstance(message.value, dict):
            event_id = message.value.get("event_id")
        set_request_id(f"kafka:{event_id}" if event_id else f"kafka:{message.offset}")
        logger.info(
            "worker.message.received topic=%s partition=%s offset=%s key=%s event_id=%s",
            message.topic,
            message.partition,
            message.offset,
            message.key,
            event_id,
        )
        try:
            handler(message.value)
            consumer.commit()
            logger.info(
                "worker.message.committed topic=%s offset=%s", message.topic, message.offset
            )
        except Exception:
            logger.exception(
                "worker.message.failed topic=%s offset=%s event_id=%s",
                message.topic,
                message.offset,
                event_id,
            )
        finally:
            set_request_id(None)


def run_outbox_dispatcher() -> None:
    logger.info("worker.outbox_dispatcher.start")
    while True:
        db = WriteSessionLocal()
        try:
            dispatched = dispatch_pending_events(db)
        finally:
            db.close()
        if dispatched == 0:
            time.sleep(1)
        else:
            logger.debug("worker.outbox_dispatcher.tick dispatched=%s", dispatched)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--worker",
        choices=["outbox-dispatcher", *HANDLERS.keys()],
        default="matching-requested",
    )
    args = parser.parse_args()
    configure_logging()
    logger.info("worker.start type=%s", args.worker)
    if args.worker == "outbox-dispatcher":
        run_outbox_dispatcher()
        return
    run_consumer(args.worker)


if __name__ == "__main__":
    main()
