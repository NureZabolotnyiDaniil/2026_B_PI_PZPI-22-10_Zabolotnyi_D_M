import logging
import os
import time
import uuid

from fastapi import FastAPI, Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

from app.core.config import get_settings
from app.core.logging import configure_logging, set_request_id
from app.modules.admin.router import router as admin_router
from app.modules.audit.router import router as audit_router
from app.modules.auth.router import router as auth_router
from app.modules.contests.router import router as contests_router
from app.modules.cross_check.router import router as cross_check_router
from app.modules.judge.router import router as judge_router
from app.modules.observability.metrics import prometheus_text, snapshot
from app.modules.participants.router import router as participants_router
from app.modules.processing_jobs.router import router as jobs_router
from app.modules.results.router import router as results_router
from app.modules.submissions.router import router as submissions_router

settings = get_settings()

os.environ.setdefault("RADIOSCORE_LOG_LEVEL", settings.log_level)
if settings.log_json:
    os.environ.setdefault("RADIOSCORE_LOG_JSON", "1")
if settings.log_sql or settings.db_echo:
    os.environ.setdefault("RADIOSCORE_LOG_SQL", "1")
configure_logging()

logger = logging.getLogger("app.api")


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Log every HTTP request with method, path, status, duration and client."""

    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get("x-request-id") or uuid.uuid4().hex[:12]
        token = set_request_id(request_id)
        start = time.perf_counter()
        client = request.client.host if request.client else "-"
        logger.info(
            "request.start %s %s",
            request.method,
            request.url.path,
            extra={"client": client, "query": str(request.url.query)},
        )
        try:
            response = await call_next(request)
        except Exception:
            duration_ms = (time.perf_counter() - start) * 1000
            logger.exception(
                "request.error %s %s after %.1fms",
                request.method,
                request.url.path,
                duration_ms,
                extra={"client": client},
            )
            set_request_id(token if isinstance(token, str) else None)
            raise
        duration_ms = (time.perf_counter() - start) * 1000
        response.headers["x-request-id"] = request_id
        log_method = logger.warning if response.status_code >= 400 else logger.info
        log_method(
            "request.end %s %s -> %s in %.1fms",
            request.method,
            request.url.path,
            response.status_code,
            duration_ms,
            extra={"status_code": response.status_code, "duration_ms": round(duration_ms, 2)},
        )
        set_request_id(None)
        return response


app = FastAPI(
    title=settings.app_name,
    version="0.1.0",
    description="RadioScore backend MVP API. Use /docs or /redoc to inspect routes.",
    swagger_ui_parameters={"persistAuthorization": True},
)
app.add_middleware(RequestLoggingMiddleware)


@app.get("/api/health", tags=["Health"])
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/api/ready", tags=["Health"])
def readiness() -> dict[str, object]:
    return {"status": "ready", "checks": {"api": "ok"}, "metrics": snapshot()}


@app.get("/api/metrics", tags=["Health"])
def metrics() -> Response:
    return Response(prometheus_text(), media_type="text/plain; version=0.0.4")


app.include_router(auth_router)
app.include_router(contests_router)
app.include_router(participants_router)
app.include_router(submissions_router)
app.include_router(cross_check_router)
app.include_router(judge_router)
app.include_router(results_router)
app.include_router(admin_router)
app.include_router(audit_router)
app.include_router(jobs_router)
