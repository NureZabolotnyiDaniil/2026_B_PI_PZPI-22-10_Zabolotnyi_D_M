"""contest judge assignments

Revision ID: 0004_contest_judges
Revises: 0003_matching_pipeline_enums
Create Date: 2026-05-08

Links users to contests as contest-scoped judges (organizers/admins assign via API).
"""

from collections.abc import Sequence

import sqlalchemy as sa

from alembic import op

revision: str = "0004_contest_judges"
down_revision: str | None = "0003_matching_pipeline_enums"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "contest_judges",
        sa.Column("contest_id", sa.Integer(), sa.ForeignKey("contests.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("created_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at_utc", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_contest_judges_user_id", "contest_judges", ["user_id"])


def downgrade() -> None:
    op.drop_index("ix_contest_judges_user_id", table_name="contest_judges")
    op.drop_table("contest_judges")
