"""initial schema

Revision ID: 0001_initial_schema
Revises:
Create Date: 2026-05-04 08:16:00
"""
from collections.abc import Sequence

import sqlalchemy as sa

from alembic import op

revision: str = "0001_initial_schema"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("email", sa.String(length=255), nullable=False),
        sa.Column("password_hash", sa.String(length=255), nullable=False),
        sa.Column("display_name", sa.String(length=255), nullable=True),
        sa.Column("callsign", sa.String(length=32), nullable=True),
        sa.Column("global_roles", sa.JSON(), nullable=False),
        sa.Column("status", sa.Enum("ACTIVE", "BLOCKED", native_enum=False), nullable=False),
        sa.Column("created_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at_utc", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index(op.f("ix_users_email"), "users", ["email"], unique=True)
    op.create_index(op.f("ix_users_callsign"), "users", ["callsign"], unique=False)

    op.create_table(
        "contests",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("title", sa.String(length=255), nullable=False),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("rules_text", sa.Text(), nullable=False),
        sa.Column("start_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("end_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("log_submission_open_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("log_submission_deadline_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("status", sa.Enum(
            "DRAFT", "PUBLISHED", "ACCEPTING_LOGS", "LOG_SUBMISSION_CLOSED", "CHECKING",
            "JUDGE_REVIEW", "FINALIZED", "RESULTS_PUBLISHED", "ARCHIVED", native_enum=False
        ), nullable=False),
        sa.Column("allowed_bands", sa.JSON(), nullable=False),
        sa.Column("allowed_modes", sa.JSON(), nullable=False),
        sa.Column("categories", sa.JSON(), nullable=False),
        sa.Column("created_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("created_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at_utc", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "scoring_rules",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("contest_id", sa.Integer(), sa.ForeignKey("contests.id"), nullable=False, unique=True),
        sa.Column("qso_points", sa.Integer(), nullable=False),
        sa.Column("required_exchange_fields", sa.JSON(), nullable=False),
        sa.Column("time_tolerance_minutes", sa.Integer(), nullable=False),
        sa.Column("duplicate_policy", sa.String(length=64), nullable=False),
        sa.Column("multiplier_policy", sa.JSON(), nullable=False),
        sa.Column("penalty_policy", sa.JSON(), nullable=False),
    )

    op.create_table(
        "participants",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("contest_id", sa.Integer(), sa.ForeignKey("contests.id"), nullable=False),
        sa.Column("callsign", sa.String(length=32), nullable=False),
        sa.Column("category", sa.String(length=64), nullable=False),
        sa.Column("power", sa.String(length=64), nullable=True),
        sa.Column("country_or_region", sa.String(length=128), nullable=True),
        sa.Column("status", sa.Enum("REGISTERED", "SUBMITTED", "ACCEPTED", "CHECKED", "WITHDRAWN", native_enum=False), nullable=False),
        sa.Column("current_submission_id", sa.Integer(), nullable=True),
        sa.Column("created_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("contest_id", "callsign", name="uq_participants_contest_callsign"),
        sa.UniqueConstraint("user_id", "contest_id", name="uq_participants_user_contest"),
    )
    op.create_index("ix_participants_user_contest", "participants", ["user_id", "contest_id"])

    op.create_table(
        "log_submissions",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("participant_id", sa.Integer(), sa.ForeignKey("participants.id"), nullable=False),
        sa.Column("contest_id", sa.Integer(), sa.ForeignKey("contests.id"), nullable=False),
        sa.Column("original_file_path", sa.String(length=512), nullable=False),
        sa.Column("original_file_hash", sa.String(length=64), nullable=False),
        sa.Column("uploaded_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("status", sa.Enum("UPLOADED", "VALIDATION_FAILED", "ACCEPTED", "CHECKING", "CHECKED", "SUPERSEDED", native_enum=False), nullable=False),
        sa.Column("parsed_metadata", sa.JSON(), nullable=False),
        sa.Column("created_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("participant_id", "version", name="uq_submissions_participant_version"),
    )
    op.create_index("ix_log_submissions_contest_status", "log_submissions", ["contest_id", "status"])
    op.create_foreign_key(
        "fk_participants_current_submission_id_log_submissions",
        "participants", "log_submissions", ["current_submission_id"], ["id"],
    )

    op.create_table(
        "qso",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("submission_id", sa.Integer(), sa.ForeignKey("log_submissions.id"), nullable=False),
        sa.Column("contest_id", sa.Integer(), sa.ForeignKey("contests.id"), nullable=False),
        sa.Column("participant_callsign", sa.String(length=32), nullable=False),
        sa.Column("counterparty_callsign", sa.String(length=32), nullable=False),
        sa.Column("qso_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("band", sa.String(length=32), nullable=False),
        sa.Column("frequency", sa.String(length=32), nullable=True),
        sa.Column("mode", sa.String(length=32), nullable=False),
        sa.Column("sent_exchange", sa.String(length=128), nullable=True),
        sa.Column("received_exchange", sa.String(length=128), nullable=True),
        sa.Column("raw_line", sa.Text(), nullable=False),
        sa.Column("line_number", sa.Integer(), nullable=False),
        sa.Column("check_status", sa.Enum("PENDING", "CONFIRMED", "REJECTED", "DUPLICATE", "CONFLICT", native_enum=False), nullable=False),
        sa.Column("matched_qso_id", sa.Integer(), sa.ForeignKey("qso.id"), nullable=True),
    )
    op.create_index("ix_qso_contest_participant_callsign", "qso", ["contest_id", "participant_callsign"])
    op.create_index("ix_qso_contest_counterparty_callsign", "qso", ["contest_id", "counterparty_callsign"])
    op.create_index("ix_qso_contest_counterparty_time", "qso", ["contest_id", "counterparty_callsign", "qso_at_utc"])
    op.create_index("ix_qso_contest_band_mode_time", "qso", ["contest_id", "band", "mode", "qso_at_utc"])

    op.create_table(
        "validation_issues",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("submission_id", sa.Integer(), sa.ForeignKey("log_submissions.id"), nullable=False),
        sa.Column("qso_id", sa.Integer(), sa.ForeignKey("qso.id"), nullable=True),
        sa.Column("type", sa.String(length=64), nullable=False),
        sa.Column("severity", sa.Enum("BLOCKING", "WARNING", native_enum=False), nullable=False),
        sa.Column("message", sa.Text(), nullable=False),
        sa.Column("line_number", sa.Integer(), nullable=True),
    )

    op.create_table(
        "cross_check_conflicts",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("contest_id", sa.Integer(), sa.ForeignKey("contests.id"), nullable=False),
        sa.Column("qso_id", sa.Integer(), sa.ForeignKey("qso.id"), nullable=False),
        sa.Column("candidate_qso_id", sa.Integer(), sa.ForeignKey("qso.id"), nullable=True),
        sa.Column("type", sa.String(length=64), nullable=False),
        sa.Column("severity", sa.Enum("BLOCKING", "WARNING", native_enum=False), nullable=False),
        sa.Column("status", sa.Enum("OPEN", "AUTO_RESOLVED", "JUDGE_RESOLVED", native_enum=False), nullable=False),
        sa.Column("detected_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("details", sa.JSON(), nullable=False),
    )
    op.create_index("ix_conflicts_contest_status_type", "cross_check_conflicts", ["contest_id", "status", "type"])

    op.create_table(
        "judge_decisions",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("conflict_id", sa.Integer(), sa.ForeignKey("cross_check_conflicts.id"), nullable=False),
        sa.Column("judge_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("decision", sa.Enum("ACCEPT", "REJECT", "ADJUST", "MARK_AS_DUPLICATE", native_enum=False), nullable=False),
        sa.Column("comment", sa.Text(), nullable=False),
        sa.Column("score_impact", sa.Integer(), nullable=False),
        sa.Column("created_at_utc", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "scoring_results",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("participant_id", sa.Integer(), sa.ForeignKey("participants.id"), nullable=False),
        sa.Column("contest_id", sa.Integer(), sa.ForeignKey("contests.id"), nullable=False),
        sa.Column("claimed_score_from_file", sa.Integer(), nullable=True),
        sa.Column("system_claimed_score", sa.Integer(), nullable=False),
        sa.Column("final_score", sa.Integer(), nullable=True),
        sa.Column("confirmed_qso_count", sa.Integer(), nullable=False),
        sa.Column("rejected_qso_count", sa.Integer(), nullable=False),
        sa.Column("duplicate_qso_count", sa.Integer(), nullable=False),
        sa.Column("multiplier_count", sa.Integer(), nullable=False),
        sa.Column("penalty_points", sa.Integer(), nullable=False),
        sa.Column("calculated_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("participant_id", "contest_id", name="uq_scoring_participant_contest"),
    )

    op.create_table(
        "public_results",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("contest_id", sa.Integer(), sa.ForeignKey("contests.id"), nullable=False),
        sa.Column("participant_id", sa.Integer(), sa.ForeignKey("participants.id"), nullable=False),
        sa.Column("rank_overall", sa.Integer(), nullable=True),
        sa.Column("rank_in_category", sa.Integer(), nullable=False),
        sa.Column("callsign", sa.String(length=32), nullable=False),
        sa.Column("category", sa.String(length=64), nullable=False),
        sa.Column("claimed_score", sa.Integer(), nullable=False),
        sa.Column("final_score", sa.Integer(), nullable=False),
        sa.Column("confirmed_qso_count", sa.Integer(), nullable=False),
        sa.Column("removed_qso_count", sa.Integer(), nullable=False),
        sa.Column("published_at_utc", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "processing_jobs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("contest_id", sa.Integer(), sa.ForeignKey("contests.id"), nullable=True),
        sa.Column("type", sa.Enum("VALIDATION", "PARSING", "SCORING", "CROSS_CHECK", "PUBLICATION_PREPARATION", native_enum=False), nullable=False),
        sa.Column("status", sa.Enum("QUEUED", "RUNNING", "SUCCEEDED", "FAILED", "CANCELLED", native_enum=False), nullable=False),
        sa.Column("started_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("started_at_utc", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at_utc", sa.DateTime(timezone=True), nullable=True),
        sa.Column("summary", sa.JSON(), nullable=False),
        sa.Column("error_message", sa.Text(), nullable=True),
    )
    op.create_index("ix_jobs_contest_type_status", "processing_jobs", ["contest_id", "type", "status"])

    op.create_table(
        "audit_events",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("actor_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("action", sa.String(length=128), nullable=False),
        sa.Column("target_type", sa.String(length=128), nullable=False),
        sa.Column("target_id", sa.Integer(), nullable=True),
        sa.Column("timestamp_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("metadata_json", sa.JSON(), nullable=False),
    )
    op.create_index("ix_audit_actor_timestamp", "audit_events", ["actor_id", "timestamp_utc"])
    op.create_index("ix_audit_target", "audit_events", ["target_type", "target_id"])


def downgrade() -> None:
    op.drop_index("ix_audit_target", table_name="audit_events")
    op.drop_index("ix_audit_actor_timestamp", table_name="audit_events")
    op.drop_table("audit_events")
    op.drop_index("ix_jobs_contest_type_status", table_name="processing_jobs")
    op.drop_table("processing_jobs")
    op.drop_table("public_results")
    op.drop_table("scoring_results")
    op.drop_table("judge_decisions")
    op.drop_index("ix_conflicts_contest_status_type", table_name="cross_check_conflicts")
    op.drop_table("cross_check_conflicts")
    op.drop_table("validation_issues")
    op.drop_index("ix_qso_contest_band_mode_time", table_name="qso")
    op.drop_index("ix_qso_contest_counterparty_time", table_name="qso")
    op.drop_index("ix_qso_contest_counterparty_callsign", table_name="qso")
    op.drop_index("ix_qso_contest_participant_callsign", table_name="qso")
    op.drop_table("qso")
    op.drop_constraint("fk_participants_current_submission_id_log_submissions", "participants", type_="foreignkey")
    op.drop_index("ix_log_submissions_contest_status", table_name="log_submissions")
    op.drop_table("log_submissions")
    op.drop_index("ix_participants_user_contest", table_name="participants")
    op.drop_table("participants")
    op.drop_table("scoring_rules")
    op.drop_table("contests")
    op.drop_index(op.f("ix_users_callsign"), table_name="users")
    op.drop_index(op.f("ix_users_email"), table_name="users")
    op.drop_table("users")
