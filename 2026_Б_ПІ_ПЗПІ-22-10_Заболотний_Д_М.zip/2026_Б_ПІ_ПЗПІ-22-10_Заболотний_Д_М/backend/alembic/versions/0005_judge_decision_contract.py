"""judge decision contract v1

Revision ID: 0005_judge_decision_contract
Revises: 0004_contest_judges
Create Date: 2026-05-09
"""

from collections.abc import Sequence

import sqlalchemy as sa

from alembic import op

revision: str = "0005_judge_decision_contract"
down_revision: str | None = "0004_contest_judges"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column(
        "judge_decisions",
        sa.Column("metadata_json", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
    )
    op.execute(
        """
        UPDATE judge_decisions
        SET decision = CASE decision
            WHEN 'ACCEPT' THEN 'ACCEPT_MATCH'
            WHEN 'REJECT' THEN 'MARK_NIL'
            WHEN 'ADJUST' THEN 'OVERRIDE_MATCH'
            WHEN 'MARK_AS_DUPLICATE' THEN 'MARK_BUSTED_CALL'
            WHEN 'MERGE' THEN 'OVERRIDE_MATCH'
            ELSE decision
        END
        """
    )


def downgrade() -> None:
    op.execute(
        """
        UPDATE judge_decisions
        SET decision = CASE decision
            WHEN 'ACCEPT_MATCH' THEN 'ACCEPT'
            WHEN 'OVERRIDE_MATCH' THEN 'ADJUST'
            WHEN 'MARK_NIL' THEN 'REJECT'
            WHEN 'MARK_BUSTED_CALL' THEN 'MARK_AS_DUPLICATE'
            WHEN 'IGNORE_CONFLICT' THEN 'REJECT'
            WHEN 'RECALCULATE' THEN 'ADJUST'
            ELSE decision
        END
        """
    )
    op.drop_column("judge_decisions", "metadata_json")
