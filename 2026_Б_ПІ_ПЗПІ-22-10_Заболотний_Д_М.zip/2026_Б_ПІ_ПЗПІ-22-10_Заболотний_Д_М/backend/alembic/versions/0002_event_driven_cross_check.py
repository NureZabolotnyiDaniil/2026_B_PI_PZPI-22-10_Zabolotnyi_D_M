"""event driven cross check

Revision ID: 0002_event_driven_cross_check
Revises: 0001_initial_schema
Create Date: 2026-05-08 09:45:00
"""

from collections.abc import Sequence

import sqlalchemy as sa

from alembic import op

revision: str = "0002_event_driven_cross_check"
down_revision: str | None = "0001_initial_schema"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "event_outbox",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("event_type", sa.String(length=128), nullable=False),
        sa.Column("aggregate_type", sa.String(length=128), nullable=False),
        sa.Column("aggregate_id", sa.Integer(), nullable=False),
        sa.Column("partition_key", sa.String(length=255), nullable=False),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("status", sa.Enum("PENDING", "PUBLISHED", "FAILED", native_enum=False), nullable=False),
        sa.Column("attempts", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("available_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("published_at_utc", sa.DateTime(timezone=True), nullable=True),
        sa.Column("idempotency_key", sa.String(length=255), nullable=False),
        sa.Column("last_error", sa.Text(), nullable=True),
        sa.Column("created_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("idempotency_key", name="uq_event_outbox_idempotency_key"),
    )
    op.create_index(
        "ix_event_outbox_status_available", "event_outbox", ["status", "available_at_utc"]
    )
    op.create_index("ix_event_outbox_aggregate", "event_outbox", ["aggregate_type", "aggregate_id"])

    op.add_column(
        "qso",
        sa.Column("normalized_participant_callsign", sa.String(length=32), nullable=True),
    )
    op.add_column(
        "qso",
        sa.Column("normalized_counterparty_callsign", sa.String(length=32), nullable=True),
    )
    op.add_column("qso", sa.Column("participant_prefix", sa.String(length=8), nullable=True))
    op.add_column("qso", sa.Column("counterparty_prefix", sa.String(length=8), nullable=True))
    op.add_column("qso", sa.Column("time_bucket", sa.DateTime(timezone=True), nullable=True))

    op.execute(
        """
        UPDATE qso
        SET normalized_participant_callsign = UPPER(participant_callsign),
            normalized_counterparty_callsign = UPPER(counterparty_callsign),
            participant_prefix = SUBSTR(UPPER(participant_callsign), 1, 3),
            counterparty_prefix = SUBSTR(UPPER(counterparty_callsign), 1, 3),
            time_bucket = qso_at_utc
        """
    )

    op.alter_column("qso", "normalized_participant_callsign", nullable=False)
    op.alter_column("qso", "normalized_counterparty_callsign", nullable=False)
    op.alter_column("qso", "participant_prefix", nullable=False)
    op.alter_column("qso", "counterparty_prefix", nullable=False)
    op.alter_column("qso", "time_bucket", nullable=False)
    op.create_index(
        "ix_qso_candidate_bucket",
        "qso",
        ["contest_id", "time_bucket", "band", "mode", "counterparty_prefix"],
    )

    op.create_table(
        "qso_candidate_index",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("qso_id", sa.Integer(), sa.ForeignKey("qso.id"), nullable=False),
        sa.Column("contest_id", sa.Integer(), sa.ForeignKey("contests.id"), nullable=False),
        sa.Column(
            "submission_id", sa.Integer(), sa.ForeignKey("log_submissions.id"), nullable=False
        ),
        sa.Column("time_bucket", sa.DateTime(timezone=True), nullable=False),
        sa.Column("band", sa.String(length=32), nullable=False),
        sa.Column("mode", sa.String(length=32), nullable=False),
        sa.Column("normalized_participant_callsign", sa.String(length=32), nullable=False),
        sa.Column("normalized_counterparty_callsign", sa.String(length=32), nullable=False),
        sa.Column("participant_prefix", sa.String(length=8), nullable=False),
        sa.Column("counterparty_prefix", sa.String(length=8), nullable=False),
        sa.Column("indexed_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("qso_id", name="uq_qso_candidate_index_qso"),
    )
    op.create_index(
        "ix_candidate_index_lookup",
        "qso_candidate_index",
        ["contest_id", "time_bucket", "band", "mode", "participant_prefix"],
    )
    op.create_index(
        "ix_candidate_index_callsign",
        "qso_candidate_index",
        ["contest_id", "normalized_participant_callsign"],
    )

    op.create_table(
        "matching_decisions",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("contest_id", sa.Integer(), sa.ForeignKey("contests.id"), nullable=False),
        sa.Column("qso_id", sa.Integer(), sa.ForeignKey("qso.id"), nullable=False),
        sa.Column("candidate_qso_id", sa.Integer(), sa.ForeignKey("qso.id"), nullable=True),
        sa.Column(
            "conflict_id", sa.Integer(), sa.ForeignKey("cross_check_conflicts.id"), nullable=True
        ),
        sa.Column(
            "status",
            sa.Enum("CONFIRMED", "CONFLICT", "DUPLICATE", "NO_MATCH", native_enum=False),
            nullable=False,
        ),
        sa.Column("confidence", sa.Integer(), nullable=False),
        sa.Column("stage", sa.String(length=64), nullable=False),
        sa.Column("time_bucket", sa.DateTime(timezone=True), nullable=False),
        sa.Column("idempotency_key", sa.String(length=255), nullable=False),
        sa.Column("details", sa.JSON(), nullable=False),
        sa.Column("decided_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("idempotency_key", name="uq_matching_decisions_idempotency_key"),
    )
    op.create_index("ix_matching_decisions_qso", "matching_decisions", ["qso_id", "status"])
    op.create_index(
        "ix_matching_decisions_contest_bucket",
        "matching_decisions",
        ["contest_id", "time_bucket"],
    )


def downgrade() -> None:
    op.drop_index("ix_matching_decisions_contest_bucket", table_name="matching_decisions")
    op.drop_index("ix_matching_decisions_qso", table_name="matching_decisions")
    op.drop_table("matching_decisions")
    op.drop_index("ix_candidate_index_callsign", table_name="qso_candidate_index")
    op.drop_index("ix_candidate_index_lookup", table_name="qso_candidate_index")
    op.drop_table("qso_candidate_index")
    op.drop_index("ix_qso_candidate_bucket", table_name="qso")
    op.drop_column("qso", "time_bucket")
    op.drop_column("qso", "counterparty_prefix")
    op.drop_column("qso", "participant_prefix")
    op.drop_column("qso", "normalized_counterparty_callsign")
    op.drop_column("qso", "normalized_participant_callsign")
    op.drop_index("ix_event_outbox_aggregate", table_name="event_outbox")
    op.drop_index("ix_event_outbox_status_available", table_name="event_outbox")
    op.drop_table("event_outbox")
