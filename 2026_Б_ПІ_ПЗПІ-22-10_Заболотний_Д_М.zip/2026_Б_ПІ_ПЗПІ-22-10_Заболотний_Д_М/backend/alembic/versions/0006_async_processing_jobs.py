"""link processing jobs to submissions

Revision ID: 0006_async_processing_jobs
Revises: 0005_judge_decision_contract
Create Date: 2026-07-12
"""

from collections.abc import Sequence

import sqlalchemy as sa

from alembic import op

revision: str = "0006_async_processing_jobs"
down_revision: str | None = "0005_judge_decision_contract"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column(
        "processing_jobs",
        sa.Column(
            "submission_id",
            sa.Integer(),
            sa.ForeignKey("log_submissions.id"),
            nullable=True,
        ),
    )
    op.create_index(
        "ix_jobs_submission_status",
        "processing_jobs",
        ["submission_id", "status"],
    )


def downgrade() -> None:
    op.drop_index("ix_jobs_submission_status", table_name="processing_jobs")
    op.drop_column("processing_jobs", "submission_id")
