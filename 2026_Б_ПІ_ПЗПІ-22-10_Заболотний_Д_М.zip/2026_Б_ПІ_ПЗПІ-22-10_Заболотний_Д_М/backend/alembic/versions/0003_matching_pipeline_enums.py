"""matching pipeline enum extensions

Revision ID: 0003_matching_pipeline_enums
Revises: 0002_event_driven_cross_check
Create Date: 2026-05-08

Adds application-level enum string values for deterministic matching:
- QSO.check_status: ambiguous, no_match
- cross_check_conflicts.type: ambiguous
- matching_decisions.status: ambiguous
- judge_decisions.decision: merge

SQLAlchemy uses native_enum=False — values are stored as plain strings; no ALTER TYPE required.
"""

from collections.abc import Sequence

revision: str = "0003_matching_pipeline_enums"
down_revision: str | None = "0002_event_driven_cross_check"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    # Schema-compatible: new enum cases are unconstrained VARCHAR-backed values.
    pass


def downgrade() -> None:
    pass
