from datetime import UTC, datetime

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from app.core.database import Base
from app.domain import ConflictType, MatchingDecisionStatus, QsoCheckStatus
from app.main import app
from app.models import QSO, Contest, LogSubmission, MatchingDecision, Participant, ScoringRule, User
from app.modules.cross_check.index import upsert_candidate_index
from app.modules.cross_check.load_testing import generate_synthetic_contest
from app.modules.cross_check.matching import resolve_matching_pipeline
from app.modules.cross_check.replay import replay_contest_matching
from app.modules.cross_check.retrieval import find_candidate_matches
from app.modules.cross_check.service import match_qso


def test_candidate_retrieval_uses_band_mode_and_reports_diagnostics() -> None:
    db, contest, qso, candidate, wrong_band = _matching_fixture()
    try:
        upsert_candidate_index(db, qso)
        upsert_candidate_index(db, candidate)
        upsert_candidate_index(db, wrong_band)
        db.flush()

        result = find_candidate_matches(db, contest, qso)

        loaded_ids = [row.id for row in result.candidates]
        assert candidate.id in loaded_ids
        assert wrong_band.id in loaded_ids
        assert result.diagnostics.strategy == "index_full_dimensions"
        assert result.diagnostics.candidate_count >= 2
        assert not result.diagnostics.fallback_triggered
    finally:
        db.close()


def test_candidate_retrieval_merges_fuzzy_callsign_neighborhood() -> None:
    db, contest, qso, candidate, distractor = _matching_fixture()
    try:
        candidate.participant_callsign = "UX2AA"
        candidate.raw_line = "QSO: UX2AA S51A"
        distractor.participant_callsign = "UX1ZZ"
        distractor.counterparty_callsign = "S51A"
        distractor.band = qso.band
        distractor.mode = qso.mode
        distractor.raw_line = "QSO: UX1ZZ S51A"
        upsert_candidate_index(db, qso)
        upsert_candidate_index(db, candidate)
        upsert_candidate_index(db, distractor)
        db.flush()

        result = find_candidate_matches(db, contest, qso)
        loaded_ids = [row.id for row in result.candidates]
        resolution = resolve_matching_pipeline(qso, result.candidates, contest)

        assert candidate.id in loaded_ids
        assert distractor.id in loaded_ids
        assert not result.diagnostics.fallback_triggered
        assert result.diagnostics.fuzzy_neighborhood_merged
        assert resolution.primary is not None
        assert resolution.primary.qso.id == candidate.id
        assert resolution.primary.stage == "fuzzy"
        assert resolution.pipeline_decision == "BUSTED_CALL"
    finally:
        db.close()


def test_replay_rebuilds_index_and_recreates_matching_decisions() -> None:
    db, contest, qso, candidate, _ = _matching_fixture()
    try:
        upsert_candidate_index(db, qso)
        upsert_candidate_index(db, candidate)
        db.flush()
        match_qso(db, contest, qso.id)
        first_decision = db.scalar(select(MatchingDecision).where(MatchingDecision.qso_id == qso.id))
        assert first_decision is not None

        summary = replay_contest_matching(db, contest)
        replayed_decision = db.scalar(select(MatchingDecision).where(MatchingDecision.qso_id == qso.id))

        assert summary.qso_reindexed >= 2
        assert summary.decisions_deleted >= 1
        assert replayed_decision is not None
        assert qso.check_status == QsoCheckStatus.CONFIRMED
    finally:
        db.close()


def test_synthetic_load_generator_is_deterministic() -> None:
    start = datetime(2026, 5, 5, tzinfo=UTC)

    left = generate_synthetic_contest(qso_count=100, start_at_utc=start, seed=42)
    right = generate_synthetic_contest(qso_count=100, start_at_utc=start, seed=42)

    assert left == right
    assert len(left.qso_records) == 100
    assert sum(left.scenario_counts.values()) >= 100


def test_ambiguous_fuzzy_pair_requires_judge_without_guessing() -> None:
    db, contest, qso, cand_a, cand_b = _ambiguous_fuzzy_fixture()
    try:
        upsert_candidate_index(db, qso)
        upsert_candidate_index(db, cand_a)
        upsert_candidate_index(db, cand_b)
        db.flush()

        resolution = resolve_matching_pipeline(qso, [cand_a, cand_b], contest)
        assert resolution.outcome == "ambiguous"
        assert resolution.matching_status == MatchingDecisionStatus.AMBIGUOUS
        assert resolution.conflict_type == ConflictType.AMBIGUOUS

        _, conflict, reasoning = match_qso(db, contest, qso.id)
        assert conflict is not None
        assert conflict.type == ConflictType.AMBIGUOUS
        assert qso.check_status == QsoCheckStatus.AMBIGUOUS
        assert qso.matched_qso_id is None
        assert reasoning["result"] == MatchingDecisionStatus.AMBIGUOUS.value
        assert reasoning["pipeline_decision"] == "AMBIGUOUS"
        details = conflict.details or {}
        assert len(details.get("matching_candidates", [])) >= 2
    finally:
        db.close()


def test_deterministic_pipeline_scores_are_reproducible() -> None:
    db, contest, qso, candidate, _ = _matching_fixture()
    try:
        upsert_candidate_index(db, qso)
        upsert_candidate_index(db, candidate)
        db.flush()
        left = resolve_matching_pipeline(qso, [candidate], contest)
        right = resolve_matching_pipeline(qso, [candidate], contest)
        assert left == right
        assert left.outcome == "confirmed"
    finally:
        db.close()


def test_metrics_endpoint_is_available() -> None:
    client = TestClient(app)

    response = client.get("/api/metrics")

    assert response.status_code == 200
    assert response.text.endswith("\n")


def _ambiguous_fuzzy_fixture():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    session_factory = sessionmaker(bind=engine, autoflush=False)
    db = session_factory()
    user_a = User(email="amb-a@example.test", password_hash="x", callsign="S51A")
    user_b = User(email="amb-b@example.test", password_hash="x", callsign="UT5XY")
    user_c = User(email="amb-c@example.test", password_hash="x", callsign="UT5XQ")
    db.add_all([user_a, user_b, user_c])
    db.flush()
    contest = Contest(
        title="Ambiguous fuzzy",
        description="Test",
        rules_text="Rules",
        start_at_utc=datetime(2026, 5, 5, 0, 0, tzinfo=UTC),
        end_at_utc=datetime(2026, 5, 6, 0, 0, tzinfo=UTC),
        log_submission_open_at_utc=datetime(2026, 5, 4, 0, 0, tzinfo=UTC),
        log_submission_deadline_at_utc=datetime(2026, 5, 7, 0, 0, tzinfo=UTC),
        categories=["SINGLE-OP"],
        created_by_id=user_a.id,
    )
    db.add(contest)
    db.flush()
    db.add(ScoringRule(contest_id=contest.id, qso_points=10))
    participant_a = Participant(user_id=user_a.id, contest_id=contest.id, callsign="S51A", category="SINGLE-OP")
    participant_b = Participant(user_id=user_b.id, contest_id=contest.id, callsign="UT5XY", category="SINGLE-OP")
    participant_c = Participant(user_id=user_c.id, contest_id=contest.id, callsign="UT5XQ", category="SINGLE-OP")
    db.add_all([participant_a, participant_b, participant_c])
    db.flush()
    submission_a = LogSubmission(
        participant_id=participant_a.id,
        contest_id=contest.id,
        original_file_path="a.log",
        original_file_hash="a",
        version=1,
        parsed_metadata={},
    )
    submission_b = LogSubmission(
        participant_id=participant_b.id,
        contest_id=contest.id,
        original_file_path="b.log",
        original_file_hash="b",
        version=1,
        parsed_metadata={},
    )
    submission_c = LogSubmission(
        participant_id=participant_c.id,
        contest_id=contest.id,
        original_file_path="c.log",
        original_file_hash="c",
        version=1,
        parsed_metadata={},
    )
    db.add_all([submission_a, submission_b, submission_c])
    db.flush()
    participant_a.current_submission_id = submission_a.id
    participant_b.current_submission_id = submission_b.id
    participant_c.current_submission_id = submission_c.id
    qso_at = datetime(2026, 5, 5, 11, 17, tzinfo=UTC)
    qso = QSO(
        submission_id=submission_a.id,
        contest_id=contest.id,
        participant_callsign="S51A",
        counterparty_callsign="UT5XX",
        qso_at_utc=qso_at,
        band="40M",
        frequency="7175",
        mode="CW",
        sent_exchange="599 001",
        received_exchange="599 002",
        raw_line="QSO: S51A UT5XX",
        line_number=1,
    )
    cand_a = QSO(
        submission_id=submission_b.id,
        contest_id=contest.id,
        participant_callsign="UT5XY",
        counterparty_callsign="S51A",
        qso_at_utc=qso_at,
        band="40M",
        frequency="7175",
        mode="CW",
        sent_exchange="599 002",
        received_exchange="599 001",
        raw_line="QSO: UT5XY S51A",
        line_number=1,
    )
    cand_b = QSO(
        submission_id=submission_c.id,
        contest_id=contest.id,
        participant_callsign="UT5XQ",
        counterparty_callsign="S51A",
        qso_at_utc=qso_at,
        band="40M",
        frequency="7175",
        mode="CW",
        sent_exchange="599 002",
        received_exchange="599 001",
        raw_line="QSO: UT5XQ S51A",
        line_number=1,
    )
    db.add_all([qso, cand_a, cand_b])
    db.flush()
    return db, contest, qso, cand_a, cand_b


def _matching_fixture():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    session_factory = sessionmaker(bind=engine, autoflush=False)
    db = session_factory()
    user_a = User(email="prod-a@example.test", password_hash="x", callsign="S51A")
    user_b = User(email="prod-b@example.test", password_hash="x", callsign="UX1AA")
    db.add_all([user_a, user_b])
    db.flush()
    contest = Contest(
        title="Production matching",
        description="Test",
        rules_text="Rules",
        start_at_utc=datetime(2026, 5, 5, 0, 0, tzinfo=UTC),
        end_at_utc=datetime(2026, 5, 6, 0, 0, tzinfo=UTC),
        log_submission_open_at_utc=datetime(2026, 5, 4, 0, 0, tzinfo=UTC),
        log_submission_deadline_at_utc=datetime(2026, 5, 7, 0, 0, tzinfo=UTC),
        categories=["SINGLE-OP"],
        created_by_id=user_a.id,
    )
    db.add(contest)
    db.flush()
    db.add(ScoringRule(contest_id=contest.id, qso_points=10))
    participant_a = Participant(user_id=user_a.id, contest_id=contest.id, callsign="S51A", category="SINGLE-OP")
    participant_b = Participant(user_id=user_b.id, contest_id=contest.id, callsign="UX1AA", category="SINGLE-OP")
    db.add_all([participant_a, participant_b])
    db.flush()
    submission_a = LogSubmission(
        participant_id=participant_a.id,
        contest_id=contest.id,
        original_file_path="a.log",
        original_file_hash="a",
        version=1,
        parsed_metadata={},
    )
    submission_b = LogSubmission(
        participant_id=participant_b.id,
        contest_id=contest.id,
        original_file_path="b.log",
        original_file_hash="b",
        version=1,
        parsed_metadata={},
    )
    db.add_all([submission_a, submission_b])
    db.flush()
    participant_a.current_submission_id = submission_a.id
    participant_b.current_submission_id = submission_b.id
    qso_at = datetime(2026, 5, 5, 11, 17, tzinfo=UTC)
    qso = QSO(
        submission_id=submission_a.id,
        contest_id=contest.id,
        participant_callsign="S51A",
        counterparty_callsign="UX1AA",
        qso_at_utc=qso_at,
        band="40M",
        frequency="7175",
        mode="SSB",
        sent_exchange="59 009",
        received_exchange="59 005",
        raw_line="QSO: S51A UX1AA",
        line_number=1,
    )
    candidate = QSO(
        submission_id=submission_b.id,
        contest_id=contest.id,
        participant_callsign="UX1AA",
        counterparty_callsign="S51A",
        qso_at_utc=qso_at,
        band="40M",
        frequency="7175",
        mode="SSB",
        sent_exchange="59 005",
        received_exchange="59 009",
        raw_line="QSO: UX1AA S51A",
        line_number=1,
    )
    wrong_band = QSO(
        submission_id=submission_b.id,
        contest_id=contest.id,
        participant_callsign="UX1AA",
        counterparty_callsign="S51A",
        qso_at_utc=qso_at,
        band="20M",
        frequency="14000",
        mode="SSB",
        sent_exchange="59 005",
        received_exchange="59 009",
        raw_line="QSO: UX1AA S51A",
        line_number=2,
    )
    db.add_all([qso, candidate, wrong_band])
    db.flush()
    return db, contest, qso, candidate, wrong_band
