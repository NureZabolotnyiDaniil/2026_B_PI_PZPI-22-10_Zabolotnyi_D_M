import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.core.database import Base
from app.domain import ProcessingJobStatus, ProcessingJobType
from app.models import ProcessingJob
from app.modules.processing_jobs.service import (
    create_queued_job,
    mark_job_failed,
    mark_job_running,
    mark_job_succeeded,
)


def test_processing_job_lifecycle() -> None:
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    session_factory = sessionmaker(bind=engine, autoflush=False)
    db = session_factory()
    try:
        job = create_queued_job(db, contest_id=123, job_type=ProcessingJobType.CROSS_CHECK, actor=None)
        assert job.status == ProcessingJobStatus.QUEUED

        mark_job_running(db, job)
        assert job.status == ProcessingJobStatus.RUNNING
        assert job.started_at_utc is not None

        mark_job_succeeded(db, job, summary={"matched": 10})
        assert job.status == ProcessingJobStatus.SUCCEEDED
        assert job.summary["matched"] == 10
        assert job.finished_at_utc is not None
        with pytest.raises(ValueError):
            mark_job_running(db, job)

        job2 = create_queued_job(db, contest_id=123, job_type=ProcessingJobType.CROSS_CHECK, actor=None)
        mark_job_running(db, job2)
        mark_job_failed(db, job2, error_message="boom")
        assert job2.status == ProcessingJobStatus.FAILED
        assert job2.error_message == "boom"

        persisted = db.get(ProcessingJob, job.id)
        assert persisted is not None
    finally:
        db.close()
