from fastapi.testclient import TestClient

from app.main import app


def test_openapi_exposes_expected_route_groups() -> None:
    client = TestClient(app)

    response = client.get("/openapi.json")

    assert response.status_code == 200
    paths = response.json()["paths"]
    assert "/api/health" in paths
    assert "/api/auth/register" in paths
    assert "/api/public/contests" in paths
    assert "/api/organizer/contests" in paths
    assert "/api/judge/contests/{contest_id}/conflicts" in paths
    assert "/api/judge/contests/{contest_id}/participants/search" in paths
    assert "/api/judge/conflicts/{conflict_id}/neighbors" in paths
    assert "/api/organizer/contests/{contest_id}/judges" in paths
    assert (
        "202"
        in paths["/api/contests/{contest_id}/submissions"]["post"]["responses"]
    )
    assert (
        "202"
        in paths["/api/organizer/contests/{contest_id}/cross-check"]["post"][
            "responses"
        ]
    )
