from datetime import UTC, datetime
from io import BytesIO

import pytest
from fastapi import HTTPException, UploadFile
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.core.config import get_settings
from app.core.database import Base
from app.domain import (
    ContestStatus,
    ProcessingJobStatus,
    ProcessingJobType,
    SubmissionStatus,
)
from app.models import (
    QSO,
    Contest,
    EventOutbox,
    Participant,
    ProcessingJob,
    QsoCandidateIndex,
    User,
)
from app.modules.cross_check.router import enqueue_cross_check
from app.modules.messaging.contracts import MatchingRequestedEvent
from app.modules.processing_jobs.router import get_job
from app.modules.processing_jobs.service import create_queued_job, mark_job_running
from app.modules.submissions.router import upload_submission
from app.worker import tasks


def test_upload_is_queued_and_parsed_by_worker(monkeypatch, tmp_path) -> None:
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    session_factory = sessionmaker(bind=engine, autoflush=False)
    db = session_factory()
    settings = get_settings()
    old_storage_path = settings.storage_path
    settings.storage_path = tmp_path
    try:
        user = User(email="async@example.test", password_hash="x", callsign="UR5ABC")
        db.add(user)
        db.flush()
        contest = Contest(
            title="Async contest",
            description="Test",
            rules_text="Rules",
            start_at_utc=datetime(2026, 5, 5, 0, 0, tzinfo=UTC),
            end_at_utc=datetime(2026, 5, 6, 0, 0, tzinfo=UTC),
            log_submission_open_at_utc=datetime(2026, 5, 4, 0, 0, tzinfo=UTC),
            log_submission_deadline_at_utc=datetime(2026, 5, 7, 0, 0, tzinfo=UTC),
            status=ContestStatus.ACCEPTING_LOGS,
            categories=["SINGLE-OP"],
            created_by_id=user.id,
        )
        db.add(contest)
        db.flush()
        db.add(
            Participant(
                user_id=user.id,
                contest_id=contest.id,
                callsign="UR5ABC",
                category="SINGLE-OP",
                power=None,
                country_or_region=None,
            )
        )
        db.commit()

        response = upload_submission(
            contest.id,
            UploadFile(
                filename="async.log",
                file=BytesIO(
                    b"CALLSIGN: UR5ABC\n"
                    b"QSO: 7000 CW 2026-05-05 1200 UR5ABC 599 UT1XYZ 599\n"
                ),
            ),
            db,
            user,
        )
        submission = response["submission"]
        job = response["job"]
        assert submission.status == SubmissionStatus.PARSING_QUEUED
        assert job.status == ProcessingJobStatus.QUEUED
        queued_event = db.scalar(
            select(EventOutbox).where(EventOutbox.event_type == "log.uploaded.v1")
        )
        assert queued_event is not None
        assert queued_event.payload["job_id"] == job.id
        assert db.scalar(select(QSO)) is None
        assert get_job(job.id, db, user).id == job.id
        stranger = User(email="stranger@example.test", password_hash="x")
        db.add(stranger)
        db.flush()
        with pytest.raises(HTTPException) as denied:
            get_job(job.id, db, stranger)
        assert denied.value.status_code == 403

        monkeypatch.setattr(tasks, "WriteSessionLocal", session_factory)
        tasks.handle_log_uploaded(queued_event.payload)

        db.expire_all()
        persisted_job = db.get(ProcessingJob, job.id)
        assert persisted_job is not None
        assert persisted_job.status == ProcessingJobStatus.SUCCEEDED
        assert persisted_job.submission_id == submission.id
        assert db.scalar(select(QSO).where(QSO.submission_id == submission.id)) is not None
        event_types = {event.event_type for event in db.scalars(select(EventOutbox)).all()}
        assert "submission.parsed.v1" in event_types
        assert "qso.ingested.v1" in event_types

        qso_event = db.scalar(
            select(EventOutbox).where(EventOutbox.event_type == "qso.ingested.v1")
        )
        assert qso_event is not None
        monkeypatch.setattr(tasks, "get_replica_session", session_factory)
        monkeypatch.setattr(tasks, "_cache_client", lambda: None)
        tasks.handle_qso_ingested(qso_event.payload)
        tasks.handle_qso_ingested(qso_event.payload)
        db.expire_all()
        assert len(list(db.scalars(select(QsoCandidateIndex)).all())) == 1
    finally:
        settings.storage_path = old_storage_path
        db.close()


def test_cross_check_request_only_enqueues_background_job() -> None:
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False)()
    try:
        organizer = User(email="organizer@example.test", password_hash="x")
        db.add(organizer)
        db.flush()
        contest = Contest(
            title="Queued cross-check",
            description="Test",
            rules_text="Rules",
            start_at_utc=datetime(2026, 5, 5, 0, 0, tzinfo=UTC),
            end_at_utc=datetime(2026, 5, 6, 0, 0, tzinfo=UTC),
            log_submission_open_at_utc=datetime(2026, 5, 4, 0, 0, tzinfo=UTC),
            log_submission_deadline_at_utc=datetime(2026, 5, 7, 0, 0, tzinfo=UTC),
            status=ContestStatus.LOG_SUBMISSION_CLOSED,
            categories=["SINGLE-OP"],
            created_by_id=organizer.id,
        )
        db.add(contest)
        db.flush()

        job = enqueue_cross_check(db, contest=contest, actor=organizer, replay=False)
        db.flush()

        assert job.status == ProcessingJobStatus.QUEUED
        event = db.scalar(
            select(EventOutbox).where(
                EventOutbox.event_type == "matching.requested.v1"
            )
        )
        assert event is not None
        assert event.payload["job_id"] == job.id
        assert event.payload["replay"] is False
    finally:
        db.close()


def test_worker_retry_and_dead_letter_are_transactional() -> None:
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, autoflush=False)()
    settings = get_settings()
    try:
        job = create_queued_job(
            db,
            contest_id=None,
            job_type=ProcessingJobType.CROSS_CHECK,
            actor=None,
        )
        mark_job_running(db, job)
        event = MatchingRequestedEvent(contest_id=123, job_id=job.id)

        tasks._schedule_retry_or_dead_letter(
            db,
            event=event,
            source_event_type="matching.requested.v1",
            error_message="temporary",
            job_id=job.id,
        )
        assert job.status == ProcessingJobStatus.QUEUED
        assert db.scalar(
            select(EventOutbox).where(
                EventOutbox.event_type == "matching.requested.v1"
            )
        ) is not None

        mark_job_running(db, job)
        terminal_event = event.model_copy(
            update={"retry_count": settings.worker_max_retries - 1}
        )
        tasks._schedule_retry_or_dead_letter(
            db,
            event=terminal_event,
            source_event_type="matching.requested.v1",
            error_message="terminal",
            job_id=job.id,
        )
        assert job.status == ProcessingJobStatus.FAILED
        assert db.scalar(
            select(EventOutbox).where(EventOutbox.event_type == "dead_letter.v1")
        ) is not None
    finally:
        db.close()
