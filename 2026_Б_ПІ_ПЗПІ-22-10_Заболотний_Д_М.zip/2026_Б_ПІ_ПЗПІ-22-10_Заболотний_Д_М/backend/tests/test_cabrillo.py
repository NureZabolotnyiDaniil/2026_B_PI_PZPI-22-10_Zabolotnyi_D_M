from datetime import UTC, datetime, timedelta
from types import SimpleNamespace

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from app.core.config import get_settings
from app.core.database import Base
from app.domain import (
    ConflictType,
    IssueSeverity,
    MatchingDecisionStatus,
    QsoCheckStatus,
    SubmissionStatus,
    ValidationIssueType,
)
from app.models import (
    QSO,
    Contest,
    EventOutbox,
    LogSubmission,
    MatchingDecision,
    Participant,
    QsoCandidateIndex,
    ScoringResult,
    ScoringRule,
    User,
)
from app.modules.cabrillo.parser import parse_cabrillo_text
from app.modules.cross_check.index import upsert_candidate_index
from app.modules.cross_check.service import (
    classify_conflict,
    exchanges_match,
    match_qso,
    run_cross_check,
)
from app.modules.submissions.service import parse_and_persist_submission
from app.modules.validation.service import validate_cabrillo


def test_parse_cabrillo_preserves_raw_qso_lines() -> None:
    content = "\n".join(
        [
            "CALLSIGN: UR5ABC",
            "CLAIMED-SCORE: 2",
            "QSO: 7000 CW 2026-04-23 1200 UR5ABC 599 UT1XYZ 599",
        ]
    )

    parsed = parse_cabrillo_text(content)

    assert parsed.headers["CALLSIGN"] == "UR5ABC"
    assert parsed.headers["CLAIMED-SCORE"] == "2"
    assert parsed.qso_records[0].participant_callsign == "UR5ABC"
    assert parsed.qso_records[0].counterparty_callsign == "UT1XYZ"
    assert parsed.qso_records[0].raw_line.startswith("QSO:")


def test_parse_cabrillo_supports_report_and_serial_exchange() -> None:
    content = "\n".join(
        [
            "CALLSIGN: S51A",
            "QSO:  7175 SSB 2026-05-05 1117 S51A 59 009 UX1AA 59 005",
        ]
    )

    parsed = parse_cabrillo_text(content)

    qso = parsed.qso_records[0]
    assert qso.participant_callsign == "S51A"
    assert qso.counterparty_callsign == "UX1AA"
    assert qso.sent_exchange == "59 009"
    assert qso.received_exchange == "59 005"


def test_cross_check_detects_serial_number_mismatch() -> None:
    qso_at = datetime(2026, 5, 5, 11, 17, tzinfo=UTC)
    s51a_qso = SimpleNamespace(
        qso_at_utc=qso_at,
        band="40M",
        mode="SSB",
        sent_exchange="59 009",
        received_exchange="59 005",
    )
    ux1aa_qso = SimpleNamespace(
        qso_at_utc=qso_at,
        band="40M",
        mode="SSB",
        sent_exchange="59 002",
        received_exchange="59 009",
    )

    assert not exchanges_match(s51a_qso, ux1aa_qso)
    assert (
        classify_conflict(s51a_qso, [ux1aa_qso], timedelta(minutes=5))
        == ConflictType.EXCHANGE_MISMATCH
    )


def test_cross_check_recalculates_final_scores() -> None:
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    session_factory = sessionmaker(bind=engine, autoflush=False)
    db = session_factory()
    try:
        user_a = User(email="a@example.test", password_hash="x", callsign="S51A")
        user_b = User(email="b@example.test", password_hash="x", callsign="UX1AA")
        db.add_all([user_a, user_b])
        db.flush()

        contest = Contest(
            title="Test contest",
            description="Test",
            rules_text="Rules",
            start_at_utc=datetime(2026, 5, 5, 0, 0, tzinfo=UTC),
            end_at_utc=datetime(2026, 5, 6, 0, 0, tzinfo=UTC),
            log_submission_open_at_utc=datetime(2026, 5, 4, 0, 0, tzinfo=UTC),
            log_submission_deadline_at_utc=datetime(2026, 5, 7, 0, 0, tzinfo=UTC),
            categories=["SINGLE-OP"],
            created_by_id=user_a.id,
        )
        db.add(contest)
        db.flush()
        db.add(ScoringRule(contest_id=contest.id, qso_points=10))
        db.flush()

        participant_a = Participant(
            user_id=user_a.id,
            contest_id=contest.id,
            callsign="S51A",
            category="SINGLE-OP",
            power=None,
            country_or_region=None,
        )
        participant_b = Participant(
            user_id=user_b.id,
            contest_id=contest.id,
            callsign="UX1AA",
            category="SINGLE-OP",
            power=None,
            country_or_region=None,
        )
        db.add_all([participant_a, participant_b])
        db.flush()

        submission_a = LogSubmission(
            participant_id=participant_a.id,
            contest_id=contest.id,
            original_file_path="a.log",
            original_file_hash="a",
            version=1,
            parsed_metadata={},
        )
        submission_b = LogSubmission(
            participant_id=participant_b.id,
            contest_id=contest.id,
            original_file_path="b.log",
            original_file_hash="b",
            version=1,
            parsed_metadata={},
        )
        db.add_all([submission_a, submission_b])
        db.flush()
        participant_a.current_submission_id = submission_a.id
        participant_b.current_submission_id = submission_b.id

        qso_at = datetime(2026, 5, 5, 11, 17, tzinfo=UTC)
        db.add_all(
            [
                QSO(
                    submission_id=submission_a.id,
                    contest_id=contest.id,
                    participant_callsign="S51A",
                    counterparty_callsign="UX1AA",
                    qso_at_utc=qso_at,
                    band="40M",
                    frequency="7175",
                    mode="SSB",
                    sent_exchange="59 009",
                    received_exchange="59 005",
                    raw_line="QSO: S51A UX1AA",
                    line_number=1,
                ),
                QSO(
                    submission_id=submission_a.id,
                    contest_id=contest.id,
                    participant_callsign="S51A",
                    counterparty_callsign="MISSING",
                    qso_at_utc=qso_at,
                    band="40M",
                    frequency="7175",
                    mode="SSB",
                    sent_exchange="59 010",
                    received_exchange="59 001",
                    raw_line="QSO: S51A MISSING",
                    line_number=2,
                ),
                QSO(
                    submission_id=submission_b.id,
                    contest_id=contest.id,
                    participant_callsign="UX1AA",
                    counterparty_callsign="S51A",
                    qso_at_utc=qso_at,
                    band="40M",
                    frequency="7175",
                    mode="SSB",
                    sent_exchange="59 005",
                    received_exchange="59 009",
                    raw_line="QSO: UX1AA S51A",
                    line_number=1,
                ),
            ]
        )
        db.add_all(
            [
                ScoringResult(
                    participant_id=participant_a.id,
                    contest_id=contest.id,
                    system_claimed_score=20,
                    final_score=20,
                    confirmed_qso_count=2,
                ),
                ScoringResult(
                    participant_id=participant_b.id,
                    contest_id=contest.id,
                    system_claimed_score=10,
                    final_score=10,
                    confirmed_qso_count=1,
                ),
            ]
        )
        db.flush()

        summary, conflicts, reasoning_log = run_cross_check(db, contest, include_details=True)
        participant_a_score = db.scalar(
            select(ScoringResult).where(ScoringResult.participant_id == participant_a.id)
        )
        participant_a_qsos = list(
            db.scalars(select(QSO).where(QSO.submission_id == submission_a.id)).all()
        )

        assert summary["scores_recalculated"] == 2
        assert participant_a_score is not None
        assert participant_a_score.final_score == 10
        assert participant_a_score.confirmed_qso_count == 1
        assert len(conflicts) == 1
        assert reasoning_log
        assert reasoning_log[0]["confidence"] >= 0.5
        assert {qso.check_status for qso in participant_a_qsos} == {
            QsoCheckStatus.CONFIRMED,
            QsoCheckStatus.NO_MATCH,
        }
    finally:
        db.close()


def test_parsing_worker_persists_qso_index_and_outbox_events(tmp_path) -> None:
    settings = get_settings()
    old_storage_path = settings.storage_path
    settings.storage_path = tmp_path
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    session_factory = sessionmaker(bind=engine, autoflush=False)
    db = session_factory()
    try:
        user = User(email="parser@example.test", password_hash="x", callsign="S51A")
        db.add(user)
        db.flush()
        contest = Contest(
            title="Parser contest",
            description="Test",
            rules_text="Rules",
            start_at_utc=datetime(2026, 5, 5, 0, 0, tzinfo=UTC),
            end_at_utc=datetime(2026, 5, 6, 0, 0, tzinfo=UTC),
            log_submission_open_at_utc=datetime(2026, 5, 4, 0, 0, tzinfo=UTC),
            log_submission_deadline_at_utc=datetime(2026, 5, 7, 0, 0, tzinfo=UTC),
            categories=["SINGLE-OP"],
            created_by_id=user.id,
        )
        db.add(contest)
        db.flush()
        db.add(ScoringRule(contest_id=contest.id, qso_points=5))
        participant = Participant(
            user_id=user.id,
            contest_id=contest.id,
            callsign="S51A",
            category="SINGLE-OP",
            power=None,
            country_or_region=None,
        )
        db.add(participant)
        db.flush()
        original_path = "submissions/parser.log"
        (tmp_path / "submissions").mkdir()
        (tmp_path / original_path).write_text(
            "\n".join(
                [
                    "CALLSIGN: S51A",
                    "QSO:  7175 SSB 2026-05-05 1117 S51A 59 009 UX1AA 59 005",
                ]
            ),
            encoding="utf-8",
        )
        submission = LogSubmission(
            participant_id=participant.id,
            contest_id=contest.id,
            original_file_path=original_path,
            original_file_hash="hash",
            version=1,
            status=SubmissionStatus.PARSING_QUEUED,
            parsed_metadata={},
        )
        db.add(submission)
        db.flush()

        parsed = parse_and_persist_submission(db, submission_id=submission.id)
        db.flush()

        assert parsed is not None
        assert parsed.status == SubmissionStatus.ACCEPTED
        assert db.scalar(select(QSO).where(QSO.submission_id == submission.id)) is not None
        assert db.scalar(select(QsoCandidateIndex)) is None
        event_types = {event.event_type for event in db.scalars(select(EventOutbox)).all()}
        assert "submission.parsed.v1" in event_types
        assert "qso.ingested.v1" in event_types
        assert "qso.matched.v1" not in event_types
    finally:
        settings.storage_path = old_storage_path
        db.close()


def test_incremental_matching_records_fuzzy_busted_call_decision() -> None:
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    session_factory = sessionmaker(bind=engine, autoflush=False)
    db = session_factory()
    try:
        user_a = User(email="fuzzy-a@example.test", password_hash="x", callsign="S51A")
        user_b = User(email="fuzzy-b@example.test", password_hash="x", callsign="UXIAA")
        db.add_all([user_a, user_b])
        db.flush()
        contest = Contest(
            title="Fuzzy contest",
            description="Test",
            rules_text="Rules",
            start_at_utc=datetime(2026, 5, 5, 0, 0, tzinfo=UTC),
            end_at_utc=datetime(2026, 5, 6, 0, 0, tzinfo=UTC),
            log_submission_open_at_utc=datetime(2026, 5, 4, 0, 0, tzinfo=UTC),
            log_submission_deadline_at_utc=datetime(2026, 5, 7, 0, 0, tzinfo=UTC),
            categories=["SINGLE-OP"],
            created_by_id=user_a.id,
        )
        db.add(contest)
        db.flush()
        db.add(ScoringRule(contest_id=contest.id, qso_points=10))
        participant_a = Participant(user_id=user_a.id, contest_id=contest.id, callsign="S51A", category="SINGLE-OP")
        participant_b = Participant(user_id=user_b.id, contest_id=contest.id, callsign="UXIAA", category="SINGLE-OP")
        db.add_all([participant_a, participant_b])
        db.flush()
        submission_a = LogSubmission(
            participant_id=participant_a.id,
            contest_id=contest.id,
            original_file_path="a.log",
            original_file_hash="a",
            version=1,
            parsed_metadata={},
        )
        submission_b = LogSubmission(
            participant_id=participant_b.id,
            contest_id=contest.id,
            original_file_path="b.log",
            original_file_hash="b",
            version=1,
            parsed_metadata={},
        )
        db.add_all([submission_a, submission_b])
        db.flush()
        qso_at = datetime(2026, 5, 5, 11, 17, tzinfo=UTC)
        qso = QSO(
            submission_id=submission_a.id,
            contest_id=contest.id,
            participant_callsign="S51A",
            counterparty_callsign="UX1AA",
            qso_at_utc=qso_at,
            band="40M",
            frequency="7175",
            mode="SSB",
            sent_exchange="59 009",
            received_exchange="59 005",
            raw_line="QSO: S51A UX1AA",
            line_number=1,
        )
        candidate = QSO(
            submission_id=submission_b.id,
            contest_id=contest.id,
            participant_callsign="UXIAA",
            counterparty_callsign="S51A",
            qso_at_utc=qso_at,
            band="40M",
            frequency="7175",
            mode="SSB",
            sent_exchange="59 005",
            received_exchange="59 009",
            raw_line="QSO: UXIAA S51A",
            line_number=1,
        )
        db.add_all([qso, candidate])
        db.flush()
        upsert_candidate_index(db, qso)
        upsert_candidate_index(db, candidate)
        db.flush()

        _, conflict, reasoning = match_qso(db, contest, qso.id)

        decision = db.scalar(select(MatchingDecision).where(MatchingDecision.qso_id == qso.id))
        assert conflict is not None
        assert conflict.type == ConflictType.BUSTED_CALL
        assert decision is not None
        assert decision.stage == "fuzzy"
        assert reasoning["result"] == MatchingDecisionStatus.CONFLICT.value
        assert reasoning["pipeline_decision"] == "BUSTED_CALL"
    finally:
        db.close()


def test_validation_reports_missing_header_and_qso() -> None:
    parsed = parse_cabrillo_text("START-OF-LOG: 3.0")
    contest = SimpleNamespace(
        start_at_utc=datetime(2026, 4, 23, tzinfo=UTC),
        end_at_utc=datetime(2026, 4, 24, tzinfo=UTC),
        allowed_bands=[],
        allowed_modes=[],
        scoring_rule=None,
    )

    issues = validate_cabrillo("START-OF-LOG: 3.0", parsed, contest)

    assert {issue.type for issue in issues} == {
        ValidationIssueType.MISSING_REQUIRED_HEADER,
        ValidationIssueType.MISSING_QSO_LINES,
    }
    assert all(issue.severity == IssueSeverity.BLOCKING for issue in issues)
