"""Unit-тести для модуля валідації QSO-записів (app.modules.validation.service).

Тести перевіряють формування зауважень валідації журналу Cabrillo:
блокувальні помилки (BLOCKING) та попередження (WARNING), а також
допоміжні функції validation_duplicate_key і has_blocking_issues.
Тести є ізольованими: змагання моделюється через SimpleNamespace,
тому виконання не потребує бази даних чи зовнішніх сервісів.
"""

from datetime import UTC, datetime
from types import SimpleNamespace

from app.domain import IssueSeverity, ValidationIssueType
from app.modules.cabrillo.parser import parse_cabrillo_text
from app.modules.validation.service import (
    has_blocking_issues,
    validate_cabrillo,
    validation_duplicate_key,
)

CONTEST_START = datetime(2026, 4, 23, 0, 0, tzinfo=UTC)
CONTEST_END = datetime(2026, 4, 24, 0, 0, tzinfo=UTC)


def make_contest(
    *,
    allowed_bands: list[str] | None = None,
    allowed_modes: list[str] | None = None,
    scoring_rule: object | None = None,
    start_at_utc: datetime = CONTEST_START,
    end_at_utc: datetime = CONTEST_END,
) -> SimpleNamespace:
    """Мінімальна модель змагання з полями, які читає validate_cabrillo."""
    return SimpleNamespace(
        start_at_utc=start_at_utc,
        end_at_utc=end_at_utc,
        allowed_bands=allowed_bands or [],
        allowed_modes=allowed_modes or [],
        scoring_rule=scoring_rule,
    )


def make_scoring_rule(
    *,
    required_exchange_fields: list[str] | None = None,
    duplicate_policy: str = "same_band_mode",
) -> SimpleNamespace:
    return SimpleNamespace(
        required_exchange_fields=required_exchange_fields or [],
        duplicate_policy=duplicate_policy,
    )


def build(content: str, contest: SimpleNamespace) -> list:
    """Розбирає текст Cabrillo та повертає список зауважень валідації."""
    parsed = parse_cabrillo_text(content)
    return validate_cabrillo(content, parsed, contest)


def issue_types(issues: list) -> set:
    return {issue.type for issue in issues}


def log(*lines: str) -> str:
    return "\n".join(lines)


VALID_LOG = log(
    "CALLSIGN: UR5ABC",
    "QSO: 14000 CW 2026-04-23 1200 UR5ABC 599 UT1XYZ 599",
)


# --- Позитивний сценарій -------------------------------------------------


def test_valid_log_has_no_issues() -> None:
    issues = build(VALID_LOG, make_contest())

    assert issues == []
    assert not has_blocking_issues(issues)


# --- Порожній файл -------------------------------------------------------


def test_empty_file_reports_file_empty() -> None:
    issues = build("", make_contest())

    assert issue_types(issues) == {ValidationIssueType.FILE_EMPTY}
    assert issues[0].severity == IssueSeverity.BLOCKING


def test_whitespace_only_file_reports_file_empty() -> None:
    issues = build("   \n\t\n   ", make_contest())

    assert issue_types(issues) == {ValidationIssueType.FILE_EMPTY}


# --- Обов'язкові заголовки та наявність QSO ------------------------------


def test_missing_callsign_header_is_blocking() -> None:
    content = log("START-OF-LOG: 3.0", "QSO: 14000 CW 2026-04-23 1200 UR5ABC 599 UT1XYZ 599")

    issues = build(content, make_contest())

    assert ValidationIssueType.MISSING_REQUIRED_HEADER in issue_types(issues)
    header_issue = next(i for i in issues if i.type == ValidationIssueType.MISSING_REQUIRED_HEADER)
    assert header_issue.severity == IssueSeverity.BLOCKING


def test_missing_qso_lines_is_blocking() -> None:
    issues = build(log("CALLSIGN: UR5ABC"), make_contest())

    assert ValidationIssueType.MISSING_QSO_LINES in issue_types(issues)


def test_missing_header_and_qso_together() -> None:
    issues = build(log("START-OF-LOG: 3.0"), make_contest())

    assert issue_types(issues) == {
        ValidationIssueType.MISSING_REQUIRED_HEADER,
        ValidationIssueType.MISSING_QSO_LINES,
    }
    assert all(i.severity == IssueSeverity.BLOCKING for i in issues)


# --- Невалідний формат рядка QSO ----------------------------------------


def test_invalid_qso_line_is_reported_with_line_number() -> None:
    content = log(
        "CALLSIGN: UR5ABC",
        "QSO: 14000 CW 2026-04-23 1200 UR5ABC 599 UT1XYZ 599",
        "QSO: broken line",
    )

    issues = build(content, make_contest())

    invalid = [i for i in issues if i.type == ValidationIssueType.INVALID_QSO_FORMAT]
    assert len(invalid) == 1
    assert invalid[0].severity == IssueSeverity.BLOCKING
    assert invalid[0].line_number == 3
    # валідний рядок присутній, тому про відсутність QSO не повідомляється
    assert ValidationIssueType.MISSING_QSO_LINES not in issue_types(issues)


# --- Часові межі змагання -----------------------------------------------


def test_qso_before_contest_start_is_blocking() -> None:
    content = log(
        "CALLSIGN: UR5ABC",
        "QSO: 14000 CW 2026-04-22 1200 UR5ABC 599 UT1XYZ 599",
    )

    issues = build(content, make_contest())

    assert ValidationIssueType.QSO_OUT_OF_CONTEST_TIME in issue_types(issues)
    out = next(i for i in issues if i.type == ValidationIssueType.QSO_OUT_OF_CONTEST_TIME)
    assert out.severity == IssueSeverity.BLOCKING
    assert out.line_number == 2


def test_qso_after_contest_end_is_blocking() -> None:
    content = log(
        "CALLSIGN: UR5ABC",
        "QSO: 14000 CW 2026-04-25 1200 UR5ABC 599 UT1XYZ 599",
    )

    issues = build(content, make_contest())

    assert ValidationIssueType.QSO_OUT_OF_CONTEST_TIME in issue_types(issues)


def test_qso_at_contest_boundaries_is_accepted() -> None:
    content = log(
        "CALLSIGN: UR5ABC",
        "QSO: 14000 CW 2026-04-23 0000 UR5ABC 599 UT1XYZ 599",
        "QSO: 14000 CW 2026-04-24 0000 UR5ABC 599 UT9ZZZ 599",
    )

    issues = build(content, make_contest())

    assert ValidationIssueType.QSO_OUT_OF_CONTEST_TIME not in issue_types(issues)


# --- Дозволені діапазони та види роботи ----------------------------------


def test_unsupported_band_is_warning_only() -> None:
    content = log(
        "CALLSIGN: UR5ABC",
        "QSO: 14000 CW 2026-04-23 1200 UR5ABC 599 UT1XYZ 599",
    )

    issues = build(content, make_contest(allowed_bands=["20M"]))
    assert ValidationIssueType.UNSUPPORTED_BAND not in issue_types(issues)

    issues = build(content, make_contest(allowed_bands=["40M"]))
    band_issue = next(i for i in issues if i.type == ValidationIssueType.UNSUPPORTED_BAND)
    assert band_issue.severity == IssueSeverity.WARNING
    assert not has_blocking_issues(issues)


def test_unsupported_mode_is_warning_only() -> None:
    content = log(
        "CALLSIGN: UR5ABC",
        "QSO: 14000 CW 2026-04-23 1200 UR5ABC 599 UT1XYZ 599",
    )

    issues = build(content, make_contest(allowed_modes=["SSB"]))

    mode_issue = next(i for i in issues if i.type == ValidationIssueType.UNSUPPORTED_MODE)
    assert mode_issue.severity == IssueSeverity.WARNING


def test_band_and_mode_check_is_case_insensitive() -> None:
    content = log(
        "CALLSIGN: UR5ABC",
        "QSO: 14000 CW 2026-04-23 1200 UR5ABC 599 UT1XYZ 599",
    )

    issues = build(content, make_contest(allowed_bands=["20m"], allowed_modes=["cw"]))

    assert ValidationIssueType.UNSUPPORTED_BAND not in issue_types(issues)
    assert ValidationIssueType.UNSUPPORTED_MODE not in issue_types(issues)


# --- Обов'язкові поля контрольного номера --------------------------------


def test_missing_required_exchange_is_blocking() -> None:
    content = log(
        "CALLSIGN: UR5ABC",
        "QSO: 14000 CW 2026-04-23 1200 UR5ABC 599 UT1XYZ 599",
    )
    rule = make_scoring_rule(required_exchange_fields=["rst", "serial"])

    issues = build(content, make_contest(scoring_rule=rule))

    exchange_issue = next(i for i in issues if i.type == ValidationIssueType.MISSING_EXCHANGE)
    assert exchange_issue.severity == IssueSeverity.BLOCKING


def test_complete_required_exchange_passes() -> None:
    content = log(
        "CALLSIGN: UR5ABC",
        "QSO: 14000 CW 2026-04-23 1200 UR5ABC 599 001 UT1XYZ 599 002",
    )
    rule = make_scoring_rule(required_exchange_fields=["rst", "serial"])

    issues = build(content, make_contest(scoring_rule=rule))

    assert ValidationIssueType.MISSING_EXCHANGE not in issue_types(issues)


# --- Дублікати зв'язків у межах одного журналу ---------------------------


def test_duplicate_qso_in_file_is_warning() -> None:
    content = log(
        "CALLSIGN: UR5ABC",
        "QSO: 14000 CW 2026-04-23 1200 UR5ABC 599 UT1XYZ 599",
        "QSO: 14000 CW 2026-04-23 1230 UR5ABC 599 UT1XYZ 599",
    )

    issues = build(content, make_contest())

    duplicates = [i for i in issues if i.type == ValidationIssueType.DUPLICATE_QSO_IN_FILE]
    assert len(duplicates) == 1
    assert duplicates[0].severity == IssueSeverity.WARNING
    assert duplicates[0].line_number == 3


def test_same_callsign_different_band_is_not_duplicate_by_default() -> None:
    content = log(
        "CALLSIGN: UR5ABC",
        "QSO: 14000 CW 2026-04-23 1200 UR5ABC 599 UT1XYZ 599",
        "QSO: 7000 CW 2026-04-23 1230 UR5ABC 599 UT1XYZ 599",
    )

    issues = build(content, make_contest())

    assert ValidationIssueType.DUPLICATE_QSO_IN_FILE not in issue_types(issues)


# --- validation_duplicate_key: політики виявлення дублікатів -------------


def _qso(counterparty: str = "UT1XYZ", band: str = "20M", mode: str = "CW") -> SimpleNamespace:
    return SimpleNamespace(counterparty_callsign=counterparty, band=band, mode=mode)


def test_duplicate_key_same_band_mode_default() -> None:
    key = validation_duplicate_key(_qso(), "same_band_mode")

    assert key == ("UT1XYZ", "20M", "CW")


def test_duplicate_key_same_callsign_ignores_band_and_mode() -> None:
    key = validation_duplicate_key(_qso(), "same_callsign")

    assert key == ("UT1XYZ",)


def test_duplicate_key_same_band_ignores_mode() -> None:
    key = validation_duplicate_key(_qso(), "same_band")

    assert key == ("UT1XYZ", "20M")


def test_duplicate_key_ignore_policy_returns_none() -> None:
    assert validation_duplicate_key(_qso(), "ignore") is None
    assert validation_duplicate_key(_qso(), "none") is None


def test_duplicate_key_normalizes_callsign_and_band_case() -> None:
    key = validation_duplicate_key(_qso(counterparty="ut1xyz", band="20m", mode="cw"), "same_band_mode")

    assert key == ("UT1XYZ", "20M", "CW")


def test_duplicate_key_unknown_policy_falls_back_to_band_mode() -> None:
    key = validation_duplicate_key(_qso(), "totally-unknown")

    assert key == ("UT1XYZ", "20M", "CW")


# --- has_blocking_issues -------------------------------------------------


def test_has_blocking_issues_true_with_blocking() -> None:
    issues = build("", make_contest())

    assert has_blocking_issues(issues) is True


def test_has_blocking_issues_false_with_warnings_only() -> None:
    content = log(
        "CALLSIGN: UR5ABC",
        "QSO: 14000 CW 2026-04-23 1200 UR5ABC 599 UT1XYZ 599",
    )

    issues = build(content, make_contest(allowed_modes=["SSB"]))

    assert issue_types(issues) == {ValidationIssueType.UNSUPPORTED_MODE}
    assert has_blocking_issues(issues) is False
