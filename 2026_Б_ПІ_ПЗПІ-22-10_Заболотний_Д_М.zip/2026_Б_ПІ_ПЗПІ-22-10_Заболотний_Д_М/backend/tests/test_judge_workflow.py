from datetime import UTC, datetime

import pytest
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker

from app.core.database import Base
from app.core.permissions import can_access_judge_workbench
from app.domain import ConflictStatus, ConflictType, JudgeDecisionType, QsoCheckStatus, UserRole
from app.models import (
    QSO,
    Contest,
    ContestJudge,
    CrossCheckConflict,
    LogSubmission,
    Participant,
    ScoringRule,
    User,
)
from app.modules.judge.router import (
    _gather_conflict_queue_items,
    _sort_queue_snapshot,
    create_decision,
)
from app.schemas import JudgeDecisionCreate


@pytest.fixture
def judge_fixture():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    session_factory = sessionmaker(bind=engine, autoflush=False)
    db = session_factory()
    try:
        organizer = User(email="org@example.test", password_hash="x", global_roles=[UserRole.ORGANIZER])
        judge = User(email="judge@example.test", password_hash="x", global_roles=[UserRole.JUDGE])
        participant_user = User(email="runner@example.test", password_hash="x", callsign="UT5XX")
        counter_user = User(email="counter@example.test", password_hash="x", callsign="DL1ABC")
        db.add_all([organizer, judge, participant_user, counter_user])
        db.flush()
        contest = Contest(
            title="Judge contest",
            description="Test",
            rules_text="Rules",
            start_at_utc=datetime(2026, 5, 5, 0, 0, tzinfo=UTC),
            end_at_utc=datetime(2026, 5, 6, 0, 0, tzinfo=UTC),
            log_submission_open_at_utc=datetime(2026, 5, 4, 0, 0, tzinfo=UTC),
            log_submission_deadline_at_utc=datetime(2026, 5, 7, 0, 0, tzinfo=UTC),
            categories=["SINGLE-OP"],
            created_by_id=organizer.id,
        )
        db.add(contest)
        db.flush()
        db.add(ScoringRule(contest_id=contest.id, qso_points=10))
        participant = Participant(
            user_id=participant_user.id,
            contest_id=contest.id,
            callsign="UT5XX",
            category="SINGLE-OP",
            country_or_region="EU",
        )
        counterparty = Participant(
            user_id=counter_user.id,
            contest_id=contest.id,
            callsign="DL1ABC",
            category="SINGLE-OP",
            country_or_region="EU",
        )
        db.add_all([participant, counterparty])
        db.flush()
        participant_submission = LogSubmission(
            participant_id=participant.id,
            contest_id=contest.id,
            original_file_path="ut5xx.log",
            original_file_hash="a",
            version=1,
            parsed_metadata={},
        )
        counter_submission = LogSubmission(
            participant_id=counterparty.id,
            contest_id=contest.id,
            original_file_path="dl1abc.log",
            original_file_hash="b",
            version=1,
            parsed_metadata={},
        )
        db.add_all([participant_submission, counter_submission])
        db.flush()
        participant.current_submission_id = participant_submission.id
        counterparty.current_submission_id = counter_submission.id
        qso = QSO(
            submission_id=participant_submission.id,
            contest_id=contest.id,
            participant_callsign="UT5XX",
            counterparty_callsign="DL1ABC",
            qso_at_utc=datetime(2026, 5, 5, 12, 1, tzinfo=UTC),
            band="20M",
            frequency="14025",
            mode="CW",
            sent_exchange="599001",
            received_exchange="599014",
            raw_line="QSO: 14025 CW 2026-10-25 1201 UT5XX 599001 DL1ABC 599014",
            line_number=1,
        )
        candidate = QSO(
            submission_id=counter_submission.id,
            contest_id=contest.id,
            participant_callsign="DL1ABC",
            counterparty_callsign="UT5XX",
            qso_at_utc=datetime(2026, 5, 5, 12, 1, 24, tzinfo=UTC),
            band="20M",
            frequency="14025",
            mode="CW",
            sent_exchange="599014",
            received_exchange="599001",
            raw_line="QSO: 14025 CW 2026-10-25 1201 DL1ABC 599014 UT5XX 599001",
            line_number=1,
        )
        db.add_all([qso, candidate])
        db.flush()
        conflict = CrossCheckConflict(
            contest_id=contest.id,
            qso_id=qso.id,
            candidate_qso_id=candidate.id,
            type=ConflictType.NIL,
            status=ConflictStatus.OPEN,
            details={"confidence": 0.62, "impact": 7},
        )
        db.add(conflict)
        db.flush()
        yield db, contest, judge, conflict
    finally:
        db.close()


def test_judge_access_requires_assignment_for_judge_role(judge_fixture):
    db, contest, judge, _ = judge_fixture
    assert can_access_judge_workbench(db, judge, contest.id) is False
    db.add(ContestJudge(contest_id=contest.id, user_id=judge.id))
    db.flush()
    assert can_access_judge_workbench(db, judge, contest.id) is True


def test_override_decision_persists_context_and_resolves_conflict(monkeypatch, judge_fixture):
    db, _, judge, conflict = judge_fixture
    db.add(ContestJudge(contest_id=conflict.contest_id, user_id=judge.id))
    db.flush()
    monkeypatch.setattr("app.modules.judge.router.recalculate_final_score", lambda _db, _participant: None)
    decision = create_decision(
        conflict_id=conflict.id,
        payload=JudgeDecisionCreate(
            decision=JudgeDecisionType.OVERRIDE_MATCH,
            comment="timestamp alignment",
            score_impact=0,
            selected_candidate_qso_id=conflict.candidate_qso_id,
        ),
        db=db,
        current_user=judge,
    )
    assert decision.metadata_json["previous_candidate_qso_id"] is None
    assert decision.metadata_json["selected_candidate_qso_id"] == conflict.candidate_qso_id
    assert decision.metadata_json["confidence_snapshot"] == 0.62
    assert conflict.status == ConflictStatus.JUDGE_RESOLVED
    assert conflict.qso.check_status == QsoCheckStatus.CONFIRMED


def test_mark_nil_decision_sets_no_match_status(monkeypatch, judge_fixture):
    db, _, judge, conflict = judge_fixture
    db.add(ContestJudge(contest_id=conflict.contest_id, user_id=judge.id))
    db.flush()
    monkeypatch.setattr("app.modules.judge.router.recalculate_final_score", lambda _db, _participant: None)
    create_decision(
        conflict_id=conflict.id,
        payload=JudgeDecisionCreate(
            decision=JudgeDecisionType.MARK_NIL,
            comment="No reciprocal QSO found",
            score_impact=0,
        ),
        db=db,
        current_user=judge,
    )
    assert conflict.qso.check_status == QsoCheckStatus.NO_MATCH
    assert conflict.qso.matched_qso_id is None


def test_station_filter_matches_counterparty_callsign(judge_fixture):
    db, contest, _judge, conflict = judge_fixture
    filtered = _gather_conflict_queue_items(db, contest.id, station="DL1ABC")
    assert any(item.id == conflict.id for item in filtered)


def test_participant_registry_search(judge_fixture):
    db, contest, _judge, _conflict = judge_fixture
    rows = db.scalars(
        select(Participant).where(
            Participant.contest_id == contest.id,
            func.upper(Participant.callsign).like("%UT5%"),
        )
    ).all()
    assert any(row.callsign == "UT5XX" for row in rows)


def test_conflict_neighbor_navigation(judge_fixture):
    db, contest, judge, conflict = judge_fixture
    db.add(ContestJudge(contest_id=contest.id, user_id=judge.id))
    qso2 = QSO(
        submission_id=conflict.qso.submission_id,
        contest_id=contest.id,
        participant_callsign="UT5XX",
        counterparty_callsign="DL9ZZZ",
        qso_at_utc=datetime(2026, 5, 5, 12, 5, tzinfo=UTC),
        band="40M",
        frequency="7000",
        mode="CW",
        sent_exchange="599001",
        received_exchange="599099",
        raw_line="QSO2",
        line_number=2,
    )
    db.add(qso2)
    db.flush()
    conflict2 = CrossCheckConflict(
        contest_id=contest.id,
        qso_id=qso2.id,
        candidate_qso_id=None,
        type=ConflictType.NIL,
        status=ConflictStatus.OPEN,
        details={"confidence": 0.4, "impact": 2},
    )
    db.add(conflict2)
    db.flush()

    ordered = _sort_queue_snapshot(
        _gather_conflict_queue_items(db, contest.id),
        sort_by="confidence",
        sort_dir="asc",
        unresolved_first=True,
    )
    ids = [item.id for item in ordered]
    assert ids.index(conflict2.id) == 0  # lower confidence surfaces first
    assert ids.index(conflict.id) == 1
    assert ids.index(conflict2.id) + 1 == ids.index(conflict.id)
