import { FormEvent, useState } from "react";

import { useAuth } from "../../shared/auth/AuthContext";
import { Field, FormActions } from "../../shared/components/Form";
import { ErrorState } from "../../shared/components/State";
import { StatusBadge } from "../../shared/components/StatusBadge";
import type { FormStatus } from "../../shared/types/forms";

export function ProfilePage() {
  const { user, updateProfile } = useAuth();
  const [displayName, setDisplayName] = useState(user?.display_name ?? "");
  const [callsign, setCallsign] = useState(user?.callsign ?? "");
  const [status, setStatus] = useState<FormStatus>({ submitting: false, error: null, success: null });

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setStatus({ submitting: true, error: null, success: null });
    try {
      await updateProfile({ display_name: displayName || null, callsign: callsign || null });
      setStatus({ submitting: false, error: null, success: "Profile updated." });
    } catch (error) {
      setStatus({
        submitting: false,
        error: error instanceof Error ? error.message : "Unable to update profile",
        success: null
      });
    }
  }

  return (
    <section className="page-section">
      <div className="hero">
        <h1>Profile</h1>
        <p className="muted">Manage your RadioScore account identity used for submissions and reports.</p>
      </div>

      <div className="grid two">
        <form className="card" onSubmit={handleSubmit}>
          <h2>Account details</h2>
          {status.error ? <ErrorState error={status.error} /> : null}
          {status.success ? <div className="state state-muted">{status.success}</div> : null}
          <Field label="Display name">
            <input value={displayName} onChange={(event) => setDisplayName(event.target.value)} />
          </Field>
          <Field label="Callsign">
            <input value={callsign} onChange={(event) => setCallsign(event.target.value.toUpperCase())} />
          </Field>
          <FormActions>
            <button className="button button-primary" disabled={status.submitting} type="submit">
              {status.submitting ? "Saving..." : "Save profile"}
            </button>
          </FormActions>
        </form>

        <aside className="card">
          <h2>Current access</h2>
          <p><strong>Email:</strong> {user?.email}</p>
          <p><strong>Status:</strong> {user ? <StatusBadge value={user.status} /> : null}</p>
          <div>
            <strong>Roles</strong>
            <div className="meta-row" style={{ marginTop: "0.5rem" }}>
              {user?.global_roles.map((role) => <StatusBadge value={role} key={role} />)}
            </div>
          </div>
        </aside>
      </div>
    </section>
  );
}
