import { useEffect, useMemo, useState } from "react";

import { radioscoreApi } from "../../shared/api/radioscore";
import { useAuth } from "../../shared/auth/AuthContext";
import { EmptyState, ErrorState, LoadingState } from "../../shared/components/State";
import { StatusBadge } from "../../shared/components/StatusBadge";
import { useAsync } from "../../shared/hooks/useAsync";
import type { UserRead, UserRole } from "../../shared/types/domain";

const ALL_ROLES: UserRole[] = ["participant", "organizer", "judge", "admin"];

function sameRoles(a: UserRole[], b: UserRole[]) {
  if (a.length !== b.length) {
    return false;
  }
  const setB = new Set(b);
  return a.every((role) => setB.has(role));
}

export function AdminUsersPage() {
  const { user: currentUser } = useAuth();
  const { data: users, error, loading, reload } = useAsync(radioscoreApi.listUsers, []);

  const [drafts, setDrafts] = useState<Record<number, UserRole[]>>({});
  const [busyUserId, setBusyUserId] = useState<number | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  useEffect(() => {
    if (!users) {
      return;
    }
    setDrafts(Object.fromEntries(users.map((u) => [u.id, [...u.global_roles]])));
  }, [users]);

  const usersById = useMemo(() => {
    const map = new Map<number, UserRead>();
    users?.forEach((u) => map.set(u.id, u));
    return map;
  }, [users]);

  function toggleRole(userId: number, role: UserRole) {
    setDrafts((prev) => {
      const current = prev[userId] ?? [];
      const next = current.includes(role)
        ? current.filter((r) => r !== role)
        : [...current, role];
      return { ...prev, [userId]: next };
    });
  }

  async function saveRoles(userId: number) {
    const roles = drafts[userId] ?? [];
    if (roles.length === 0) {
      setActionError("A user must keep at least one role.");
      return;
    }
    setBusyUserId(userId);
    setActionError(null);
    setActionMessage(null);
    try {
      await radioscoreApi.updateUserRoles(userId, roles);
      setActionMessage(`Roles updated for user #${userId}.`);
      await reload();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : "Could not update roles");
    } finally {
      setBusyUserId(null);
    }
  }

  async function toggleStatus(target: UserRead) {
    const nextStatus = target.status === "active" ? "blocked" : "active";
    setBusyUserId(target.id);
    setActionError(null);
    setActionMessage(null);
    try {
      await radioscoreApi.updateUserStatus(target.id, nextStatus);
      setActionMessage(`User #${target.id} is now ${nextStatus}.`);
      await reload();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : "Could not update status");
    } finally {
      setBusyUserId(null);
    }
  }

  return (
    <section className="page-section">
      <div className="hero">
        <span className="badge badge-info">Admin workspace</span>
        <h1>User management</h1>
        <p className="muted">
          Assign global roles and block or unblock accounts. Changes are recorded in the audit log.
        </p>
        <div className="inline-actions">
          <button className="button button-ghost" disabled={loading} onClick={reload} type="button">
            Refresh
          </button>
        </div>
      </div>

      {actionError ? <ErrorState error={actionError} /> : null}
      {actionMessage ? <div className="state state-muted">{actionMessage}</div> : null}

      {loading ? <LoadingState label="Loading users..." /> : null}
      {error ? (
        <ErrorState
          error={error}
          action={
            <button className="button button-ghost" onClick={reload} type="button">
              Retry
            </button>
          }
        />
      ) : null}
      {!loading && !error && users?.length === 0 ? (
        <EmptyState title="No users" description="No accounts have been registered yet." />
      ) : null}

      {users?.length ? (
        <article className="card table-wrap">
          <table>
            <thead>
              <tr>
                <th>User</th>
                <th>Roles</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((target) => {
                const draft = drafts[target.id] ?? target.global_roles;
                const isSelf = currentUser?.id === target.id;
                const dirty = !sameRoles(draft, usersById.get(target.id)?.global_roles ?? []);
                const busy = busyUserId === target.id;
                return (
                  <tr key={target.id}>
                    <td>
                      <div className="stacked-cell">
                        <strong>{target.display_name || target.email}</strong>
                        <small className="muted">{target.email}</small>
                        {target.callsign ? <small className="muted">{target.callsign}</small> : null}
                      </div>
                    </td>
                    <td>
                      <div className="role-options">
                        {ALL_ROLES.map((role) => {
                          const lockSelfAdmin = isSelf && role === "admin";
                          return (
                            <label className="role-option" key={role}>
                              <input
                                checked={draft.includes(role)}
                                disabled={busy || lockSelfAdmin}
                                onChange={() => toggleRole(target.id, role)}
                                type="checkbox"
                              />
                              <span>{role}</span>
                            </label>
                          );
                        })}
                      </div>
                    </td>
                    <td>
                      <StatusBadge value={target.status} />
                    </td>
                    <td>
                      <div className="inline-actions">
                        <button
                          className="button button-secondary"
                          disabled={busy || !dirty}
                          onClick={() => void saveRoles(target.id)}
                          type="button"
                        >
                          {busy ? "Saving..." : "Save roles"}
                        </button>
                        <button
                          className="button button-ghost"
                          disabled={busy || isSelf}
                          onClick={() => void toggleStatus(target)}
                          title={isSelf ? "You cannot change your own status" : undefined}
                          type="button"
                        >
                          {target.status === "active" ? "Block" : "Unblock"}
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </article>
      ) : null}
    </section>
  );
}
