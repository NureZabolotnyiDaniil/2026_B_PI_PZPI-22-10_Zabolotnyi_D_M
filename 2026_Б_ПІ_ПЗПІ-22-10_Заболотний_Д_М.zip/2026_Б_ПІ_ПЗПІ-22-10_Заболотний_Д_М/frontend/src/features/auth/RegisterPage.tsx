import { FormEvent, useState } from "react";
import { Link, Navigate } from "react-router-dom";

import { useAuth } from "../../shared/auth/AuthContext";
import { Field, FormActions } from "../../shared/components/Form";
import { ErrorState } from "../../shared/components/State";
import type { FormStatus } from "../../shared/types/forms";

export function RegisterPage() {
  const { register, isAuthenticated } = useAuth();
  const [form, setForm] = useState({ email: "", password: "", display_name: "", callsign: "" });
  const [status, setStatus] = useState<FormStatus>({ submitting: false, error: null, success: null });

  if (isAuthenticated) {
    return <Navigate to="/me" replace />;
  }

  function updateField(field: keyof typeof form, value: string) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setStatus({ submitting: true, error: null, success: null });
    try {
      await register({
        email: form.email,
        password: form.password,
        display_name: form.display_name || undefined,
        callsign: form.callsign || undefined
      });
    } catch (error) {
      setStatus({
        submitting: false,
        error: error instanceof Error ? error.message : "Unable to register",
        success: null
      });
    }
  }

  return (
    <section className="page-section narrow">
      <div className="hero">
        <h1>Create account</h1>
        <p className="muted">Register once, then submit logs and access personal reports across contests.</p>
      </div>

      <form className="card" onSubmit={handleSubmit}>
        {status.error ? <ErrorState error={status.error} /> : null}
        <Field label="Email">
          <input autoComplete="email" required type="email" value={form.email} onChange={(event) => updateField("email", event.target.value)} />
        </Field>
        <Field label="Password" hint="At least 8 characters.">
          <input
            autoComplete="new-password"
            minLength={8}
            required
            type="password"
            value={form.password}
            onChange={(event) => updateField("password", event.target.value)}
          />
        </Field>
        <Field label="Display name">
          <input value={form.display_name} onChange={(event) => updateField("display_name", event.target.value)} />
        </Field>
        <Field label="Callsign">
          <input value={form.callsign} onChange={(event) => updateField("callsign", event.target.value.toUpperCase())} />
        </Field>
        <FormActions>
          <button className="button button-primary" disabled={status.submitting} type="submit">
            {status.submitting ? "Creating..." : "Create account"}
          </button>
          <Link to="/login">Already have an account?</Link>
        </FormActions>
      </form>
    </section>
  );
}
