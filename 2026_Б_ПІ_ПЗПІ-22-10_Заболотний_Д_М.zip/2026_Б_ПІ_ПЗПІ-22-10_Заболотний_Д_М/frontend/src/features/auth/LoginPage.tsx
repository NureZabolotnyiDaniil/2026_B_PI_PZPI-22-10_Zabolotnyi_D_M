import { FormEvent, useState } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";

import { useAuth } from "../../shared/auth/AuthContext";
import { Field, FormActions } from "../../shared/components/Form";
import { ErrorState } from "../../shared/components/State";
import type { FormStatus } from "../../shared/types/forms";

export function LoginPage() {
  const { login, isAuthenticated } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [status, setStatus] = useState<FormStatus>({ submitting: false, error: null, success: null });

  if (isAuthenticated) {
    return <Navigate to="/me" replace />;
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setStatus({ submitting: true, error: null, success: null });
    try {
      await login(email, password);
      const from = (location.state as { from?: { pathname?: string } } | null)?.from?.pathname ?? "/me";
      navigate(from, { replace: true });
    } catch (error) {
      setStatus({
        submitting: false,
        error: error instanceof Error ? error.message : "Unable to login",
        success: null
      });
    }
  }

  return (
    <section className="page-section narrow">
      <div className="hero">
        <h1>Login</h1>
        <p className="muted">Use your RadioScore account to manage participations and submissions.</p>
      </div>

      <form className="card" onSubmit={handleSubmit}>
        {status.error ? <ErrorState error={status.error} /> : null}
        <Field label="Email">
          <input autoComplete="email" required type="email" value={email} onChange={(event) => setEmail(event.target.value)} />
        </Field>
        <Field label="Password">
          <input
            autoComplete="current-password"
            required
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
          />
        </Field>
        <FormActions>
          <button className="button button-primary" disabled={status.submitting} type="submit">
            {status.submitting ? "Signing in..." : "Sign in"}
          </button>
          <Link to="/register">Create account</Link>
        </FormActions>
      </form>
    </section>
  );
}
