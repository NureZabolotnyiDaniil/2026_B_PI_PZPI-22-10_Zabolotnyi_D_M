import { radioscoreApi } from "../../shared/api/radioscore";
import { ErrorState, LoadingState } from "../../shared/components/State";
import { useAsync } from "../../shared/hooks/useAsync";
import { useContest } from "../contest/contestContext";

export function JudgeContestDashboardPage() {
  const { contest } = useContest();
  const {
    data: dashboard,
    error,
    loading
  } = useAsync(() => radioscoreApi.getJudgeDashboard(contest.id), [contest.id]);

  return (
    <div className="page-section">
      <article className="card">
        <h2>Queue metrics</h2>
        {loading ? <LoadingState label="Loading queue metrics..." /> : null}
        {error ? <ErrorState error={error} /> : null}
        {dashboard ? (
          <div className="grid three">
            <Metric label="Total QSO" value={dashboard.total_qso.toLocaleString()} />
            <Metric label="Auto-resolved" value={`${(dashboard.auto_resolved_ratio * 100).toFixed(1)}%`} />
            <Metric label="Pending conflicts" value={dashboard.pending_conflicts.toLocaleString()} />
            <Metric label="High priority" value={dashboard.high_priority_conflicts.toLocaleString()} />
            <Metric label="Avg confidence" value={dashboard.avg_confidence.toFixed(2)} />
          </div>
        ) : null}
      </article>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="state state-muted metric">
      <strong>{value}</strong>
      <span>{label}</span>
    </div>
  );
}
