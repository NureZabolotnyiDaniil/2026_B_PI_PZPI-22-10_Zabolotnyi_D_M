import { useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";

import { radioscoreApi } from "../../shared/api/radioscore";
import { EmptyState, ErrorState, LoadingState } from "../../shared/components/State";
import { StatusBadge } from "../../shared/components/StatusBadge";
import { useAsync } from "../../shared/hooks/useAsync";
import type { ConflictType } from "../../shared/types/domain";
import { formatDateTime } from "../../shared/utils/format";

const conflictTypes: ConflictType[] = [
  "nil",
  "ambiguous",
  "busted_call",
  "time_mismatch",
  "band_mismatch",
  "mode_mismatch",
  "exchange_mismatch",
  "duplicate_qso",
  "missing_counterparty_log"
];

export function ConflictQueuePage() {
  const { contestId = "" } = useParams();
  const [station, setStation] = useState("");
  const [band, setBand] = useState("");
  const [typeFilter, setTypeFilter] = useState<ConflictType | "">("");
  const [confidenceLt, setConfidenceLt] = useState("0.7");

  const query = useMemo(
    () => ({
      station: station || undefined,
      band: band || undefined,
      conflict_type: typeFilter || undefined,
      confidence_lt: confidenceLt ? Number(confidenceLt) : undefined,
      sort_by: "confidence" as const,
      sort_dir: "asc" as const,
      unresolved_first: true,
      limit: 100,
      offset: 0
    }),
    [band, confidenceLt, station, typeFilter]
  );

  /** Serialize queue filters so the review page keeps neighbor navigation parity */
  const reviewQueryString = useMemo(() => {
    const params = new URLSearchParams();
    params.set("contestId", contestId);
    if (station.trim()) params.set("station", station.trim());
    if (band.trim()) params.set("band", band.trim());
    if (typeFilter) params.set("type", typeFilter);
    if (confidenceLt.trim()) params.set("confidenceLt", confidenceLt.trim());
    return params.toString();
  }, [band, contestId, confidenceLt, station, typeFilter]);

  const { data, error, loading, reload } = useAsync(
    () => radioscoreApi.listJudgeConflicts(contestId, query),
    [contestId, query]
  );

  return (
    <div className="page-section">
      <article className="card">
        <h2>Filters</h2>
        <p className="muted">Filters apply automatically as you change them.</p>
        <div className="filter-row">
          <label className="field">
            <span>Station</span>
            <input onChange={(event) => setStation(event.target.value)} placeholder="UT5XX" value={station} />
          </label>
          <label className="field">
            <span>Band</span>
            <input onChange={(event) => setBand(event.target.value)} placeholder="20M" value={band} />
          </label>
          <label className="field">
            <span>Type</span>
            <select onChange={(event) => setTypeFilter(event.target.value as ConflictType | "")} value={typeFilter}>
              <option value="">Any</option>
              {conflictTypes.map((type) => (
                <option key={type} value={type}>
                  {type.replaceAll("_", " ")}
                </option>
              ))}
            </select>
          </label>
          <label className="field">
            <span>Confidence &lt;</span>
            <input
              max="1"
              min="0"
              onChange={(event) => setConfidenceLt(event.target.value)}
              step="0.01"
              type="number"
              value={confidenceLt}
            />
          </label>
        </div>
      </article>

      <article className="card table-wrap">
        <div className="meta-row">
          <h2>Conflicts</h2>
          <span className="muted">{data ? `${data.total} total` : ""}</span>
        </div>
        {loading ? <LoadingState label="Loading conflicts..." /> : null}
        {error ? (
          <ErrorState error={error} action={<button className="button button-ghost" onClick={reload}>Retry</button>} />
        ) : null}
        {!loading && !error && data?.items.length === 0 ? (
          <EmptyState title="No conflicts with this filter" />
        ) : null}
        {data?.items.length ? (
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Station</th>
                <th>Type</th>
                <th>Band/Mode</th>
                <th>Confidence</th>
                <th>Impact</th>
                <th>Detected</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {data.items.map((item) => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>
                    <strong>{item.participant_callsign}</strong>
                    <br />
                    <small className="muted">{item.counterparty_callsign}</small>
                  </td>
                  <td>
                    <StatusBadge value={item.status} /> <StatusBadge value={item.type} />
                  </td>
                  <td>
                    {item.band} / {item.mode}
                  </td>
                  <td>{item.confidence.toFixed(2)}</td>
                  <td>{item.impact}</td>
                  <td>{formatDateTime(item.detected_at_utc)}</td>
                  <td>
                    <Link to={`/judge/conflicts/${item.id}${reviewQueryString ? `?${reviewQueryString}` : ""}`}>
                      Review
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : null}
      </article>
    </div>
  );
}
