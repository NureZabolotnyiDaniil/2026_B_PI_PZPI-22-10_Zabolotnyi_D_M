import { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom";

import { radioscoreApi } from "../../shared/api/radioscore";
import { Breadcrumbs } from "../../shared/components/Breadcrumbs";
import { EmptyState, ErrorState, LoadingState } from "../../shared/components/State";
import { StatusBadge } from "../../shared/components/StatusBadge";
import { useAsync } from "../../shared/hooks/useAsync";
import type { JudgeDecisionType, ParticipantStationSearchHit } from "../../shared/types/domain";
import { formatDateTime } from "../../shared/utils/format";

const decisionHotkeys: Array<{ key: string; action: JudgeDecisionType; label: string }> = [
  { key: "a", action: "accept_match", label: "Accept match" },
  { key: "n", action: "mark_nil", label: "Mark NIL" },
  { key: "b", action: "mark_busted_call", label: "Mark busted call" },
  { key: "i", action: "ignore_conflict", label: "Ignore conflict" },
  { key: "r", action: "recalculate", label: "Recalculate" }
];

function isEditableTarget(target: EventTarget | null): boolean {
  if (!target || !(target instanceof HTMLElement)) {
    return false;
  }
  return Boolean(target.closest("input, textarea, select, option, [contenteditable='true']"));
}

export function ConflictReviewPage() {
  const { conflictId = "" } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const [comment, setComment] = useState("Reviewed by judge.");
  const [selectedCandidate, setSelectedCandidate] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [decisionError, setDecisionError] = useState<string | null>(null);
  const [registryQuery, setRegistryQuery] = useState("");
  const [registryHits, setRegistryHits] = useState<ParticipantStationSearchHit[]>([]);

  const { data: conflict, error, loading, reload } = useAsync(
    () => radioscoreApi.getJudgeConflict(conflictId),
    [conflictId]
  );
  const { data: decisions, reload: reloadDecisions } = useAsync(
    () => radioscoreApi.listJudgeDecisions(conflictId),
    [conflictId]
  );

  const contestIdForNav = useMemo(() => {
    const fromQuery = searchParams.get("contestId");
    if (fromQuery) {
      return Number(fromQuery);
    }
    return conflict?.contest_id ?? 0;
  }, [searchParams, conflict?.contest_id]);

  const neighborApiQuery = useMemo(
    () => ({
      contest_id: contestIdForNav,
      station: searchParams.get("station") || undefined,
      band: searchParams.get("band") || undefined,
      conflict_type: searchParams.get("type") || undefined,
      confidence_lt: searchParams.get("confidenceLt") ? Number(searchParams.get("confidenceLt")) : undefined,
      sort_by: "confidence" as const,
      sort_dir: "asc" as const,
      unresolved_first: true
    }),
    [contestIdForNav, searchParams]
  );

  const searchParamsKey = searchParams.toString();

  const { data: neighbors, reload: reloadNeighbors } = useAsync(
    async () => {
      if (!conflict?.id || !contestIdForNav) {
        return undefined;
      }
      return radioscoreApi.getJudgeConflictNeighbors(conflict.id, neighborApiQuery);
    },
    [conflict?.id, contestIdForNav, searchParamsKey]
  );

  const candidateOptions = useMemo(() => {
    if (!conflict?.matching_candidates?.length) {
      return [];
    }
    return conflict.matching_candidates
      .map((row) => ({
        id: Number(row.candidate_qso_id),
        callsign: String(row.candidate_callsign || row.candidate_station_callsign || "unknown")
      }))
      .filter((row) => Number.isFinite(row.id));
  }, [conflict?.matching_candidates]);

  const judgeView = useMemo(() => {
    const raw = conflict?.explainability?.judge_view;
    return raw && typeof raw === "object" ? (raw as Record<string, unknown>) : null;
  }, [conflict?.explainability]);

  useEffect(() => {
    if (candidateOptions.length && selectedCandidate === null) {
      setSelectedCandidate(candidateOptions[0].id);
    }
  }, [candidateOptions, selectedCandidate]);

  useEffect(() => {
    const handle = window.setTimeout(() => {
      const q = registryQuery.trim();
      if (!conflict?.contest_id || q.length < 2) {
        setRegistryHits([]);
        return;
      }
      void radioscoreApi
        .searchJudgeContestParticipants(conflict.contest_id, q, 40)
        .then(setRegistryHits)
        .catch(() => setRegistryHits([]));
    }, 280);
    return () => window.clearTimeout(handle);
  }, [registryQuery, conflict?.contest_id]);

  const navigateWithQueueContext = useCallback(
    (targetConflictId: number) => {
      const suffix = searchParamsKey ? `?${searchParamsKey}` : "";
      navigate(`/judge/conflicts/${targetConflictId}${suffix}`);
    },
    [navigate, searchParamsKey]
  );

  const submitDecision = useCallback(
    async (decision: JudgeDecisionType, options?: { advanceToNext?: boolean }) => {
      setBusy(true);
      setDecisionError(null);
      try {
        await radioscoreApi.createJudgeDecision(conflictId, {
          decision,
          comment,
          score_impact: 0,
          selected_candidate_qso_id: decision === "override_match" ? selectedCandidate : undefined
        });
        if (options?.advanceToNext && neighbors?.next_conflict_id) {
          navigateWithQueueContext(neighbors.next_conflict_id);
          return;
        }
        await reload();
        await reloadDecisions();
        await reloadNeighbors();
      } catch (caught) {
        setDecisionError(caught instanceof Error ? caught.message : "Decision failed");
      } finally {
        setBusy(false);
      }
    },
    [comment, conflictId, navigateWithQueueContext, neighbors?.next_conflict_id, reload, reloadDecisions, reloadNeighbors, selectedCandidate]
  );

  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if (event.metaKey || event.ctrlKey || event.altKey) {
        return;
      }
      if (isEditableTarget(event.target)) {
        return;
      }

      if (event.key === "[" && neighbors?.prev_conflict_id) {
        event.preventDefault();
        navigateWithQueueContext(neighbors.prev_conflict_id);
        return;
      }
      if (event.key === "]" && neighbors?.next_conflict_id) {
        event.preventDefault();
        navigateWithQueueContext(neighbors.next_conflict_id);
        return;
      }

      const hotkey = decisionHotkeys.find((item) => item.key === event.key.toLowerCase());
      if (!hotkey || busy) {
        return;
      }
      event.preventDefault();
      void submitDecision(hotkey.action, { advanceToNext: event.shiftKey && hotkey.action !== "recalculate" });
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [busy, navigateWithQueueContext, neighbors?.next_conflict_id, neighbors?.prev_conflict_id, submitDecision]);

  if (loading) {
    return <LoadingState label="Loading conflict..." />;
  }
  if (error) {
    return <ErrorState error={error} />;
  }
  if (!conflict) {
    return <EmptyState title="Conflict not found" />;
  }

  return (
    <section className="page-section">
      <Breadcrumbs
        items={[
          { label: "Judge", to: "/judge" },
          { label: `Contest #${conflict.contest_id}`, to: `/contests/${conflict.contest_id}/judge` },
          { label: "Conflicts", to: `/contests/${conflict.contest_id}/judge/conflicts` },
          { label: `Conflict #${conflict.id}` }
        ]}
      />
      <div className="hero">
        <div className="meta-row">
          <StatusBadge value={conflict.status} />
          <StatusBadge value={conflict.type} />
          <span className="muted">Conflict #{conflict.id}</span>
        </div>
        <h1>Conflict Review</h1>
        <p className="muted">Structured cross-check context, candidate ranking, and keyboard-friendly navigation.</p>
        <div className="inline-actions" style={{ marginTop: "0.75rem" }}>
          <button
            className="button button-ghost"
            disabled={!neighbors?.prev_conflict_id}
            type="button"
            onClick={() => neighbors?.prev_conflict_id && navigateWithQueueContext(neighbors.prev_conflict_id)}
          >
            Previous [
          </button>
          <button
            className="button button-ghost"
            disabled={!neighbors?.next_conflict_id}
            type="button"
            onClick={() => neighbors?.next_conflict_id && navigateWithQueueContext(neighbors.next_conflict_id)}
          >
            Next ]
          </button>
          <span className="muted">
            Queue position: {neighbors?.index != null ? neighbors.index + 1 : "—"} / {neighbors?.total_matching_filters ?? "—"}
          </span>
        </div>
      </div>
      {decisionError ? <ErrorState error={decisionError} /> : null}
      <div className="split">
        <article className="card">
          <h2>Original QSO</h2>
          <p>
            <strong>{conflict.qso.participant_callsign}</strong> → <strong>{conflict.qso.counterparty_callsign}</strong>
          </p>
          <p>
            {conflict.qso.band} {conflict.qso.mode} at {formatDateTime(conflict.qso.qso_at_utc)}
          </p>

          <h3>Cross-check summary</h3>
          {judgeView ? (
            <div className="judge-view">
              <p>
                <strong>{String(judgeView.headline ?? "")}</strong>
              </p>
              {judgeView.detail ? <p className="muted">{String(judgeView.detail)}</p> : null}
              <p>
                Confidence{" "}
                <strong>
                  {typeof judgeView.confidence_percent === "number" ? judgeView.confidence_percent : "—"}%
                </strong>
                {judgeView.pipeline_decision ? (
                  <span className="muted"> — {String(judgeView.pipeline_decision)}</span>
                ) : null}
              </p>
              {Boolean(judgeView.probable_typo) ? (
                <p className="muted">
                  <strong>Probable typo band</strong> — verify callsign + exchange carefully.
                </p>
              ) : null}
              {Array.isArray(judgeView.ranked_candidates) && judgeView.ranked_candidates.length ? (
                <div>
                  <h4>Ranked candidates</h4>
                  <ol>
                    {(judgeView.ranked_candidates as Record<string, unknown>[]).map((row, index) => (
                      <li key={String(row.candidate_qso_id ?? index)}>
                        <strong>{String(row.candidate_callsign ?? row.candidate_station_callsign ?? "?")}</strong> —{" "}
                        {typeof row.confidence_percent === "number" ? row.confidence_percent : "—"}%
                        {row.time_delta_seconds != null ? (
                          <span className="muted"> — Δt {String(row.time_delta_seconds)}s</span>
                        ) : null}
                      </li>
                    ))}
                  </ol>
                </div>
              ) : null}
              {Array.isArray(judgeView.nearby_callsigns) && judgeView.nearby_callsigns.length ? (
                <p className="muted">
                  Nearby callsigns: {(judgeView.nearby_callsigns as unknown[]).map(String).join(", ")}
                </p>
              ) : null}
            </div>
          ) : (
            <EmptyState title="No structured summary (legacy conflict details)" />
          )}

          <h3>Participant registry search</h3>
          <p className="muted">Search stations registered for this contest (partial callsign).</p>
          <input
            onChange={(event) => setRegistryQuery(event.target.value)}
            placeholder="e.g. UT5"
            style={{ width: "100%", padding: "0.5rem", marginBottom: "0.5rem" }}
            type="search"
            value={registryQuery}
          />
          {registryHits.length ? (
            <ul>
              {registryHits.map((hit) => (
                <li key={hit.callsign}>
                  <strong>{hit.callsign}</strong>
                  {hit.category ? <span className="muted"> · {hit.category}</span> : null}
                  {hit.region ? <span className="muted"> · {hit.region}</span> : null}
                </li>
              ))}
            </ul>
          ) : (
            <p className="muted">{registryQuery.trim().length >= 2 ? "No hits" : "Enter at least two characters"}</p>
          )}

          <h3>Candidate matches</h3>
          {conflict.matching_candidates?.length ? (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Candidate</th>
                    <th>Conf</th>
                    <th>Δt (s)</th>
                    <th>Band/Mode</th>
                    <th>Stage</th>
                    <th>Select</th>
                  </tr>
                </thead>
                <tbody>
                  {conflict.matching_candidates.map((row) => {
                    const id = Number(row.candidate_qso_id);
                    const cs = String(row.candidate_callsign || row.candidate_station_callsign || "?");
                    const conf = typeof row.confidence === "number" ? row.confidence : Number(row.confidence);
                    const dt = row.time_delta_seconds;
                    return (
                      <tr key={id}>
                        <td>
                          <strong>{cs}</strong>
                          <div className="muted" style={{ fontSize: "0.85rem" }}>
                            Candidate: {cs} → {String(row.their_logged_counterparty ?? "—")}
                          </div>
                          {row.comparison &&
                          typeof row.comparison === "object" &&
                          Array.isArray((row.comparison as { differences?: unknown }).differences) ? (
                            <div className="muted" style={{ fontSize: "0.85rem" }}>
                              Differences:{" "}
                              {((row.comparison as { differences: unknown[] }).differences).map(String).join(", ")}
                            </div>
                          ) : null}
                        </td>
                        <td>{Number.isFinite(conf) ? conf.toFixed(2) : "—"}</td>
                        <td>{dt != null ? String(dt) : "—"}</td>
                        <td>
                          {String(row.band ?? "")} / {String(row.mode ?? "")}
                        </td>
                        <td>{String(row.stage ?? "")}</td>
                        <td>
                          <label>
                            <input
                              checked={selectedCandidate === id}
                              name="candidate"
                              onChange={() => setSelectedCandidate(id)}
                              type="radio"
                            />{" "}
                            pick
                          </label>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <EmptyState title="No candidate rows" />
          )}
          {candidateOptions.length && !conflict.matching_candidates?.length ? (
            <table>
              <thead>
                <tr>
                  <th>Candidate</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {candidateOptions.map((candidate) => (
                  <tr key={candidate.id}>
                    <td>{candidate.callsign}</td>
                    <td>
                      <label>
                        <input
                          checked={selectedCandidate === candidate.id}
                          name="candidate_fallback"
                          onChange={() => setSelectedCandidate(candidate.id)}
                          type="radio"
                        />{" "}
                        Select
                      </label>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : null}

          <h3>Signals & rationale</h3>
          {conflict.matching_candidates?.some((c) => Array.isArray((c as { rationale?: unknown }).rationale)) ? (
            <ul>
              {conflict.matching_candidates.slice(0, 5).flatMap((raw) => {
                const r = (raw as { rationale?: string[]; candidate_callsign?: string }).rationale;
                if (!r?.length) {
                  return [];
                }
                const label = String((raw as { candidate_callsign?: string }).candidate_callsign ?? "?");
                return r.map((line) => (
                  <li key={`${label}:${line}`}>
                    <strong>{label}</strong>: {line}
                  </li>
                ));
              })}
            </ul>
          ) : (
            <p className="muted">Expand technical JSON for full pipeline output.</p>
          )}

          <details>
            <summary>Technical JSON (debug)</summary>
            <pre className="code-block">{JSON.stringify(conflict.explainability || conflict.details, null, 2)}</pre>
            <h4>Timeline</h4>
            <pre className="code-block">{JSON.stringify(conflict.timeline || {}, null, 2)}</pre>
          </details>

          <h3>Raw Cabrillo</h3>
          <pre className="code-block">{conflict.qso.raw_line}</pre>
        </article>
        <aside className="card">
          <h2>Judge actions</h2>
          <label>
            Reason
            <textarea onChange={(event) => setComment(event.target.value)} value={comment} />
          </label>
          <p className="muted">
            Shortcuts: Accept A, NIL N, Busted B, Ignore I, Recalc R — only when not typing in a field. Navigation: [ / ] .
            Hold <kbd>Shift</kbd> while activating a decision shortcut to jump to the next conflict after submit.
          </p>
          <div className="grid">
            {decisionHotkeys.map((item) => (
              <button
                key={item.action}
                className="button button-secondary"
                disabled={busy}
                type="button"
                onClick={() => void submitDecision(item.action, { advanceToNext: false })}
              >
                {item.label} [{item.key.toUpperCase()}]
              </button>
            ))}
            <button
              className="button button-primary"
              disabled={busy || selectedCandidate === null}
              type="button"
              onClick={() => void submitDecision("override_match", { advanceToNext: false })}
            >
              Override match
            </button>
          </div>
          <h3>Audit trail</h3>
          {decisions?.length ? (
            <ul>
              {decisions.map((decision) => (
                <li key={decision.id}>
                  <strong>{decision.decision}</strong> - {formatDateTime(decision.created_at_utc)}
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState title="No judge decisions yet" />
          )}
          <Link className="button button-ghost" to={`/contests/${conflict.contest_id}/judge/conflicts`}>
            Back to queue
          </Link>
        </aside>
      </div>
    </section>
  );
}
