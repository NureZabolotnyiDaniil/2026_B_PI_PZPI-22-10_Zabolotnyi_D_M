import { Link } from "react-router-dom";

import { radioscoreApi } from "../../shared/api/radioscore";
import { EmptyState, ErrorState, LoadingState } from "../../shared/components/State";
import { StatusBadge } from "../../shared/components/StatusBadge";
import { useAsync } from "../../shared/hooks/useAsync";
import { formatDateTime } from "../../shared/utils/format";

export function JudgeLandingPage() {
  const { data: contests, error, loading, reload } = useAsync(() => radioscoreApi.listJudgeContests(), []);

  return (
    <section className="page-section">
      <div className="hero">
        <span className="badge badge-info">Judge workspace</span>
        <h1>Assigned contests</h1>
        <p className="muted">Open a contest to review its dashboard metrics and conflict queue.</p>
      </div>

      {loading ? <LoadingState label="Loading assigned contests..." /> : null}
      {error ? (
        <ErrorState error={error} action={<button className="button button-ghost" onClick={reload}>Retry</button>} />
      ) : null}
      {!loading && !error && contests?.length === 0 ? (
        <EmptyState title="No assigned contests" description="Ask an organizer to assign you as a contest judge." />
      ) : null}

      <div className="grid two">
        {contests?.map((contest) => (
          <article className="card" key={contest.id}>
            <div className="meta-row">
              <StatusBadge value={contest.status} />
              <span className="muted">{formatDateTime(contest.start_at_utc)}</span>
            </div>
            <h2>{contest.title}</h2>
            <div className="inline-actions">
              <Link className="button button-primary" to={`/contests/${contest.id}/judge`}>
                Judge dashboard
              </Link>
              <Link className="button button-ghost" to={`/contests/${contest.id}/judge/conflicts`}>
                Conflict queue
              </Link>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
