import { Link } from "react-router-dom";

import { radioscoreApi } from "../../shared/api/radioscore";
import { ContestCard } from "../../shared/components/ContestCard";
import { EmptyState, ErrorState, LoadingState } from "../../shared/components/State";
import { useAsync } from "../../shared/hooks/useAsync";

export function OrganizerDashboardPage() {
  const { data: contests, error, loading, reload } = useAsync(radioscoreApi.listOrganizerContests, []);

  return (
    <section className="page-section">
      <div className="hero">
        <span className="badge badge-info">Organizer workspace</span>
        <h1>Contest management</h1>
        <p className="muted">
          Create contests, monitor submissions and move contests through the MVP lifecycle.
        </p>
        <div className="inline-actions">
          <Link className="button button-primary" to="/organizer/contests/new">
            New contest
          </Link>
        </div>
      </div>

      {loading ? <LoadingState label="Loading contests..." /> : null}
      {error ? <ErrorState error={error} action={<button className="button button-ghost" onClick={reload}>Retry</button>} /> : null}
      {!loading && !error && contests?.length === 0 ? (
        <EmptyState title="No visible contests" description="Create a contest to start the organizer workflow." />
      ) : null}

      <div className="grid two">
        {contests?.map((contest) => (
          <div className="card" key={contest.id}>
            <ContestCard contest={contest} />
            <Link className="button button-secondary" to={`/contests/${contest.id}/manage`}>
              Manage contest
            </Link>
          </div>
        ))}
      </div>
    </section>
  );
}
