import { type FormEvent, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";

import { radioscoreApi } from "../../shared/api/radioscore";
import { EmptyState, ErrorState, LoadingState } from "../../shared/components/State";
import { StatusBadge } from "../../shared/components/StatusBadge";
import { useAsync } from "../../shared/hooks/useAsync";
import { useProcessingJob } from "../../shared/hooks/useProcessingJob";
import type { ContestRead, ContestStatus, ProcessingJobRead } from "../../shared/types/domain";
import { formatDateTime } from "../../shared/utils/format";
import { useContest } from "../contest/contestContext";

type ActionKind = "publish" | "open-logs" | "close-logs" | "finalize" | "cross-check" | "publish-results";

const ACTION_LABELS: Record<ActionKind, string> = {
  publish: "Publish",
  "open-logs": "Open logs",
  "close-logs": "Close logs",
  finalize: "Finalize",
  "cross-check": "Run cross-check",
  "publish-results": "Publish results"
};

const ACTIONS_BY_STATUS: Record<ContestStatus, ActionKind[]> = {
  draft: ["publish"],
  published: ["open-logs"],
  accepting_logs: ["close-logs"],
  log_submission_closed: ["cross-check", "finalize"],
  checking: ["cross-check", "finalize"],
  judge_review: ["cross-check", "finalize"],
  finalized: ["publish-results"],
  results_published: [],
  archived: []
};

function runActionKind(contestId: number, kind: ActionKind) {
  switch (kind) {
    case "cross-check":
      return radioscoreApi.crossCheckContest(contestId);
    case "publish-results":
      return radioscoreApi.publishResults(contestId);
    default:
      return radioscoreApi.transitionContest(contestId, kind);
  }
}

export function OrganizerContestPage() {
  const { contest, reloadContest } = useContest();
  const base = `/contests/${contest.id}`;

  const [actionError, setActionError] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);
  const [actionBusy, setActionBusy] = useState<ActionKind | null>(null);
  const [activeJob, setActiveJob] = useState<ProcessingJobRead | null>(null);
  const completedJobRef = useRef<number | null>(null);
  const { job: polledJob, error: jobPollingError } = useProcessingJob(
    activeJob?.id,
    activeJob
  );
  const trackedJob = polledJob ?? activeJob;

  const {
    data: submissions,
    error: submissionsError,
    loading: submissionsLoading,
    reload: reloadSubmissions
  } = useAsync(() => radioscoreApi.listContestSubmissions(contest.id), [contest.id]);
  const {
    data: judges,
    error: judgesError,
    loading: judgesLoading,
    reload: reloadJudges
  } = useAsync(() => radioscoreApi.listContestJudges(contest.id), [contest.id]);

  const [judgeEmail, setJudgeEmail] = useState("");
  const [judgeFormError, setJudgeFormError] = useState<string | null>(null);
  const [judgeBusy, setJudgeBusy] = useState(false);

  useEffect(() => {
    if (
      trackedJob &&
      ["succeeded", "failed", "cancelled"].includes(trackedJob.status) &&
      completedJobRef.current !== trackedJob.id
    ) {
      completedJobRef.current = trackedJob.id;
      setActionMessage(
        trackedJob.status === "succeeded"
          ? `Cross-check job #${trackedJob.id} completed.`
          : `Cross-check job #${trackedJob.id} ${trackedJob.status}.`
      );
      if (trackedJob.error_message) setActionError(trackedJob.error_message);
      void Promise.all([reloadContest(), reloadSubmissions()]);
    }
  }, [reloadContest, reloadSubmissions, trackedJob]);

  async function runAction(kind: ActionKind) {
    setActionBusy(kind);
    setActionError(null);
    setActionMessage(null);
    try {
      const result = await runActionKind(contest.id, kind);
      if (result && typeof result === "object" && "id" in result && "status" in result) {
        const job = result as ProcessingJobRead;
        if (kind === "cross-check") {
          completedJobRef.current = null;
          setActiveJob(job);
        }
        setActionMessage(`${ACTION_LABELS[kind]} started job #${job.id} (${job.status}).`);
      } else {
        setActionMessage(`${ACTION_LABELS[kind]} completed.`);
      }
      await reloadContest();
      await reloadSubmissions();
      await reloadJudges();
    } catch (error) {
      setActionError(error instanceof Error ? error.message : `${ACTION_LABELS[kind]} failed`);
    } finally {
      setActionBusy(null);
    }
  }

  async function handleAddJudge(event: FormEvent) {
    event.preventDefault();
    const email = judgeEmail.trim().toLowerCase();
    if (!email) {
      setJudgeFormError("Enter the judge account email.");
      return;
    }
    setJudgeBusy(true);
    setJudgeFormError(null);
    try {
      await radioscoreApi.addContestJudge(contest.id, { email });
      setJudgeEmail("");
      await reloadJudges();
    } catch (error) {
      setJudgeFormError(error instanceof Error ? error.message : "Could not add judge");
    } finally {
      setJudgeBusy(false);
    }
  }

  async function handleRemoveJudge(userId: number) {
    setJudgeBusy(true);
    setJudgeFormError(null);
    try {
      await radioscoreApi.removeContestJudge(contest.id, userId);
      await reloadJudges();
    } catch (error) {
      setJudgeFormError(error instanceof Error ? error.message : "Could not remove judge");
    } finally {
      setJudgeBusy(false);
    }
  }

  return (
    <div className="page-section">
      {contest.status === "draft" ? (
        <div className="inline-actions">
          <Link className="button button-secondary" to={`${base}/manage/edit`}>
            Edit contest
          </Link>
        </div>
      ) : null}

      <div className="grid two">
        <LifecycleCard
          busy={
            actionBusy ??
            (trackedJob && ["queued", "running"].includes(trackedJob.status)
              ? "cross-check"
              : null)
          }
          contest={contest}
          error={actionError}
          message={actionMessage}
          onAction={runAction}
        />
        <ContestSummary contest={contest} />
      </div>
      {trackedJob ? (
        <article className="card">
          <div className="meta-row">
            <h2>Cross-check job #{trackedJob.id}</h2>
            <StatusBadge value={trackedJob.status} />
          </div>
          {trackedJob.error_message ? <ErrorState error={trackedJob.error_message} /> : null}
          {jobPollingError ? <ErrorState error={jobPollingError} /> : null}
        </article>
      ) : null}

      <article className="card">
        <div className="meta-row">
          <h2>Contest judges</h2>
          <button className="button button-ghost" disabled={judgeBusy} onClick={() => void reloadJudges()} type="button">
            Refresh
          </button>
        </div>
        <p className="muted">
          Assigned users can use judge APIs and cross-check for this contest without the global judge role.
        </p>
        <form className="inline-actions" onSubmit={(e) => void handleAddJudge(e)}>
          <label className="field" htmlFor="judge-email">
            <span>User email</span>
            <input
              autoComplete="email"
              disabled={judgeBusy}
              id="judge-email"
              name="judge-email"
              onChange={(e) => setJudgeEmail(e.target.value)}
              placeholder="registered@example.com"
              type="email"
              value={judgeEmail}
            />
          </label>
          <button className="button button-secondary" disabled={judgeBusy} type="submit">
            {judgeBusy ? "Saving..." : "Add judge"}
          </button>
        </form>
        {judgeFormError ? <ErrorState error={judgeFormError} /> : null}
        {judgesLoading ? <LoadingState label="Loading judges..." /> : null}
        {judgesError ? <ErrorState error={judgesError} /> : null}
        {!judgesLoading && !judgesError && judges?.length === 0 ? (
          <EmptyState title="No contest judges yet" description="Add accounts by email." />
        ) : null}
        {judges?.length ? (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Email</th>
                  <th>Display name</th>
                  <th>Callsign</th>
                  <th>Assigned</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {judges.map((judge) => (
                  <tr key={judge.user_id}>
                    <td>{judge.email}</td>
                    <td>{judge.display_name ?? "—"}</td>
                    <td>{judge.callsign ?? "—"}</td>
                    <td>{formatDateTime(judge.assigned_at_utc)}</td>
                    <td>
                      <button
                        className="button button-ghost"
                        disabled={judgeBusy}
                        onClick={() => void handleRemoveJudge(judge.user_id)}
                        type="button"
                      >
                        Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
      </article>

      <article className="card table-wrap">
        <div className="meta-row">
          <h2>Submissions</h2>
          <button className="button button-ghost" onClick={reloadSubmissions} type="button">
            Refresh
          </button>
        </div>
        {submissionsLoading ? <LoadingState label="Loading submissions..." /> : null}
        {submissionsError ? <ErrorState error={submissionsError} /> : null}
        {!submissionsLoading && !submissionsError && submissions?.length === 0 ? (
          <EmptyState title="No submissions" description="Uploaded Cabrillo logs will appear here." />
        ) : null}
        {submissions?.length ? (
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Participant</th>
                <th>Version</th>
                <th>Status</th>
                <th>Uploaded</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
              {submissions.map((submission) => (
                <tr key={submission.id}>
                  <td>{submission.id}</td>
                  <td>{submission.participant_id}</td>
                  <td>{submission.version}</td>
                  <td>
                    <StatusBadge value={submission.status} />
                  </td>
                  <td>{formatDateTime(submission.uploaded_at_utc)}</td>
                  <td>
                    <Link to={`/submissions/${submission.id}`}>Open</Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : null}
      </article>
    </div>
  );
}

function LifecycleCard({
  busy,
  contest,
  error,
  message,
  onAction
}: {
  busy: ActionKind | null;
  contest: ContestRead;
  error: string | null;
  message: string | null;
  onAction: (kind: ActionKind) => Promise<void>;
}) {
  const actions = ACTIONS_BY_STATUS[contest.status] ?? [];

  return (
    <article className="card">
      <h2>Lifecycle controls</h2>
      <p className="muted">Only actions valid for the current status are shown. The backend validates every transition.</p>
      {error ? <ErrorState error={error} /> : null}
      {message ? <div className="state state-muted">{message}</div> : null}
      {actions.length === 0 ? (
        <EmptyState title="No actions available" description="This contest has reached the end of its lifecycle." />
      ) : (
        <div className="inline-actions">
          {actions.map((kind) => (
            <button
              className={kind === "publish-results" ? "button button-primary" : "button button-secondary"}
              disabled={Boolean(busy)}
              key={kind}
              onClick={() => void onAction(kind)}
              type="button"
            >
              {busy === kind ? "Working..." : ACTION_LABELS[kind]}
            </button>
          ))}
        </div>
      )}
    </article>
  );
}

function ContestSummary({ contest }: { contest: ContestRead }) {
  return (
    <aside className="card">
      <h2>Schedule</h2>
      <dl className="detail-list">
        <div>
          <dt>Start</dt>
          <dd>{formatDateTime(contest.start_at_utc)}</dd>
        </div>
        <div>
          <dt>End</dt>
          <dd>{formatDateTime(contest.end_at_utc)}</dd>
        </div>
        <div>
          <dt>Logs open</dt>
          <dd>{formatDateTime(contest.log_submission_open_at_utc)}</dd>
        </div>
        <div>
          <dt>Logs deadline</dt>
          <dd>{formatDateTime(contest.log_submission_deadline_at_utc)}</dd>
        </div>
        <div>
          <dt>Categories</dt>
          <dd>{contest.categories.join(", ")}</dd>
        </div>
      </dl>
    </aside>
  );
}
