import { FormEvent, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

import { radioscoreApi } from "../../shared/api/radioscore";
import { Field, FormActions } from "../../shared/components/Form";
import { ErrorState, LoadingState } from "../../shared/components/State";
import type { ContestCreate, ContestRead } from "../../shared/types/domain";
import type { FormStatus } from "../../shared/types/forms";

function toDateInput(value: string) {
  return value ? value.slice(0, 16) : "";
}

function toIso(value: string) {
  return new Date(value).toISOString();
}

function splitCsv(value: string) {
  return value
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

function defaultDate(hoursFromNow: number) {
  const date = new Date(Date.now() + hoursFromNow * 60 * 60 * 1000);
  date.setMinutes(0, 0, 0);
  return date.toISOString().slice(0, 16);
}

const defaultForm = {
  title: "",
  description: "",
  rules_text: "",
  start_at_utc: defaultDate(24),
  end_at_utc: defaultDate(30),
  log_submission_open_at_utc: defaultDate(30),
  log_submission_deadline_at_utc: defaultDate(72),
  allowed_bands: "80m, 40m, 20m",
  allowed_modes: "CW, SSB",
  categories: "Single Operator, Multi Operator",
  qso_points: "1",
  time_tolerance_minutes: "5"
};

export function OrganizerContestFormPage() {
  const { contestId } = useParams();
  const navigate = useNavigate();
  const editing = Boolean(contestId);
  const [form, setForm] = useState(defaultForm);
  const [loading, setLoading] = useState(editing);
  const [status, setStatus] = useState<FormStatus>({ submitting: false, error: null, success: null });

  useEffect(() => {
    if (!contestId) {
      return;
    }
    let active = true;
    radioscoreApi
      .getOrganizerContest(contestId)
      .then((contest: ContestRead) => {
        if (!active) {
          return;
        }
        setForm({
          title: contest.title,
          description: contest.description,
          rules_text: contest.rules_text,
          start_at_utc: toDateInput(contest.start_at_utc),
          end_at_utc: toDateInput(contest.end_at_utc),
          log_submission_open_at_utc: toDateInput(contest.log_submission_open_at_utc),
          log_submission_deadline_at_utc: toDateInput(contest.log_submission_deadline_at_utc),
          allowed_bands: contest.allowed_bands.join(", "),
          allowed_modes: contest.allowed_modes.join(", "),
          categories: contest.categories.join(", "),
          qso_points: String(contest.scoring_rule?.qso_points ?? 1),
          time_tolerance_minutes: String(contest.scoring_rule?.time_tolerance_minutes ?? 5)
        });
      })
      .catch((error) => {
        setStatus({
          submitting: false,
          error: error instanceof Error ? error.message : "Unable to load contest",
          success: null
        });
      })
      .finally(() => setLoading(false));
    return () => {
      active = false;
    };
  }, [contestId]);

  function updateField(field: keyof typeof form, value: string) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  function buildPayload(): ContestCreate {
    return {
      title: form.title,
      description: form.description,
      rules_text: form.rules_text,
      start_at_utc: toIso(form.start_at_utc),
      end_at_utc: toIso(form.end_at_utc),
      log_submission_open_at_utc: toIso(form.log_submission_open_at_utc),
      log_submission_deadline_at_utc: toIso(form.log_submission_deadline_at_utc),
      allowed_bands: splitCsv(form.allowed_bands),
      allowed_modes: splitCsv(form.allowed_modes),
      categories: splitCsv(form.categories),
      scoring_rule: {
        qso_points: Number(form.qso_points),
        required_exchange_fields: [],
        time_tolerance_minutes: Number(form.time_tolerance_minutes),
        duplicate_policy: "same_band_mode",
        multiplier_policy: {},
        penalty_policy: {}
      }
    };
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setStatus({ submitting: true, error: null, success: null });
    try {
      const contest = editing
        ? await radioscoreApi.updateContest(contestId as string, buildPayload())
        : await radioscoreApi.createContest(buildPayload());
      navigate(`/contests/${contest.id}/manage`);
    } catch (error) {
      setStatus({
        submitting: false,
        error: error instanceof Error ? error.message : "Unable to save contest",
        success: null
      });
    }
  }

  if (loading) {
    return <LoadingState label="Loading contest form..." />;
  }

  return (
    <section className="page-section">
      <div className="hero">
        <span className="badge badge-info">Contest setup</span>
        <h1>{editing ? "Edit contest" : "Create contest"}</h1>
        <p className="muted">Configure dates, categories, allowed bands and the MVP scoring rule.</p>
      </div>

      <form className="card" onSubmit={handleSubmit}>
        {status.error ? <ErrorState error={status.error} /> : null}
        <div className="grid two">
          <Field label="Title">
            <input required value={form.title} onChange={(event) => updateField("title", event.target.value)} />
          </Field>
          <Field label="Categories" hint="Comma-separated values.">
            <input required value={form.categories} onChange={(event) => updateField("categories", event.target.value)} />
          </Field>
          <Field label="Start">
            <input required type="datetime-local" value={form.start_at_utc} onChange={(event) => updateField("start_at_utc", event.target.value)} />
          </Field>
          <Field label="End">
            <input required type="datetime-local" value={form.end_at_utc} onChange={(event) => updateField("end_at_utc", event.target.value)} />
          </Field>
          <Field label="Log submission opens">
            <input required type="datetime-local" value={form.log_submission_open_at_utc} onChange={(event) => updateField("log_submission_open_at_utc", event.target.value)} />
          </Field>
          <Field label="Log submission deadline">
            <input required type="datetime-local" value={form.log_submission_deadline_at_utc} onChange={(event) => updateField("log_submission_deadline_at_utc", event.target.value)} />
          </Field>
          <Field label="Allowed bands" hint="Comma-separated values.">
            <input value={form.allowed_bands} onChange={(event) => updateField("allowed_bands", event.target.value)} />
          </Field>
          <Field label="Allowed modes" hint="Comma-separated values.">
            <input value={form.allowed_modes} onChange={(event) => updateField("allowed_modes", event.target.value)} />
          </Field>
          <Field label="QSO points">
            <input min={1} required type="number" value={form.qso_points} onChange={(event) => updateField("qso_points", event.target.value)} />
          </Field>
          <Field label="Time tolerance, minutes">
            <input min={1} required type="number" value={form.time_tolerance_minutes} onChange={(event) => updateField("time_tolerance_minutes", event.target.value)} />
          </Field>
        </div>
        <Field label="Description">
          <textarea required value={form.description} onChange={(event) => updateField("description", event.target.value)} />
        </Field>
        <Field label="Rules text">
          <textarea required value={form.rules_text} onChange={(event) => updateField("rules_text", event.target.value)} />
        </Field>
        <FormActions>
          <button className="button button-primary" disabled={status.submitting} type="submit">
            {status.submitting ? "Saving..." : "Save contest"}
          </button>
          <Link to={editing ? `/contests/${contestId}/manage` : "/organizer/contests"}>Cancel</Link>
        </FormActions>
      </form>
    </section>
  );
}
