import { useMemo } from "react";
import { Link, Outlet, useParams } from "react-router-dom";

import { radioscoreApi } from "../../shared/api/radioscore";
import { useAuth } from "../../shared/auth/AuthContext";
import { Breadcrumbs } from "../../shared/components/Breadcrumbs";
import { LifecycleStepper } from "../../shared/components/LifecycleStepper";
import { EmptyState, ErrorState, LoadingState } from "../../shared/components/State";
import { StatusBadge } from "../../shared/components/StatusBadge";
import { TabNav, type TabItem } from "../../shared/components/TabNav";
import { useAsync } from "../../shared/hooks/useAsync";
import type { ContestRead, ParticipantRead } from "../../shared/types/domain";
import { ContestProvider } from "./contestContext";

async function loadContest(contestId: string, canManage: boolean): Promise<ContestRead> {
  try {
    return await radioscoreApi.getPublicContest(contestId);
  } catch (error) {
    if (canManage) {
      return radioscoreApi.getOrganizerContest(contestId);
    }
    throw error;
  }
}

export function ContestLayout() {
  const { contestId = "" } = useParams();
  const { isAuthenticated, hasRole } = useAuth();
  const canManage = hasRole(["organizer", "admin"]);
  const canJudge = hasRole(["judge", "organizer", "admin"]);

  const {
    data: contest,
    error,
    loading,
    reload: reloadContest
  } = useAsync(() => loadContest(contestId, canManage), [contestId, canManage]);

  const { data: participations, reload: reloadParticipation } = useAsync(
    () =>
      isAuthenticated
        ? radioscoreApi.listMyParticipations()
        : Promise.resolve([] as ParticipantRead[]),
    [isAuthenticated, contestId]
  );

  const myParticipation = useMemo(
    () => participations?.find((item) => String(item.contest_id) === String(contestId)) ?? null,
    [participations, contestId]
  );

  const base = `/contests/${contestId}`;

  const tabs = useMemo<TabItem[]>(() => {
    if (!contest) {
      return [];
    }
    const items: TabItem[] = [{ to: base, label: "Overview", end: true }];

    const resultsVisible = contest.status === "results_published" || contest.status === "archived" || canJudge;
    if (resultsVisible) {
      items.push({ to: `${base}/results`, label: "Results" });
    }
    if (isAuthenticated && !myParticipation && contest.status === "accepting_logs") {
      items.push({ to: `${base}/participate`, label: "Participate" });
    }
    if (myParticipation) {
      items.push({ to: `${base}/entry`, label: "My entry" });
    }
    if (canManage) {
      items.push({ to: `${base}/manage`, label: "Manage" });
    }
    if (canJudge) {
      items.push({ to: `${base}/judge`, label: "Judge", end: true });
      items.push({ to: `${base}/judge/conflicts`, label: "Conflicts" });
    }
    return items;
  }, [base, canJudge, canManage, contest, isAuthenticated, myParticipation]);

  if (loading) {
    return <LoadingState label="Loading contest..." />;
  }
  if (error) {
    return (
      <section className="page-section">
        <Breadcrumbs items={[{ label: "Contests", to: "/contests" }, { label: "Contest" }]} />
        <ErrorState
          error={error}
          action={
            <div className="inline-actions">
              <button className="button button-ghost" onClick={() => void reloadContest()} type="button">
                Retry
              </button>
              <Link className="button button-ghost" to="/contests">
                Back to contests
              </Link>
            </div>
          }
        />
      </section>
    );
  }
  if (!contest) {
    return (
      <section className="page-section">
        <Breadcrumbs items={[{ label: "Contests", to: "/contests" }, { label: "Contest" }]} />
        <EmptyState title="Contest not found" description="It may have been removed or is not visible to you." />
      </section>
    );
  }

  return (
    <section className="page-section">
      <Breadcrumbs items={[{ label: "Contests", to: "/contests" }, { label: contest.title }]} />

      <header className="contest-hub">
        <div className="meta-row">
          <StatusBadge value={contest.status} />
          <span className="muted">Contest #{contest.id}</span>
        </div>
        <h1>{contest.title}</h1>
        <LifecycleStepper status={contest.status} />
      </header>

      <TabNav items={tabs} />

      <ContestProvider
        value={{
          contest,
          myParticipation,
          reloadContest: async () => {
            await reloadContest();
          },
          reloadParticipation: async () => {
            await reloadParticipation();
          }
        }}
      >
        <Outlet />
      </ContestProvider>
    </section>
  );
}
