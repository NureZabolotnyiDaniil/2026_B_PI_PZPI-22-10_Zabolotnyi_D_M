import { createContext, useContext } from "react";

import type { ContestRead, ParticipantRead } from "../../shared/types/domain";

export interface ContestContextValue {
  contest: ContestRead;
  myParticipation: ParticipantRead | null;
  reloadContest: () => Promise<void>;
  reloadParticipation: () => Promise<void>;
}

const ContestContext = createContext<ContestContextValue | undefined>(undefined);

export const ContestProvider = ContestContext.Provider;

export function useContest(): ContestContextValue {
  const context = useContext(ContestContext);
  if (!context) {
    throw new Error("useContest must be used within a ContestLayout route");
  }
  return context;
}
