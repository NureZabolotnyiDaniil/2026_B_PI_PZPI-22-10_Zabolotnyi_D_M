import { useParams } from "react-router-dom";

import { radioscoreApi } from "../../shared/api/radioscore";
import { EmptyState, ErrorState, LoadingState } from "../../shared/components/State";
import { StatusBadge } from "../../shared/components/StatusBadge";
import { useAsync } from "../../shared/hooks/useAsync";

export function PersonalReportPage() {
  const { contestId } = useParams();
  const { data: report, error, loading, reload } = useAsync(
    () => radioscoreApi.getPersonalReport(contestId as string),
    [contestId]
  );

  if (loading) {
    return <LoadingState label="Loading personal report..." />;
  }
  if (error) {
    return <ErrorState error={error} action={<button className="button button-ghost" onClick={reload}>Retry</button>} />;
  }
  if (!report) {
    return <EmptyState title="Report not found" />;
  }

  return (
    <div className="page-section">
      <div className="card">
        <span className="badge badge-info">Personal report</span>
        <h2>{report.participant.callsign}</h2>
        <p className="muted">Private scoring explanation for your contest participation.</p>
      </div>

      <div className="grid three">
        <article className="card">
          <h2>Participant</h2>
          <p><strong>Category:</strong> {report.participant.category}</p>
          <p><strong>Status:</strong> <StatusBadge value={report.participant.status} /></p>
        </article>
        <article className="card">
          <h2>Final score</h2>
          <p className="muted">Published after scoring and decisions.</p>
          <strong>{report.scoring?.final_score ?? "Not finalized"}</strong>
        </article>
        <article className="card">
          <h2>Claimed score</h2>
          <p><strong>From file:</strong> {report.scoring?.claimed_score_from_file ?? "N/A"}</p>
          <p><strong>System:</strong> {report.scoring?.system_claimed_score ?? "N/A"}</p>
        </article>
      </div>

      <article className="card table-wrap">
        <h2>Removed or changed QSO</h2>
        {report.removed_or_changed_qso.length === 0 ? (
          <EmptyState title="No changes recorded" description="Conflicts and judge decisions will appear here." />
        ) : (
          <table>
            <thead>
              <tr>
                <th>QSO</th>
                <th>Type</th>
                <th>Status</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
              {report.removed_or_changed_qso.map((item, index) => (
                <tr key={`${item.qso_id}-${index}`}>
                  <td>{String(item.qso_id ?? "N/A")}</td>
                  <td>{String(item.type ?? "unknown").replaceAll("_", " ")}</td>
                  <td><StatusBadge value={String(item.status ?? "unknown")} /></td>
                  <td><code>{JSON.stringify(item.details ?? {})}</code></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </article>
    </div>
  );
}
