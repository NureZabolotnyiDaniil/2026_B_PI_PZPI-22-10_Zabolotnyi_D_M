import { useMemo } from "react";
import { Link } from "react-router-dom";

import { radioscoreApi } from "../../shared/api/radioscore";
import { EmptyState, ErrorState, LoadingState } from "../../shared/components/State";
import { StatusBadge } from "../../shared/components/StatusBadge";
import { useAsync } from "../../shared/hooks/useAsync";

export function ParticipantContestsPage() {
  const { data: participations, error, loading, reload } = useAsync(radioscoreApi.listMyParticipations, []);
  const { data: contests } = useAsync(radioscoreApi.listPublicContests, []);

  const contestById = useMemo(() => {
    const map = new Map<number, { title: string; acceptingLogs: boolean }>();
    contests?.forEach((contest) =>
      map.set(contest.id, { title: contest.title, acceptingLogs: contest.status === "accepting_logs" })
    );
    return map;
  }, [contests]);

  return (
    <section className="page-section">
      <div className="hero">
        <h1>My contests</h1>
        <p className="muted">Track contest registrations, current submission links and participant status.</p>
        <Link className="button button-primary" to="/contests">
          Find contests
        </Link>
      </div>

      {loading ? <LoadingState label="Loading participations..." /> : null}
      {error ? <ErrorState error={error} action={<button className="button button-ghost" onClick={reload}>Retry</button>} /> : null}
      {!loading && !error && participations?.length === 0 ? (
        <EmptyState title="No participations" description="Open a contest and register your callsign to start." />
      ) : null}

      {participations?.length ? (
        <div className="card table-wrap">
          <table>
            <thead>
              <tr>
                <th>Contest</th>
                <th>Callsign</th>
                <th>Category</th>
                <th>Status</th>
                <th>Submission</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {participations.map((participation) => (
                <tr key={participation.id}>
                  <td>
                    <Link to={`/contests/${participation.contest_id}`}>
                      {contestById.get(participation.contest_id)?.title ?? `Contest #${participation.contest_id}`}
                    </Link>
                  </td>
                  <td>{participation.callsign}</td>
                  <td>{participation.category}</td>
                  <td><StatusBadge value={participation.status} /></td>
                  <td>
                    {participation.current_submission_id ? (
                      <Link to={`/submissions/${participation.current_submission_id}`}>
                        Submission #{participation.current_submission_id}
                      </Link>
                    ) : (
                      <span className="muted">No submission</span>
                    )}
                  </td>
                  <td>
                    <div className="inline-actions">
                      {contestById.get(participation.contest_id)?.acceptingLogs ? (
                        <Link className="button button-secondary" to={`/contests/${participation.contest_id}/upload`}>
                          Upload log
                        </Link>
                      ) : null}
                      <Link className="button button-ghost" to={`/contests/${participation.contest_id}/personal-report`}>
                        Personal report
                      </Link>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
    </section>
  );
}
