import { Link } from "react-router-dom";

import { EmptyState } from "../../shared/components/State";
import { StatusBadge } from "../../shared/components/StatusBadge";
import { useContest } from "../contest/contestContext";

export function ParticipantEntryPage() {
  const { contest, myParticipation } = useContest();
  const base = `/contests/${contest.id}`;

  if (!myParticipation) {
    return (
      <EmptyState
        title="You are not registered yet"
        description="Open the Participate tab to register your callsign for this contest."
      />
    );
  }

  const acceptingLogs = contest.status === "accepting_logs";

  return (
    <div className="page-section">
      <div className="grid two">
        <article className="card">
          <h2>My registration</h2>
          <dl className="detail-list">
            <div>
              <dt>Callsign</dt>
              <dd>{myParticipation.callsign}</dd>
            </div>
            <div>
              <dt>Category</dt>
              <dd>{myParticipation.category}</dd>
            </div>
            <div>
              <dt>Power</dt>
              <dd>{myParticipation.power ?? "—"}</dd>
            </div>
            <div>
              <dt>Region</dt>
              <dd>{myParticipation.country_or_region ?? "—"}</dd>
            </div>
            <div>
              <dt>Status</dt>
              <dd>
                <StatusBadge value={myParticipation.status} />
              </dd>
            </div>
          </dl>
        </article>

        <aside className="card">
          <h2>Log submission</h2>
          {acceptingLogs ? (
            <p className="muted">Submission window is open. Upload or replace your Cabrillo log.</p>
          ) : (
            <p className="muted">The submission window is currently closed for new uploads.</p>
          )}
          <div className="stacked-actions">
            {acceptingLogs ? (
              <Link className="button button-primary" to={`${base}/upload`}>
                Upload Cabrillo log
              </Link>
            ) : null}
            {myParticipation.current_submission_id ? (
              <Link className="button button-secondary" to={`/submissions/${myParticipation.current_submission_id}`}>
                View current submission
              </Link>
            ) : (
              <span className="muted">No submission uploaded yet.</span>
            )}
            <Link className="button button-ghost" to={`${base}/personal-report`}>
              Personal report
            </Link>
          </div>
        </aside>
      </div>
    </div>
  );
}
