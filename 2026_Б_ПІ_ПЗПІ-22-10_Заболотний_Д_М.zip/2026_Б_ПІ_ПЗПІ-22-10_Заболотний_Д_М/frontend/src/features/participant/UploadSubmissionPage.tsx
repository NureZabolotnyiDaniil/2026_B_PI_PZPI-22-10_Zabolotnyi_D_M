import { FormEvent, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import { radioscoreApi } from "../../shared/api/radioscore";
import { Field, FormActions } from "../../shared/components/Form";
import { EmptyState, ErrorState } from "../../shared/components/State";
import type { FormStatus } from "../../shared/types/forms";
import { useContest } from "../contest/contestContext";

const MAX_UPLOAD_BYTES = 1_048_576;

export function UploadSubmissionPage() {
  const { contest, reloadParticipation } = useContest();
  const navigate = useNavigate();
  const base = `/contests/${contest.id}`;
  const acceptingLogs = contest.status === "accepting_logs";
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<FormStatus>({ submitting: false, error: null, success: null });

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!file) {
      setStatus({ submitting: false, error: "Choose a Cabrillo file first.", success: null });
      return;
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      setStatus({ submitting: false, error: "File is larger than the 1 MB backend upload limit.", success: null });
      return;
    }

    setStatus({ submitting: true, error: null, success: null });
    try {
      const { submission, job } = await radioscoreApi.uploadSubmission(contest.id, file);
      await reloadParticipation();
      navigate(`/submissions/${submission.id}?job=${job.id}`);
    } catch (caught) {
      setStatus({
        submitting: false,
        error: caught instanceof Error ? caught.message : "Unable to upload submission",
        success: null
      });
    }
  }

  if (!acceptingLogs) {
    return (
      <div className="page-section narrow">
        <div className="card">
          <h2>Upload contest log</h2>
          <EmptyState
            title="Log submission is closed"
            description="This contest is no longer accepting new or updated log files."
          />
          <FormActions>
            <Link className="button button-ghost" to={`${base}/entry`}>
              Back to my entry
            </Link>
          </FormActions>
        </div>
      </div>
    );
  }

  return (
    <div className="page-section narrow">
      <div className="card">
        <h2>Upload contest log</h2>
        <p className="muted">
          Upload a text Cabrillo file. Parsing and validation continue in the background after upload.
        </p>
        <form onSubmit={handleSubmit}>
          {status.error ? <ErrorState error={status.error} /> : null}
          <Field label="Cabrillo file" hint="Text-based Cabrillo log, up to 1 MB.">
            <input
              accept=".log,.txt,text/plain"
              required
              type="file"
              onChange={(event) => setFile(event.target.files?.[0] ?? null)}
            />
          </Field>
          {file ? (
            <div className="state state-muted">
              <strong>{file.name}</strong>
              <span>{Math.ceil(file.size / 1024)} KB selected</span>
            </div>
          ) : null}
          <FormActions>
            <button className="button button-primary" disabled={status.submitting} type="submit">
              {status.submitting ? "Uploading..." : "Upload log"}
            </button>
            <Link to={`${base}/entry`}>Back to my entry</Link>
          </FormActions>
        </form>
      </div>
    </div>
  );
}
