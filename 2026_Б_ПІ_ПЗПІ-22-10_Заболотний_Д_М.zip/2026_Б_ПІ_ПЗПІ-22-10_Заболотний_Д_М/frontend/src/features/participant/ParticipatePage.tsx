import { FormEvent, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import { radioscoreApi } from "../../shared/api/radioscore";
import { Field, FormActions } from "../../shared/components/Form";
import { ErrorState } from "../../shared/components/State";
import type { FormStatus } from "../../shared/types/forms";
import { useContest } from "../contest/contestContext";

export function ParticipatePage() {
  const { contest, reloadParticipation } = useContest();
  const navigate = useNavigate();
  const base = `/contests/${contest.id}`;
  const [form, setForm] = useState({ callsign: "", category: "", power: "", country_or_region: "" });
  const [status, setStatus] = useState<FormStatus>({ submitting: false, error: null, success: null });

  function updateField(field: keyof typeof form, value: string) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setStatus({ submitting: true, error: null, success: null });
    try {
      await radioscoreApi.registerParticipation(contest.id, {
        callsign: form.callsign,
        category: form.category || contest.categories[0] || "",
        power: form.power || null,
        country_or_region: form.country_or_region || null
      });
      await reloadParticipation();
      navigate(`${base}/upload`);
    } catch (caught) {
      setStatus({
        submitting: false,
        error: caught instanceof Error ? caught.message : "Unable to register participation",
        success: null
      });
    }
  }

  return (
    <div className="page-section narrow">
      <div className="card">
        <h2>Register your participation</h2>
        <p className="muted">Register your callsign and contest category before uploading a Cabrillo log.</p>
        <form onSubmit={handleSubmit}>
          {status.error ? <ErrorState error={status.error} /> : null}
          <Field label="Callsign" hint="Letters, numbers and slash. It will be stored uppercase.">
            <input
              maxLength={32}
              minLength={2}
              required
              value={form.callsign}
              onChange={(event) => updateField("callsign", event.target.value.toUpperCase())}
            />
          </Field>
          <Field label="Category">
            <select
              required
              value={form.category || contest.categories[0] || ""}
              onChange={(event) => updateField("category", event.target.value)}
            >
              {contest.categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Power">
            <input value={form.power} onChange={(event) => updateField("power", event.target.value)} />
          </Field>
          <Field label="Country or region">
            <input
              value={form.country_or_region}
              onChange={(event) => updateField("country_or_region", event.target.value)}
            />
          </Field>
          <FormActions>
            <button className="button button-primary" disabled={status.submitting} type="submit">
              {status.submitting ? "Registering..." : "Register participation"}
            </button>
            <Link to={base}>Back to overview</Link>
          </FormActions>
        </form>
      </div>
    </div>
  );
}
