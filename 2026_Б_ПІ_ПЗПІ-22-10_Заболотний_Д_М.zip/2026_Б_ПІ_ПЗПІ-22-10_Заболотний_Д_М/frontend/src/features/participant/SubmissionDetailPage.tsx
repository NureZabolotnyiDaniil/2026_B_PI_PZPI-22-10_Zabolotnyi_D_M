import { useEffect, useRef } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";

import { radioscoreApi } from "../../shared/api/radioscore";
import { Breadcrumbs } from "../../shared/components/Breadcrumbs";
import { EmptyState, ErrorState, LoadingState } from "../../shared/components/State";
import { StatusBadge } from "../../shared/components/StatusBadge";
import { useAsync } from "../../shared/hooks/useAsync";
import { useProcessingJob } from "../../shared/hooks/useProcessingJob";
import { formatDateTime } from "../../shared/utils/format";

export function SubmissionDetailPage() {
  const { submissionId } = useParams();
  const [searchParams] = useSearchParams();
  const jobId = searchParams.get("job");
  const completedJobRef = useRef<string | null>(null);
  const { data: submission, error, loading, reload } = useAsync(
    () => radioscoreApi.getSubmission(submissionId as string),
    [submissionId]
  );
  const { data: contest } = useAsync(
    () => (submission ? radioscoreApi.getPublicContest(submission.contest_id) : Promise.resolve(null)),
    [submission?.contest_id]
  );
  const { job, error: jobError, polling } = useProcessingJob(jobId);

  useEffect(() => {
    if (
      jobId &&
      job &&
      ["succeeded", "failed", "cancelled"].includes(job.status) &&
      completedJobRef.current !== jobId
    ) {
      completedJobRef.current = jobId;
      void reload();
    }
  }, [job, jobId, reload]);

  if (loading) {
    return <LoadingState label="Loading submission..." />;
  }
  if (error) {
    return <ErrorState error={error} action={<button className="button button-ghost" onClick={reload}>Retry</button>} />;
  }
  if (!submission) {
    return <EmptyState title="Submission not found" />;
  }

  const blockingIssues = submission.issues.filter((issue) => issue.severity === "blocking");
  const warningIssues = submission.issues.filter((issue) => issue.severity === "warning");

  return (
    <section className="page-section">
      <Breadcrumbs
        items={[
          { label: "Contests", to: "/contests" },
          { label: `Contest #${submission.contest_id}`, to: `/contests/${submission.contest_id}` },
          { label: `Submission #${submission.id}` }
        ]}
      />
      <div className="hero">
        <div className="meta-row">
          <StatusBadge value={submission.status} />
          <span className="muted">Version {submission.version}</span>
        </div>
        <h1>Submission #{submission.id}</h1>
        <p className="muted">Uploaded {formatDateTime(submission.uploaded_at_utc)}</p>
        <div className="inline-actions">
          {contest?.status === "accepting_logs" ? (
            <Link className="button button-secondary" to={`/contests/${submission.contest_id}/upload`}>
              Upload correction
            </Link>
          ) : null}
          <Link className="button button-ghost" to={`/contests/${submission.contest_id}/personal-report`}>
            Personal report
          </Link>
        </div>
      </div>

      {jobId ? (
        <article className="card">
          <div className="meta-row">
            <h2>Background processing</h2>
            <StatusBadge value={job?.status ?? "queued"} />
          </div>
          {polling ? <p className="muted">Parsing and validating the uploaded log…</p> : null}
          {job?.error_message ? <ErrorState error={job.error_message} /> : null}
          {jobError ? <ErrorState error={jobError} /> : null}
        </article>
      ) : null}

      <div className="grid two">
        <IssueCard title="Blocking issues" issues={blockingIssues} />
        <IssueCard title="Warnings" issues={warningIssues} />
      </div>

      <article className="card">
        <h2>Parsed metadata</h2>
        <pre className="code-block">{JSON.stringify(submission.parsed_metadata, null, 2)}</pre>
      </article>

      <article className="card table-wrap">
        <h2>QSO records</h2>
        {submission.qso_records.length === 0 ? (
          <EmptyState title="No parsed QSO records" description="Records appear after parsing succeeds." />
        ) : (
          <table>
            <thead>
              <tr>
                <th>Line</th>
                <th>Time</th>
                <th>Band</th>
                <th>Mode</th>
                <th>Participant</th>
                <th>Counterparty</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {submission.qso_records.map((qso) => (
                <tr key={qso.id}>
                  <td>{qso.line_number}</td>
                  <td>{formatDateTime(qso.qso_at_utc)}</td>
                  <td>{qso.band}</td>
                  <td>{qso.mode}</td>
                  <td>{qso.participant_callsign}</td>
                  <td>{qso.counterparty_callsign}</td>
                  <td><StatusBadge value={qso.check_status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </article>
    </section>
  );
}

function IssueCard({ title, issues }: { title: string; issues: Array<{ id: number; message: string; type: string; line_number: number | null; severity: string }> }) {
  return (
    <article className="card">
      <h2>{title}</h2>
      {issues.length === 0 ? (
        <EmptyState title="None" />
      ) : (
        <div className="grid">
          {issues.map((issue) => (
            <div className="state" key={issue.id}>
              <div className="meta-row">
                <StatusBadge value={issue.severity} />
                <strong>{issue.type.replaceAll("_", " ")}</strong>
              </div>
              <span>{issue.message}</span>
              {issue.line_number ? <small className="muted">Line {issue.line_number}</small> : null}
            </div>
          ))}
        </div>
      )}
    </article>
  );
}
