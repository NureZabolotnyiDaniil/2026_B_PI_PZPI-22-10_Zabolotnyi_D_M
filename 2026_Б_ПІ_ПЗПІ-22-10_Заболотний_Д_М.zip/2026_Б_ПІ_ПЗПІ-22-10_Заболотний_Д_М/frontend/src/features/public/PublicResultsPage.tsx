import { useParams } from "react-router-dom";

import { radioscoreApi } from "../../shared/api/radioscore";
import { EmptyState, ErrorState, LoadingState } from "../../shared/components/State";
import { useAsync } from "../../shared/hooks/useAsync";

export function PublicResultsPage() {
  const { contestId } = useParams();
  const { data: results, error, loading, reload } = useAsync(
    () => radioscoreApi.getPublicResults(contestId as string),
    [contestId]
  );

  return (
    <div className="page-section">
      {loading ? <LoadingState label="Loading results..." /> : null}
      {error ? (
        <ErrorState error={error} action={<button className="button button-ghost" onClick={reload}>Retry</button>} />
      ) : null}
      {!loading && !error && results?.length === 0 ? (
        <EmptyState title="No published results" description="Results appear after the organizer publishes them." />
      ) : null}

      {results?.length ? (
        <div className="card table-wrap">
          <table className="results-table">
            <thead>
              <tr>
                <th className="col-rank">#</th>
                <th>Callsign</th>
                <th>Category</th>
                <th className="col-final">Final score</th>
                <th className="col-num">Confirmed QSO</th>
                <th className="col-num">Claimed</th>
                <th className="col-num">Removed QSO</th>
              </tr>
            </thead>
            <tbody>
              {results.map((result) => (
                <tr key={result.id} className={result.rank_in_category === 1 ? "is-winner" : undefined}>
                  <td className="col-rank">
                    {result.rank_in_category === 1 ? (
                      <span className="rank-badge first">1</span>
                    ) : (
                      result.rank_in_category
                    )}
                  </td>
                  <td>
                    <strong>{result.callsign}</strong>
                  </td>
                  <td>{result.category}</td>
                  <td className="col-final">{result.final_score}</td>
                  <td className="col-num">{result.confirmed_qso_count}</td>
                  <td className="col-num">{result.claimed_score}</td>
                  <td className="col-num">{result.removed_qso_count}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
    </div>
  );
}
