import { ContestCard } from "../../shared/components/ContestCard";
import { EmptyState, ErrorState, LoadingState } from "../../shared/components/State";
import { radioscoreApi } from "../../shared/api/radioscore";
import { useAsync } from "../../shared/hooks/useAsync";

export function ContestListPage() {
  const { data: contests, error, loading, reload } = useAsync(radioscoreApi.listPublicContests, []);

  return (
    <section className="page-section">
      <div className="hero">
        <span className="badge badge-info">Radio contest platform</span>
        <h1>Published contests</h1>
        <p className="muted">
          Browse contests, check log submission windows and open published results when they are available.
        </p>
      </div>

      {loading ? <LoadingState label="Loading contests..." /> : null}
      {error ? <ErrorState error={error} action={<button className="button button-ghost" onClick={reload}>Retry</button>} /> : null}
      {!loading && !error && contests?.length === 0 ? (
        <EmptyState title="No contests yet" description="Published contests will appear here." />
      ) : null}
      <div className="grid two">
        {contests?.map((contest) => (
          <ContestCard contest={contest} key={contest.id} />
        ))}
      </div>
    </section>
  );
}
