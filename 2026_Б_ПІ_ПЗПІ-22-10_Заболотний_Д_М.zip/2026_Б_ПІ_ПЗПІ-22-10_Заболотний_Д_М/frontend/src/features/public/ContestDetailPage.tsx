import { Link } from "react-router-dom";

import { useAuth } from "../../shared/auth/AuthContext";
import { formatDateTime, joinList } from "../../shared/utils/format";
import { useContest } from "../contest/contestContext";

export function ContestDetailPage() {
  const { contest, myParticipation } = useContest();
  const { isAuthenticated } = useAuth();
  const acceptingLogs = contest.status === "accepting_logs";

  // The only call-to-action worth surfacing here is the one that is NOT already a
  // tab: prompting an anonymous visitor to log in so they can participate.
  const showLoginCta = acceptingLogs && !isAuthenticated && !myParticipation;

  return (
    <div className="page-section">
      {showLoginCta ? (
        <div className="cta-banner">
          <div>
            <strong>Log submission is open.</strong>
            <p className="muted">Log in to register your callsign and take part.</p>
          </div>
          <Link className="button button-primary" to="/login">
            Log in to participate
          </Link>
        </div>
      ) : null}

      <p className="contest-intro">{contest.description}</p>

      <div className="split">
        <article className="card">
          <h2>Rules</h2>
          <p className="prewrap">{contest.rules_text}</p>
        </article>
        <aside className="card">
          <h2>Contest setup</h2>
          <dl className="detail-list">
            <div>
              <dt>Start</dt>
              <dd>{formatDateTime(contest.start_at_utc)}</dd>
            </div>
            <div>
              <dt>End</dt>
              <dd>{formatDateTime(contest.end_at_utc)}</dd>
            </div>
            <div>
              <dt>Logs open</dt>
              <dd>{formatDateTime(contest.log_submission_open_at_utc)}</dd>
            </div>
            <div>
              <dt>Logs deadline</dt>
              <dd>{formatDateTime(contest.log_submission_deadline_at_utc)}</dd>
            </div>
            <div>
              <dt>Categories</dt>
              <dd>{joinList(contest.categories)}</dd>
            </div>
            <div>
              <dt>Bands</dt>
              <dd>{joinList(contest.allowed_bands)}</dd>
            </div>
            <div>
              <dt>Modes</dt>
              <dd>{joinList(contest.allowed_modes)}</dd>
            </div>
          </dl>
        </aside>
      </div>
    </div>
  );
}
