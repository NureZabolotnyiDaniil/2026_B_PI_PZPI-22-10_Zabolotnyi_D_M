import { Navigate, Route, Routes } from "react-router-dom";

import { AdminUsersPage } from "../features/admin/AdminUsersPage";
import { ContestLayout } from "../features/contest/ContestLayout";
import { LoginPage } from "../features/auth/LoginPage";
import { RegisterPage } from "../features/auth/RegisterPage";
import { ConflictQueuePage } from "../features/judge/ConflictQueuePage";
import { ConflictReviewPage } from "../features/judge/ConflictReviewPage";
import { JudgeContestDashboardPage } from "../features/judge/JudgeContestDashboardPage";
import { JudgeLandingPage } from "../features/judge/JudgeLandingPage";
import { OrganizerContestFormPage } from "../features/organizer/OrganizerContestFormPage";
import { OrganizerContestPage } from "../features/organizer/OrganizerContestPage";
import { OrganizerDashboardPage } from "../features/organizer/OrganizerDashboardPage";
import { ParticipantContestsPage } from "../features/participant/ParticipantContestsPage";
import { ParticipantEntryPage } from "../features/participant/ParticipantEntryPage";
import { ParticipatePage } from "../features/participant/ParticipatePage";
import { PersonalReportPage } from "../features/participant/PersonalReportPage";
import { SubmissionDetailPage } from "../features/participant/SubmissionDetailPage";
import { UploadSubmissionPage } from "../features/participant/UploadSubmissionPage";
import { ContestDetailPage } from "../features/public/ContestDetailPage";
import { ContestListPage } from "../features/public/ContestListPage";
import { PublicResultsPage } from "../features/public/PublicResultsPage";
import { ProfilePage } from "../features/profile/ProfilePage";
import { AppLayout } from "../shared/components/Layout";
import { NotFoundPage } from "../shared/components/NotFoundPage";
import { ProtectedRoute } from "../shared/components/ProtectedRoute";

export function AppRouter() {
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route index element={<Navigate to="/contests" replace />} />
        <Route path="/contests" element={<ContestListPage />} />

        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />

        <Route element={<ProtectedRoute />}>
          <Route path="/me" element={<ProfilePage />} />
          <Route path="/me/contests" element={<ParticipantContestsPage />} />
          <Route path="/submissions/:submissionId" element={<SubmissionDetailPage />} />
        </Route>

        <Route element={<ProtectedRoute roles={["organizer", "admin"]} />}>
          <Route path="/organizer/contests" element={<OrganizerDashboardPage />} />
          <Route path="/organizer/contests/new" element={<OrganizerContestFormPage />} />
        </Route>

        <Route element={<ProtectedRoute roles={["judge", "organizer", "admin"]} />}>
          <Route path="/judge" element={<JudgeLandingPage />} />
          <Route path="/judge/conflicts/:conflictId" element={<ConflictReviewPage />} />
        </Route>

        <Route element={<ProtectedRoute roles={["admin"]} />}>
          <Route path="/admin/users" element={<AdminUsersPage />} />
        </Route>

        {/* Contest hub: every contest-scoped view lives under one shared layout. */}
        <Route path="/contests/:contestId" element={<ContestLayout />}>
          <Route index element={<ContestDetailPage />} />
          <Route path="results" element={<PublicResultsPage />} />

          <Route element={<ProtectedRoute />}>
            <Route path="participate" element={<ParticipatePage />} />
            <Route path="entry" element={<ParticipantEntryPage />} />
            <Route path="upload" element={<UploadSubmissionPage />} />
            <Route path="personal-report" element={<PersonalReportPage />} />
          </Route>

          <Route element={<ProtectedRoute roles={["organizer", "admin"]} />}>
            <Route path="manage" element={<OrganizerContestPage />} />
            <Route path="manage/edit" element={<OrganizerContestFormPage />} />
          </Route>

          <Route element={<ProtectedRoute roles={["judge", "organizer", "admin"]} />}>
            <Route path="judge" element={<JudgeContestDashboardPage />} />
            <Route path="judge/conflicts" element={<ConflictQueuePage />} />
          </Route>
        </Route>

        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}
