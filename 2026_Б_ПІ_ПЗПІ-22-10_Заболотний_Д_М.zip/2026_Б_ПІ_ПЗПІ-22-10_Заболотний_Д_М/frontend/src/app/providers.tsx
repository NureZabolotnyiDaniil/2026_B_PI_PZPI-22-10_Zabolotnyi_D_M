import { BrowserRouter } from "react-router-dom";
import type { ReactNode } from "react";

import { AuthProvider } from "../shared/auth/AuthContext";

export function AppProviders({ children }: { children: ReactNode }) {
  return (
    <BrowserRouter>
      <AuthProvider>{children}</AuthProvider>
    </BrowserRouter>
  );
}
