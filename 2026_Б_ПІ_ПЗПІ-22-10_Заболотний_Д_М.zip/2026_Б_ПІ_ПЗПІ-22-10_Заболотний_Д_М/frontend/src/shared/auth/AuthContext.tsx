import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";

import { onUnauthorized, setApiToken } from "../api/client";
import { radioscoreApi } from "../api/radioscore";
import type { UserRead, UserRole } from "../types/domain";

const TOKEN_KEY = "radioscore.accessToken";

interface AuthContextValue {
  user: UserRead | null;
  token: string | null;
  loading: boolean;
  isAuthenticated: boolean;
  hasRole: (roles: UserRole[]) => boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (payload: { email: string; password: string; display_name?: string; callsign?: string }) => Promise<void>;
  updateProfile: (payload: { display_name?: string | null; callsign?: string | null }) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem(TOKEN_KEY));
  const [user, setUser] = useState<UserRead | null>(null);
  const [loading, setLoading] = useState(true);

  const clearSession = useCallback(() => {
    localStorage.removeItem(TOKEN_KEY);
    setToken(null);
    setUser(null);
    setApiToken(null);
  }, []);

  useEffect(() => {
    setApiToken(token);
    onUnauthorized(clearSession);

    let active = true;
    async function loadMe() {
      if (!token) {
        setLoading(false);
        return;
      }
      try {
        const profile = await radioscoreApi.me();
        if (active) {
          setUser(profile);
        }
      } catch {
        if (active) {
          clearSession();
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    }

    loadMe();
    return () => {
      active = false;
      onUnauthorized(null);
    };
  }, [clearSession, token]);

  const login = useCallback(async (email: string, password: string) => {
    const response = await radioscoreApi.login({ email, password });
    localStorage.setItem(TOKEN_KEY, response.access_token);
    setApiToken(response.access_token);
    setToken(response.access_token);
    setUser(await radioscoreApi.me());
  }, []);

  const register = useCallback<AuthContextValue["register"]>(async (payload) => {
    await radioscoreApi.register(payload);
    await login(payload.email, payload.password);
  }, [login]);

  const updateProfile = useCallback(async (payload: { display_name?: string | null; callsign?: string | null }) => {
    setUser(await radioscoreApi.updateProfile(payload));
  }, []);

  const logout = useCallback(async () => {
    try {
      if (token) {
        await radioscoreApi.logout();
      }
    } finally {
      clearSession();
    }
  }, [clearSession, token]);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      token,
      loading,
      isAuthenticated: Boolean(user && token),
      hasRole: (roles) => Boolean(user?.global_roles.some((role) => roles.includes(role))),
      login,
      register,
      updateProfile,
      logout
    }),
    [loading, login, logout, register, token, updateProfile, user]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return context;
}
