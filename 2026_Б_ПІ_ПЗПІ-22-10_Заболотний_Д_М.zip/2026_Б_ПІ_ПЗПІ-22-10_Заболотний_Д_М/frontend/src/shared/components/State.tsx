import type { ReactNode } from "react";

export function LoadingState({ label = "Loading..." }: { label?: string }) {
  return <div className="state state-muted">{label}</div>;
}

export function ErrorState({ error, action }: { error: Error | string; action?: ReactNode }) {
  return (
    <div className="state state-error" role="alert">
      <strong>Something went wrong.</strong>
      <span>{typeof error === "string" ? error : error.message}</span>
      {action}
    </div>
  );
}

export function EmptyState({ title, description }: { title: string; description?: string }) {
  return (
    <div className="state state-muted">
      <strong>{title}</strong>
      {description ? <span>{description}</span> : null}
    </div>
  );
}
