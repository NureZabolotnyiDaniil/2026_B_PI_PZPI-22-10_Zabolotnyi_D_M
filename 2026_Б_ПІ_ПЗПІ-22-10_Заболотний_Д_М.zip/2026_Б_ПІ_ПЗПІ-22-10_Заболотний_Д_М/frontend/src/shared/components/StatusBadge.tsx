type Tone = "neutral" | "success" | "warning" | "danger" | "info";

const toneByStatus: Record<string, Tone> = {
  active: "success",
  blocked: "danger",
  published: "info",
  accepting_logs: "success",
  log_submission_closed: "warning",
  checking: "warning",
  judge_review: "warning",
  finalized: "info",
  results_published: "success",
  archived: "neutral",
  uploaded: "info",
  parsing_queued: "info",
  parsing: "warning",
  validation_failed: "danger",
  accepted: "success",
  checked: "success",
  superseded: "neutral",
  blocking: "danger",
  warning: "warning",
  queued: "neutral",
  running: "warning",
  succeeded: "success",
  failed: "danger",
  cancelled: "neutral",
  ambiguous: "warning",
  no_match: "danger"
};

export function StatusBadge({ value }: { value: string }) {
  const tone = toneByStatus[value] ?? "neutral";
  return <span className={`badge badge-${tone}`}>{value.replaceAll("_", " ")}</span>;
}
