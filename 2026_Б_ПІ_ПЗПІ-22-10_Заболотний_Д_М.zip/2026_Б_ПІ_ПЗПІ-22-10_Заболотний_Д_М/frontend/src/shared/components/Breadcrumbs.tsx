import { Fragment } from "react";
import { Link } from "react-router-dom";

export interface Crumb {
  label: string;
  to?: string;
}

export function Breadcrumbs({ items }: { items: Crumb[] }) {
  return (
    <nav className="breadcrumbs" aria-label="Breadcrumb">
      {items.map((crumb, index) => {
        const isLast = index === items.length - 1;
        return (
          <Fragment key={`${crumb.label}-${index}`}>
            {crumb.to && !isLast ? (
              <Link className="crumb-link" to={crumb.to}>
                {crumb.label}
              </Link>
            ) : (
              <span className="crumb-current" aria-current={isLast ? "page" : undefined}>
                {crumb.label}
              </span>
            )}
            {!isLast ? <span className="crumb-sep" aria-hidden="true">/</span> : null}
          </Fragment>
        );
      })}
    </nav>
  );
}
