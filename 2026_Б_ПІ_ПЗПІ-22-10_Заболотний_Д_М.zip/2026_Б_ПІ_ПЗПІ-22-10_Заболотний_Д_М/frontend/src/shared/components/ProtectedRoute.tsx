import { Link, Navigate, Outlet, useLocation } from "react-router-dom";

import { useAuth } from "../auth/AuthContext";
import type { UserRole } from "../types/domain";
import { LoadingState } from "./State";

export function ProtectedRoute({ roles }: { roles?: UserRole[] }) {
  const { loading, isAuthenticated, hasRole } = useAuth();
  const location = useLocation();

  if (loading) {
    return <LoadingState label="Checking session..." />;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  if (roles && !hasRole(roles)) {
    return (
      <section className="page-section narrow">
        <div className="state state-error" role="alert">
          <strong>Access denied.</strong>
          <span>Your account does not have permission to open this area.</span>
        </div>
        <div className="inline-actions">
          <Link className="button button-primary" to="/contests">
            Back to contests
          </Link>
          <Link className="button button-ghost" to="/me">
            View profile
          </Link>
        </div>
      </section>
    );
  }

  return <Outlet />;
}
