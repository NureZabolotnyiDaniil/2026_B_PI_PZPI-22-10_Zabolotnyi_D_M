import { Link } from "react-router-dom";

import type { ContestRead } from "../types/domain";
import { formatDateTime } from "../utils/format";
import { StatusBadge } from "./StatusBadge";

export function ContestCard({ contest }: { contest: ContestRead }) {
  return (
    <article className="card">
      <div className="meta-row">
        <StatusBadge value={contest.status} />
        <span className="muted">{formatDateTime(contest.start_at_utc)}</span>
      </div>
      <div>
        <h2>{contest.title}</h2>
        <p className="muted">{contest.description}</p>
      </div>
      <div className="meta-row">
        {contest.categories.map((category) => (
          <span className="badge badge-neutral" key={category}>
            {category}
          </span>
        ))}
      </div>
      <div className="inline-actions">
        <Link className="button button-primary" to={`/contests/${contest.id}`}>
          Details
        </Link>
        <Link className="button button-ghost" to={`/contests/${contest.id}/results`}>
          Results
        </Link>
      </div>
    </article>
  );
}
