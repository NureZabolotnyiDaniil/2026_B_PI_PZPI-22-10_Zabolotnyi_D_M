import { NavLink } from "react-router-dom";

export interface TabItem {
  to: string;
  label: string;
  /** Match the path exactly so parent tabs do not stay active on child routes. */
  end?: boolean;
}

export function TabNav({ items, label = "Section navigation" }: { items: TabItem[]; label?: string }) {
  if (items.length <= 1) {
    return null;
  }
  return (
    <nav className="subnav" aria-label={label}>
      {items.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          end={item.end}
          className={({ isActive }) => `subnav-link${isActive ? " active" : ""}`}
        >
          {item.label}
        </NavLink>
      ))}
    </nav>
  );
}
