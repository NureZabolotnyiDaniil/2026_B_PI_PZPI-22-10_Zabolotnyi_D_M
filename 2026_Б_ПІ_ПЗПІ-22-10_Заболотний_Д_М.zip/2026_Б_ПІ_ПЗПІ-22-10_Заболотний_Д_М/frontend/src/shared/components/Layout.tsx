import { useState } from "react";
import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import { useEffect } from "react";

import { useAuth } from "../auth/AuthContext";

export function AppLayout() {
  const { user, isAuthenticated, hasRole, logout } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  const navClass = `main-nav${menuOpen ? " is-open" : ""}`;

  return (
    <div className="app-shell">
      <header className="topbar">
        <Link className="brand" to="/contests">
          <span className="brand-mark">RS</span>
          <span className="brand-text">
            <strong>RadioScore</strong>
            <small>Contest management</small>
          </span>
        </Link>

        <button
          className="nav-toggle"
          type="button"
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          onClick={() => setMenuOpen((open) => !open)}
        >
          <span className="nav-toggle-bar" aria-hidden="true" />
          <span className="sr-only">Menu</span>
        </button>

        <nav className={navClass} id="primary-navigation" aria-label="Primary navigation">
          <NavLink to="/contests">Contests</NavLink>
          {isAuthenticated ? <NavLink to="/me/contests">My contests</NavLink> : null}
          {hasRole(["organizer", "admin"]) ? <NavLink to="/organizer/contests">Organizer</NavLink> : null}
          {hasRole(["admin"]) ? <NavLink to="/admin/users">Admin</NavLink> : null}

          <div className="account-nav">
            {isAuthenticated ? (
              <>
                <NavLink className="account-link" to="/me">
                  {user?.display_name || user?.email}
                </NavLink>
                <button className="button button-ghost" type="button" onClick={() => void logout()}>
                  Logout
                </button>
              </>
            ) : (
              <>
                <NavLink to="/login">Login</NavLink>
                <Link className="button button-primary" to="/register">
                  Register
                </Link>
              </>
            )}
          </div>
        </nav>
      </header>

      <main className="page-frame">
        <Outlet />
      </main>
    </div>
  );
}
