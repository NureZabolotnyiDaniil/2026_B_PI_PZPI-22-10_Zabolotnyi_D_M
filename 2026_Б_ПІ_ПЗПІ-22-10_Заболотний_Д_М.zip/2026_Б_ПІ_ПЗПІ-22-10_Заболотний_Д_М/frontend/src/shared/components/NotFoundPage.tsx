import { Link } from "react-router-dom";

export function NotFoundPage() {
  return (
    <section className="page-section narrow">
      <div className="hero">
        <span className="badge badge-warning">404</span>
        <h1>Page not found</h1>
        <p className="muted">The page you are looking for does not exist or may have moved.</p>
        <div className="inline-actions">
          <Link className="button button-primary" to="/contests">
            Back to contests
          </Link>
        </div>
      </div>
    </section>
  );
}
