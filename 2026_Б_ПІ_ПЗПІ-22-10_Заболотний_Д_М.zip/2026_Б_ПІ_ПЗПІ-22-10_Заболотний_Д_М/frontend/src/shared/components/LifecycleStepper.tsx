import type { ContestStatus } from "../types/domain";

const LIFECYCLE: ContestStatus[] = [
  "draft",
  "published",
  "accepting_logs",
  "log_submission_closed",
  "checking",
  "judge_review",
  "finalized",
  "results_published"
];

const STEP_LABELS: Record<string, string> = {
  draft: "Draft",
  published: "Published",
  accepting_logs: "Logs open",
  log_submission_closed: "Logs closed",
  checking: "Checking",
  judge_review: "Judge review",
  finalized: "Finalized",
  results_published: "Results"
};

export function LifecycleStepper({ status }: { status: ContestStatus }) {
  if (status === "archived") {
    return (
      <div className="lifecycle lifecycle-archived">
        <span className="badge badge-neutral">Archived</span>
      </div>
    );
  }

  const currentIndex = LIFECYCLE.indexOf(status);

  return (
    <ol className="lifecycle" aria-label="Contest lifecycle">
      {LIFECYCLE.map((step, index) => {
        const state = index < currentIndex ? "done" : index === currentIndex ? "current" : "upcoming";
        return (
          <li className={`lifecycle-step is-${state}`} key={step}>
            <span className="lifecycle-dot" aria-hidden="true" />
            <span className="lifecycle-label">{STEP_LABELS[step]}</span>
          </li>
        );
      })}
    </ol>
  );
}
