export type FormStatus = {
  submitting: boolean;
  error: string | null;
  success: string | null;
};
