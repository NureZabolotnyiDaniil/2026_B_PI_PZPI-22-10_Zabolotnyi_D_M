export type UserRole = "participant" | "organizer" | "judge" | "admin";
export type UserStatus = "active" | "blocked";

export type ContestStatus =
  | "draft"
  | "published"
  | "accepting_logs"
  | "log_submission_closed"
  | "checking"
  | "judge_review"
  | "finalized"
  | "results_published"
  | "archived";

export type ParticipantStatus = "registered" | "submitted" | "accepted" | "checked" | "withdrawn";
export type SubmissionStatus =
  | "uploaded"
  | "parsing_queued"
  | "parsing"
  | "validation_failed"
  | "accepted"
  | "checking"
  | "checked"
  | "superseded";
export type IssueSeverity = "blocking" | "warning";
export type QsoCheckStatus =
  | "pending"
  | "confirmed"
  | "rejected"
  | "duplicate"
  | "conflict"
  | "ambiguous"
  | "no_match";
export type ProcessingJobStatus = "queued" | "running" | "succeeded" | "failed" | "cancelled";
export type ProcessingJobType =
  | "validation"
  | "parsing"
  | "scoring"
  | "cross_check"
  | "publication_preparation";
export type ConflictType =
  | "nil"
  | "ambiguous"
  | "busted_call"
  | "time_mismatch"
  | "band_mismatch"
  | "mode_mismatch"
  | "exchange_mismatch"
  | "duplicate_qso"
  | "missing_counterparty_log";
export type ConflictStatus = "open" | "auto_resolved" | "judge_resolved";
export type JudgeDecisionType =
  | "accept_match"
  | "override_match"
  | "mark_nil"
  | "mark_busted_call"
  | "ignore_conflict"
  | "recalculate";

export interface Token {
  access_token: string;
  token_type: "bearer";
}

export interface UserRead {
  id: number;
  email: string;
  display_name: string | null;
  callsign: string | null;
  global_roles: UserRole[];
  status: UserStatus;
}

export interface AuditEventRead {
  id: number;
  actor_id: number | null;
  action: string;
  target_type: string;
  target_id: number | null;
  timestamp_utc: string;
  metadata_json: Record<string, unknown>;
}

export interface ScoringRuleIn {
  qso_points: number;
  required_exchange_fields: string[];
  time_tolerance_minutes: number;
  duplicate_policy: string;
  multiplier_policy: Record<string, unknown>;
  penalty_policy: Record<string, unknown>;
}

export interface ContestJudgeRead {
  user_id: number;
  email: string;
  display_name: string | null;
  callsign: string | null;
  assigned_at_utc: string;
}

export interface JudgeContestRead {
  id: number;
  title: string;
  status: ContestStatus;
  start_at_utc: string;
  end_at_utc: string;
}

export interface ContestRead {
  id: number;
  title: string;
  description: string;
  rules_text: string;
  start_at_utc: string;
  end_at_utc: string;
  log_submission_open_at_utc: string;
  log_submission_deadline_at_utc: string;
  status: ContestStatus;
  allowed_bands: string[];
  allowed_modes: string[];
  categories: string[];
  created_by_id: number;
  scoring_rule: ScoringRuleIn | null;
}

export interface ContestCreate {
  title: string;
  description: string;
  rules_text: string;
  start_at_utc: string;
  end_at_utc: string;
  log_submission_open_at_utc: string;
  log_submission_deadline_at_utc: string;
  allowed_bands: string[];
  allowed_modes: string[];
  categories: string[];
  scoring_rule: ScoringRuleIn;
}

export type ContestUpdate = Partial<ContestCreate>;

export interface ParticipationCreate {
  callsign: string;
  category: string;
  power?: string | null;
  country_or_region?: string | null;
}

export interface ParticipantRead {
  id: number;
  user_id: number;
  contest_id: number;
  callsign: string;
  category: string;
  power: string | null;
  country_or_region: string | null;
  status: ParticipantStatus;
  current_submission_id: number | null;
}

export interface ValidationIssueRead {
  id: number;
  submission_id: number;
  qso_id: number | null;
  type: string;
  severity: IssueSeverity;
  message: string;
  line_number: number | null;
}

export interface QsoRead {
  id: number;
  participant_callsign: string;
  counterparty_callsign: string;
  qso_at_utc: string;
  band: string;
  frequency: string | null;
  mode: string;
  sent_exchange: string | null;
  received_exchange: string | null;
  raw_line: string;
  line_number: number;
  check_status: QsoCheckStatus;
  matched_qso_id: number | null;
}

export interface SubmissionRead {
  id: number;
  participant_id: number;
  contest_id: number;
  original_file_path: string;
  original_file_hash: string;
  uploaded_at_utc: string;
  version: number;
  status: SubmissionStatus;
  parsed_metadata: Record<string, unknown>;
}

export interface SubmissionDetail extends SubmissionRead {
  issues: ValidationIssueRead[];
  qso_records: QsoRead[];
}

export interface ScoringResultRead {
  id: number;
  participant_id: number;
  contest_id: number;
  claimed_score_from_file: number | null;
  system_claimed_score: number;
  final_score: number | null;
  confirmed_qso_count: number;
  rejected_qso_count: number;
  duplicate_qso_count: number;
  multiplier_count: number;
  penalty_points: number;
  calculated_at_utc: string;
}

export interface PublicResultRead {
  id: number;
  contest_id: number;
  participant_id: number;
  rank_overall: number | null;
  rank_in_category: number;
  callsign: string;
  category: string;
  claimed_score: number;
  final_score: number;
  confirmed_qso_count: number;
  removed_qso_count: number;
  published_at_utc: string;
}

export interface PersonalReport {
  participant: ParticipantRead;
  scoring: ScoringResultRead | null;
  removed_or_changed_qso: Array<Record<string, unknown>>;
}

export interface ProcessingJobRead {
  id: number;
  contest_id: number | null;
  submission_id: number | null;
  type: ProcessingJobType;
  status: ProcessingJobStatus;
  started_by_id: number | null;
  started_at_utc: string | null;
  finished_at_utc: string | null;
  summary: Record<string, unknown>;
  error_message: string | null;
}

export interface SubmissionUploadAccepted {
  submission: SubmissionDetail;
  job: ProcessingJobRead;
}

export interface ConflictRead {
  id: number;
  contest_id: number;
  qso_id: number;
  candidate_qso_id: number | null;
  type: ConflictType;
  severity: IssueSeverity;
  status: ConflictStatus;
  detected_at_utc: string;
  details: Record<string, unknown>;
}

export interface ConflictQueueItem extends ConflictRead {
  participant_callsign: string;
  counterparty_callsign: string;
  band: string;
  mode: string;
  qso_at_utc: string;
  confidence: number;
  impact: number;
  category: string | null;
  region: string | null;
}

export interface ConflictQueueRead {
  items: ConflictQueueItem[];
  total: number;
  limit: number;
  offset: number;
}

export interface ConflictNeighborRead {
  contest_id: number;
  conflict_id: number;
  index: number | null;
  prev_conflict_id: number | null;
  next_conflict_id: number | null;
  total_matching_filters: number;
}

export interface ParticipantStationSearchHit {
  callsign: string;
  category: string | null;
  region: string | null;
}

export interface JudgeDashboardRead {
  total_qso: number;
  auto_resolved_ratio: number;
  pending_conflicts: number;
  high_priority_conflicts: number;
  avg_confidence: number;
}

export interface MatchingDecisionRead {
  id: number;
  contest_id: number;
  qso_id: number;
  candidate_qso_id: number | null;
  conflict_id: number | null;
  status: string;
  confidence: number;
  stage: string;
  decided_at_utc: string;
  details: Record<string, unknown>;
}

export interface ConflictWorkbenchDetail extends ConflictRead {
  qso: QsoRead;
  candidate_qso: QsoRead | null;
  explainability: Record<string, unknown> | null;
  matching_candidates: Array<Record<string, unknown>>;
  timeline: Record<string, unknown> | null;
  prior_matching_decisions: MatchingDecisionRead[];
}

export interface JudgeDecisionCreate {
  decision: JudgeDecisionType;
  comment: string;
  score_impact: number;
  selected_candidate_qso_id?: number | null;
}

export interface JudgeDecisionRead {
  id: number;
  conflict_id: number;
  judge_id: number;
  decision: JudgeDecisionType;
  comment: string;
  score_impact: number;
  metadata_json: Record<string, unknown>;
  created_at_utc: string;
}
