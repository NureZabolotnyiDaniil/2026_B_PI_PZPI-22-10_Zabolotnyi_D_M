import { useEffect, useState } from "react";

import { radioscoreApi } from "../api/radioscore";
import type { ProcessingJobRead } from "../types/domain";

const TERMINAL_STATUSES = new Set(["succeeded", "failed", "cancelled"]);

export function useProcessingJob(
  jobId: string | number | null | undefined,
  initialJob: ProcessingJobRead | null = null,
  intervalMs = 1_000
) {
  const [job, setJob] = useState<ProcessingJobRead | null>(initialJob);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (jobId == null) {
      setJob(null);
      setError(null);
      return;
    }

    let cancelled = false;
    let timer: number | undefined;

    async function poll() {
      try {
        const next = await radioscoreApi.getProcessingJob(jobId as string | number);
        if (cancelled) return;
        setJob(next);
        setError(null);
        if (!TERMINAL_STATUSES.has(next.status)) {
          timer = window.setTimeout(poll, intervalMs);
        }
      } catch (caught) {
        if (cancelled) return;
        setError(caught instanceof Error ? caught.message : "Unable to load processing job");
        timer = window.setTimeout(poll, intervalMs);
      }
    }

    void poll();
    return () => {
      cancelled = true;
      if (timer !== undefined) window.clearTimeout(timer);
    };
  }, [intervalMs, jobId]);

  return {
    job,
    error,
    polling: Boolean(job && !TERMINAL_STATUSES.has(job.status))
  };
}
