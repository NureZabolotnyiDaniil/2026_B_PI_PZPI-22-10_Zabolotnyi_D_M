import { apiRequest } from "./client";
import type {
  AuditEventRead,
  ConflictNeighborRead,
  ConflictQueueRead,
  ConflictWorkbenchDetail,
  ContestCreate,
  ContestJudgeRead,
  ContestRead,
  ContestUpdate,
  JudgeDashboardRead,
  JudgeContestRead,
  JudgeDecisionCreate,
  JudgeDecisionRead,
  ParticipantRead,
  ParticipantStationSearchHit,
  ParticipationCreate,
  PersonalReport,
  ProcessingJobRead,
  PublicResultRead,
  SubmissionDetail,
  SubmissionRead,
  SubmissionUploadAccepted,
  Token,
  UserRead,
  UserRole,
  UserStatus,
  ValidationIssueRead
} from "../types/domain";

export const radioscoreApi = {
  register(payload: { email: string; password: string; display_name?: string; callsign?: string }) {
    return apiRequest<UserRead>("/api/auth/register", { method: "POST", body: payload });
  },
  login(payload: { email: string; password: string }) {
    return apiRequest<Token>("/api/auth/login", { method: "POST", body: payload });
  },
  logout() {
    return apiRequest<void>("/api/auth/logout", { method: "POST" });
  },
  me() {
    return apiRequest<UserRead>("/api/me");
  },
  updateProfile(payload: { display_name?: string | null; callsign?: string | null }) {
    return apiRequest<UserRead>("/api/me/profile", { method: "PATCH", body: payload });
  },
  listPublicContests() {
    return apiRequest<ContestRead[]>("/api/public/contests");
  },
  getPublicContest(contestId: string | number) {
    return apiRequest<ContestRead>(`/api/public/contests/${contestId}`);
  },
  getPublicResults(contestId: string | number) {
    return apiRequest<PublicResultRead[]>(`/api/public/contests/${contestId}/results`);
  },
  listOrganizerContests() {
    return apiRequest<ContestRead[]>("/api/organizer/contests");
  },
  getOrganizerContest(contestId: string | number) {
    return apiRequest<ContestRead>(`/api/organizer/contests/${contestId}`);
  },
  listMyParticipations() {
    return apiRequest<ParticipantRead[]>("/api/me/participations");
  },
  registerParticipation(contestId: string | number, payload: ParticipationCreate) {
    return apiRequest<ParticipantRead>(`/api/contests/${contestId}/participation`, {
      method: "POST",
      body: payload
    });
  },
  uploadSubmission(contestId: string | number, file: File) {
    const body = new FormData();
    body.append("file", file);
    return apiRequest<SubmissionUploadAccepted>(`/api/contests/${contestId}/submissions`, {
      method: "POST",
      body
    });
  },
  getSubmission(submissionId: string | number) {
    return apiRequest<SubmissionDetail>(`/api/submissions/${submissionId}`);
  },
  getSubmissionIssues(submissionId: string | number) {
    return apiRequest<ValidationIssueRead[]>(`/api/submissions/${submissionId}/issues`);
  },
  getProcessingJob(jobId: string | number) {
    return apiRequest<ProcessingJobRead>(`/api/jobs/${jobId}`);
  },
  getPersonalReport(contestId: string | number) {
    return apiRequest<PersonalReport>(`/api/contests/${contestId}/personal-report`);
  },
  createContest(payload: ContestCreate) {
    return apiRequest<ContestRead>("/api/organizer/contests", { method: "POST", body: payload });
  },
  updateContest(contestId: string | number, payload: ContestUpdate) {
    return apiRequest<ContestRead>(`/api/organizer/contests/${contestId}`, {
      method: "PATCH",
      body: payload
    });
  },
  transitionContest(contestId: string | number, action: "publish" | "open-logs" | "close-logs" | "finalize") {
    return apiRequest<ContestRead>(`/api/organizer/contests/${contestId}/${action}`, { method: "POST" });
  },
  listContestSubmissions(contestId: string | number) {
    return apiRequest<SubmissionRead[]>(`/api/organizer/contests/${contestId}/submissions`);
  },
  listContestJudges(contestId: string | number) {
    return apiRequest<ContestJudgeRead[]>(`/api/organizer/contests/${contestId}/judges`);
  },
  addContestJudge(contestId: string | number, payload: { email: string } | { user_id: number }) {
    return apiRequest<ContestJudgeRead>(`/api/organizer/contests/${contestId}/judges`, {
      method: "POST",
      body: payload
    });
  },
  removeContestJudge(contestId: string | number, userId: string | number) {
    return apiRequest<void>(`/api/organizer/contests/${contestId}/judges/${userId}`, {
      method: "DELETE"
    });
  },
  crossCheckContest(contestId: string | number) {
    return apiRequest<ProcessingJobRead>(`/api/organizer/contests/${contestId}/cross-check`, { method: "POST" });
  },
  publishResults(contestId: string | number) {
    return apiRequest<PublicResultRead[]>(`/api/organizer/contests/${contestId}/publish-results`, {
      method: "POST"
    });
  },
  getJudgeDashboard(contestId: string | number) {
    return apiRequest<JudgeDashboardRead>(`/api/judge/contests/${contestId}/dashboard`);
  },
  listJudgeContests() {
    return apiRequest<JudgeContestRead[]>("/api/judge/contests");
  },
  listJudgeConflicts(
    contestId: string | number,
    query: {
      conflict_type?: string;
      status?: string;
      station?: string;
      band?: string;
      region?: string;
      category?: string;
      confidence_lt?: number;
      sort_by?: "confidence" | "impact" | "detected_at";
      sort_dir?: "asc" | "desc";
      unresolved_first?: boolean;
      limit?: number;
      offset?: number;
    } = {}
  ) {
    const params = new URLSearchParams();
    Object.entries(query).forEach(([key, value]) => {
      if (value === undefined || value === null || value === "") {
        return;
      }
      params.set(key, String(value));
    });
    const suffix = params.toString() ? `?${params.toString()}` : "";
    return apiRequest<ConflictQueueRead>(`/api/judge/contests/${contestId}/conflicts${suffix}`);
  },
  getJudgeConflict(conflictId: string | number) {
    return apiRequest<ConflictWorkbenchDetail>(`/api/judge/conflicts/${conflictId}`);
  },
  getJudgeConflictNeighbors(
    conflictId: string | number,
    query: {
      contest_id: number;
      conflict_type?: string;
      status?: string;
      station?: string;
      band?: string;
      region?: string;
      category?: string;
      confidence_lt?: number;
      sort_by?: "confidence" | "impact" | "detected_at";
      sort_dir?: "asc" | "desc";
      unresolved_first?: boolean;
    }
  ) {
    const params = new URLSearchParams();
    Object.entries(query).forEach(([key, value]) => {
      if (value === undefined || value === null || value === "") {
        return;
      }
      params.set(key, String(value));
    });
    const suffix = params.toString() ? `?${params.toString()}` : "";
    return apiRequest<ConflictNeighborRead>(`/api/judge/conflicts/${conflictId}/neighbors${suffix}`);
  },
  searchJudgeContestParticipants(contestId: string | number, q: string, limit = 40) {
    const params = new URLSearchParams({ q, limit: String(limit) });
    return apiRequest<ParticipantStationSearchHit[]>(
      `/api/judge/contests/${contestId}/participants/search?${params.toString()}`
    );
  },
  listJudgeDecisions(conflictId: string | number) {
    return apiRequest<JudgeDecisionRead[]>(`/api/judge/conflicts/${conflictId}/decisions`);
  },
  createJudgeDecision(conflictId: string | number, payload: JudgeDecisionCreate) {
    return apiRequest<JudgeDecisionRead>(`/api/judge/conflicts/${conflictId}/decisions`, {
      method: "POST",
      body: payload
    });
  },
  listUsers() {
    return apiRequest<UserRead[]>("/api/admin/users");
  },
  updateUserRoles(userId: string | number, roles: UserRole[]) {
    return apiRequest<UserRead>(`/api/admin/users/${userId}/roles`, {
      method: "PATCH",
      body: { roles }
    });
  },
  updateUserStatus(userId: string | number, status: UserStatus) {
    return apiRequest<UserRead>(`/api/admin/users/${userId}/status`, {
      method: "PATCH",
      body: { status }
    });
  },
  listAuditEvents() {
    return apiRequest<AuditEventRead[]>("/api/admin/audit-events");
  }
};
